#!/usr/bin/env python3
"""Render and independently verify publication-safe HPADMIN V3 evidence.

Published aggregates and paired tests are recomputed from raw case rows.  The
private result's summary and paired_comparisons fields are deliberately ignored.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


CONDITIONS = ("direct", "native_reasoning_requested", "self_reflection", "dohaa")
PAIRINGS = (
    ("dohaa_vs_direct", "dohaa", "direct"),
    ("dohaa_vs_native_reasoning_requested", "dohaa", "native_reasoning_requested"),
    ("dohaa_vs_self_reflection", "dohaa", "self_reflection"),
    ("native_reasoning_requested_vs_direct", "native_reasoning_requested", "direct"),
    ("self_reflection_vs_direct", "self_reflection", "direct"),
)
ORACLE_GATE_TOKENS = ("oracle", "result_equals", "expected_result", "reference_answer")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
CONTROLLER_GATE_ALLOWLIST = {
    "result_spec", "production_domain_policy", "action_policy",
    "claim_evidence", "required_evidence",
}
SCORING_GATE_ALLOWLIST = CONTROLLER_GATE_ALLOWLIST | {"semantic_assertions"}
REQUIRED_PUBLIC_SOURCE_FILES = {
    "hpadmin-comparative-suite-v3.json",
    "hpadmin-comparative-suite-v3.commitment.json",
    "HPADMIN-COMPARATIVE-PROTOCOL-v3.json",
    "run_hpadmin_comparative_v3.py",
    "hpadmin_v3_gates.py",
    "generate_hpadmin_comparative_suite_v3.py",
    "render_hpadmin_comparative_report_v3.py",
    "hpadmin-comparative-prescore-v3.commitment.json",
}
PACKAGE_MANIFEST_PUBLIC_BINDINGS = {
    "HPADMIN-COMPARATIVE-PROTOCOL-v3.json",
    "generate_hpadmin_comparative_suite_v3.py",
    "hpadmin-comparative-suite-v3.json",
    "hpadmin_v3_gates.py",
    "render_hpadmin_comparative_report_v3.py",
    "run_hpadmin_comparative_v3.py",
}
REQUIRED_PASS_EXPRESSION = (
    "rate_dohaa > rate_direct AND W > L AND p_exact <= 0.05 AND L == 0 AND "
    "dohaa_unrecovered_runtime_failures == 0 AND oracle_isolation_violations == 0 AND "
    "visible_input_identity_violations == 0 AND shared_initial_identity_violations == 0"
)


def read_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def canonical_sha(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def visible_contract_sha(contract: Any) -> str:
    """Hash the scorer-free contract used by all four inference conditions."""

    if not isinstance(contract, dict):
        raise ValueError("suite contract must be an object")
    visible = json.loads(canonical_json(contract))
    inputs = visible.get("inputs")
    if not isinstance(inputs, dict):
        raise ValueError("suite contract inputs must be an object")
    inputs.pop("semantic_assertions", None)
    return canonical_sha(visible)


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def parse_package_manifest(path: Path) -> dict[str, str]:
    """Parse the original package manifest without permitting unsafe paths."""

    entries: dict[str, str] = {}
    for line_number, raw_line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        match = re.fullmatch(r"([0-9a-f]{64})  \./([A-Za-z0-9][A-Za-z0-9._-]*)", raw_line)
        if match is None:
            raise ValueError(f"unsafe or malformed package-manifest line {line_number}")
        digest, filename = match.groups()
        if filename in entries:
            raise ValueError(f"duplicate package-manifest entry: {filename}")
        entries[filename] = digest
    if not entries:
        raise ValueError("package manifest is empty")
    return entries


def require_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"{label} must be a non-negative integer")
    return value


def finite_number(value: Any, default: float = 0.0) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return default
    value = float(value)
    return value if math.isfinite(value) else default


def duration_seconds(started: Any, completed: Any) -> float | None:
    if not isinstance(started, str) or not isinstance(completed, str):
        return None
    try:
        return round((datetime.fromisoformat(completed) - datetime.fromisoformat(started)).total_seconds(), 3)
    except ValueError:
        return None


def average(values: Iterable[float | int]) -> float:
    values = list(values)
    return round(sum(values) / len(values), 6) if values else 0.0


def exact_two_sided_sign_p(wins: int, losses: int) -> float:
    discordant = wins + losses
    if discordant == 0:
        return 1.0
    tail = min(wins, losses)
    probability = 2.0 * sum(math.comb(discordant, index) for index in range(tail + 1)) / (2**discordant)
    return round(min(1.0, probability), 12)


def validated_score_pass(score: Any, label: str) -> bool:
    if not isinstance(score, dict):
        raise ValueError(f"{label} must be an object")
    boolean_fields = ("all_gates_passed", "production_all_gates_passed", "oracle_passed")
    if any(not isinstance(score.get(name), bool) for name in boolean_fields):
        raise ValueError(f"{label} score summary flags must be booleans")
    gate_results = score.get("gate_results")
    production_results = score.get("production_gate_results")
    oracle_result = score.get("oracle_gate_result")
    if not isinstance(gate_results, list) or not isinstance(production_results, list):
        raise ValueError(f"{label} gate results must be lists")
    if not isinstance(oracle_result, dict) or not isinstance(oracle_result.get("passed"), bool):
        raise ValueError(f"{label} oracle gate result must contain a boolean passed field")
    for collection_name, results in (
        ("gate_results", gate_results),
        ("production_gate_results", production_results),
    ):
        if any(not isinstance(item, dict) or not isinstance(item.get("passed"), bool) for item in results):
            raise ValueError(f"{label}.{collection_name} contains an invalid gate result")
    if gate_results != [*production_results, oracle_result]:
        raise ValueError(f"{label} combined gate results do not match production plus oracle results")
    production_pass = all(item["passed"] for item in production_results)
    all_pass = all(item["passed"] for item in gate_results)
    if score["production_all_gates_passed"] is not production_pass:
        raise ValueError(f"{label}.production_all_gates_passed is inconsistent")
    if score["oracle_passed"] is not oracle_result["passed"]:
        raise ValueError(f"{label}.oracle_passed is inconsistent")
    if score["all_gates_passed"] is not all_pass:
        raise ValueError(f"{label}.all_gates_passed is inconsistent with gate_results")
    if score["all_gates_passed"] is not (production_pass and oracle_result["passed"]):
        raise ValueError(f"{label}.all_gates_passed is inconsistent with production and oracle flags")
    return score["all_gates_passed"]


def score_pass(outcome: dict[str, Any]) -> bool:
    if outcome.get("status") == "completed":
        return validated_score_pass(outcome.get("final_score"), "final_score")
    return False


def failed_production_gates(outcome: dict[str, Any]) -> list[str]:
    score = outcome.get("final_score")
    if not isinstance(score, dict):
        return []
    gates = score.get("production_gate_results", score.get("gate_results", []))
    if not isinstance(gates, list):
        raise ValueError("gate results must be a list")
    failed: list[str] = []
    for gate in gates:
        if not isinstance(gate, dict) or gate.get("passed") is True:
            continue
        raw_name = gate.get("gate", gate.get("name"))
        name = raw_name if isinstance(raw_name, str) and raw_name else "UNNAMED_PRODUCTION_GATE"
        kind = str(gate.get("kind", "")).lower()
        if gate.get("production") is False or kind in {"oracle", "scoring", "reference"}:
            continue
        if any(token in name.lower() for token in ORACLE_GATE_TOKENS):
            continue
        failed.append(name)
    return sorted(set(failed))


def usage_fields(outcome: dict[str, Any]) -> tuple[int | None, bool]:
    summary = outcome.get("usage_summary")
    if not isinstance(summary, dict):
        return None, False
    tokens = summary.get("reported_total_tokens")
    if isinstance(tokens, bool) or not isinstance(tokens, int) or tokens < 0:
        tokens = None
    return tokens, bool(summary.get("complete"))


def physical_calls(raw: Any, label: str) -> dict[str, int]:
    if not isinstance(raw, dict):
        raise ValueError(f"{label} physical_model_calls missing")
    total = require_int(raw.get("total"), f"{label}.total")
    logical = require_int(
        raw.get("logical_inference_steps", raw.get("logical_calls")),
        f"{label}.logical_inference_steps",
    )
    retries = require_int(
        raw.get("transport_retries", raw.get("total_transport_retries")),
        f"{label}.transport_retries",
    )
    aliases = (
        ("total_request_attempts", total),
        ("logical_calls", logical),
        ("total_transport_retries", retries),
    )
    for alias, expected in aliases:
        if alias in raw and require_int(raw[alias], f"{label}.{alias}") != expected:
            raise ValueError(f"{label} physical-call alias mismatch: {alias}")
    return {"total": total, "logical_inference_steps": logical, "transport_retries": retries}


def validate_protocol_contract(protocol: dict[str, Any]) -> None:
    if protocol.get("schema_version") != "hpadmin-comparative-protocol/3.0":
        raise ValueError("unexpected V3 protocol schema")
    if protocol.get("protocol_id") != "hpadmin-local-small-hardware-comparative-v3":
        raise ValueError("unexpected V3 protocol ID")
    if [item.get("id") for item in protocol.get("conditions", []) if isinstance(item, dict)] != list(CONDITIONS):
        raise ValueError("protocol condition set/order mismatch")
    criteria = protocol.get("success_criteria")
    if not isinstance(criteria, dict) or criteria.get("combination") != "ALL_REQUIRED_AND":
        raise ValueError("V3 success criteria must be ALL_REQUIRED_AND")
    if criteria.get("pass_expression") != REQUIRED_PASS_EXPRESSION:
        raise ValueError("V3 pass expression is missing or changed")
    scoring = protocol.get("scoring", {})
    if scoring.get("exact_two_sided_sign_test", {}).get("alpha") != 0.05:
        raise ValueError("V3 preregistered alpha must equal 0.05")
    oracle = protocol.get("oracle_isolation", {})
    required_oracle = {
        "oracle_available_during_inference": False,
        "oracle_available_to_controllers": False,
        "oracle_available_to_prompts": False,
        "oracle_available_to_production_gates": False,
        "oracle_scorer_runs_only_after_all_suite_inference_outputs_are_final_and_committed": True,
        "oracle_feedback_to_any_condition": "ZERO",
    }
    if any(oracle.get(key) != value for key, value in required_oracle.items()):
        raise ValueError("V3 oracle-isolation policy is missing or changed")
    shared = protocol.get("shared_initial_proposal", {})
    if shared.get("enabled") is not True or shared.get("shared_by_conditions") != [
        "direct", "self_reflection", "dohaa"
    ]:
        raise ValueError("V3 shared-initial policy is missing or changed")


def prescore_boundary(
    result: dict[str, Any], boundary: dict[str, Any], artifact_path: Path | None,
    manifest_path: Path | None,
) -> dict[str, Any]:
    commitment = result.get("prescore_commitment", result.get("pre_score_commitment", {}))
    if not isinstance(commitment, dict):
        commitment = {}
    digest = (
        commitment.get("output_sha256")
        or commitment.get("prescore_output_sha256")
        or result.get("prescore_output_sha256")
        or result.get("pre_score_output_sha256")
    )
    if not isinstance(digest, str) or SHA256_RE.fullmatch(digest) is None:
        raise ValueError("a valid pre-score output SHA-256 commitment is required")
    embedded_payload = commitment.get("payload", result.get("prescore_payload"))
    artifact_file_digest = None
    if artifact_path is not None:
        artifact_payload = read_json(artifact_path)
        observed_digest = canonical_sha(artifact_payload)
        artifact_file_digest = file_sha(artifact_path)
        verification = "RECOMPUTED_FROM_PRIVATE_PRESCORE_ARTIFACT"
    elif embedded_payload is not None:
        observed_digest = canonical_sha(embedded_payload)
        verification = "RECOMPUTED_FROM_EMBEDDED_PRIVATE_PRESCORE_PAYLOAD"
    else:
        raise ValueError("pre-score payload/artifact is required to recompute its commitment")
    if observed_digest != digest:
        raise ValueError("pre-score output commitment does not match the private payload/artifact")
    if artifact_path is not None:
        expected_file_digest = result.get("prescore_output_file_sha256")
        if not isinstance(expected_file_digest, str) or artifact_file_digest != expected_file_digest:
            raise ValueError("pre-score file hash does not match final result")
    manifest_sha = None
    if artifact_path is not None and manifest_path is None:
        raise ValueError("pre-score commitment manifest is required")
    if manifest_path is not None:
        manifest = read_json(manifest_path)
        if not isinstance(manifest, dict):
            raise ValueError("pre-score commitment manifest must be an object")
        if manifest.get("prescore_canonical_sha256", manifest.get("canonical_sha256")) != digest:
            raise ValueError("pre-score commitment manifest canonical hash mismatch")
        if artifact_path is None or manifest.get("prescore_file_sha256", manifest.get("file_sha256")) != artifact_file_digest:
            raise ValueError("pre-score commitment manifest file hash mismatch")
        if manifest.get("suite_commitment_sha256") != result.get("suite_commitment_sha256"):
            raise ValueError("pre-score commitment manifest suite commitment mismatch")
        if manifest.get("oracle_feedback_events") != 0:
            raise ValueError("pre-score commitment manifest reports oracle feedback")
        if manifest.get("size_bytes") != artifact_path.stat().st_size:
            raise ValueError("pre-score commitment manifest size mismatch")
        manifest_sha = file_sha(manifest_path)
    loaded_after = boundary.get(
        "oracle_loaded_after_prescore_commit",
        boundary.get("oracle_loaded_after_pre_score_commit"),
    )
    if loaded_after is not True:
        raise ValueError("oracle must be loaded only after the pre-score output commitment")
    return {
        "prescore_output_sha256": digest,
        "prescore_output_canonical_sha256": digest,
        "prescore_output_file_sha256": artifact_file_digest,
        "prescore_digest_verification": verification,
        "prescore_commitment_manifest_sha256": manifest_sha,
        "oracle_loaded_after_prescore_commit": True,
    }


def validate_oracle_boundary(
    result: dict[str, Any], prescore_artifact: Path | None,
    prescore_manifest: Path | None,
) -> dict[str, Any]:
    events = require_int(result.get("oracle_feedback_events"), "oracle_feedback_events")
    boundary = result.get("oracle_boundary")
    if not isinstance(boundary, dict):
        raise ValueError("oracle_boundary is required")
    if boundary.get("controller_expected_result_access") is not False:
        raise ValueError("controller expected-result access was not explicitly disabled")
    if boundary.get("controller_result_equals_gate") is not False:
        raise ValueError("controller result_equals access was not explicitly disabled")
    if boundary.get("scoring_after_controller") is not True:
        raise ValueError("scoring-after-controller boundary is not asserted")
    if boundary.get("semantic_assertions_available_during_inference") is not False:
        raise ValueError("semantic assertions were not explicitly excluded from inference")
    if boundary.get("semantic_assertions_loaded_only_by_scorer") is not True:
        raise ValueError("semantic assertions were not explicitly restricted to the scorer")
    if boundary.get("asserted_zero_oracle_feedback_events") is not True or events != 0:
        raise ValueError("zero oracle-feedback assertion failed")
    return {
        "oracle_feedback_events": 0,
        "controller_expected_result_access": False,
        "controller_result_equals_gate": False,
        "scoring_after_controller": True,
        "semantic_assertions_available_during_inference": False,
        "semantic_assertions_loaded_only_by_scorer": True,
        "verified_from_raw_cases": True,
        **prescore_boundary(result, boundary, prescore_artifact, prescore_manifest),
    }


def validate_prescore_case_binding(result: dict[str, Any], artifact_path: Path | None) -> None:
    """Prove that scoring only appended scorer-owned fields to committed inference rows."""

    if artifact_path is None:
        raise ValueError("private pre-score artifact is required for case-level binding")
    prescore = read_json(artifact_path)
    if not isinstance(prescore, dict) or not isinstance(prescore.get("cases"), list):
        raise ValueError("pre-score artifact lacks case rows")

    forbidden_oracle_tokens = ("oracle", "result_equals", "expected_result", "reference_answer")
    scorer_key_tokens = (
        "initial_score", "final_score", "improved", "regressed",
        "repair_transition", "public_summary", "oracle_gate_result",
    )

    prescore_top_keys = frozenset({
        "schema_version", "evaluation_id", "suite_id", "suite_sha256",
        "suite_commitment", "suite_commitment_sha256", "protocol_id",
        "protocol_sha256", "started_at", "inference_completed_at", "seed",
        "sampling_seed", "repetitions", "conditions", "oracle_feedback_events",
        "visible_input_identity_violations", "controller_production_gate_names",
        "scoring_production_gate_names", "runtime_policy", "counterbalancing",
        "physical_model_calls", "attributed_logical_calls_by_condition", "cases",
    })
    prescore_row_keys = frozenset({
        "case_id", "domain", "repetition", "sampling_seed",
        "visible_input_sha256", "condition_visible_input_sha256",
        "initial_call_order", "execution_order", "branch_order",
        "shared_initial_proposal_sha256", "shared_initial_identity_verified",
        "oracle_feedback_events", "conditions", "physical_model_calls",
    })
    outcome_common_keys = frozenset({
        "condition", "status", "runtime_calls", "attributed_logical_model_calls",
        "elapsed_seconds", "usage", "usage_summary", "initial_proposal",
        "final_proposal", "initial_proposal_sha256", "transport",
        "oracle_feedback_events", "visible_input_sha256",
    })
    outcome_failure_keys = frozenset({"error_type", "error_code", "error", "error_details"})
    outcome_condition_keys = {
        "direct": frozenset({"shared_initial_proposal_sha256"}),
        "native_reasoning_requested": frozenset({
            "reasoning_effort_requested", "reasoning_attestation",
        }),
        "self_reflection": frozenset({"shared_initial_proposal_sha256"}),
        "dohaa": frozenset({"shared_initial_proposal_sha256", "controller"}),
    }

    def assert_exact_prescore_schema(value: dict[str, Any]) -> None:
        top_keys = set(value)
        if top_keys != prescore_top_keys:
            unknown = sorted(top_keys - prescore_top_keys)
            missing = sorted(prescore_top_keys - top_keys)
            raise ValueError(f"pre-score top-level schema mismatch; unknown={unknown}, missing={missing}")
        rows = value.get("cases")
        if not isinstance(rows, list):
            raise ValueError("pre-score cases must be a list")
        for row_index, row in enumerate(rows):
            if not isinstance(row, dict):
                raise ValueError(f"pre-score case {row_index} must be an object")
            row_keys = set(row)
            if row_keys != prescore_row_keys:
                unknown = sorted(row_keys - prescore_row_keys)
                missing = sorted(prescore_row_keys - row_keys)
                raise ValueError(
                    f"pre-score case {row_index} schema mismatch; unknown={unknown}, missing={missing}"
                )
            outcomes = row.get("conditions")
            if not isinstance(outcomes, dict) or set(outcomes) != set(CONDITIONS):
                raise ValueError(f"pre-score case {row_index} condition set mismatch")
            for condition in CONDITIONS:
                outcome = outcomes.get(condition)
                if not isinstance(outcome, dict):
                    raise ValueError(f"pre-score {row_index}/{condition} outcome must be an object")
                status = outcome.get("status")
                if status not in {"completed", "runtime_failed"}:
                    raise ValueError(f"pre-score {row_index}/{condition} status is invalid")
                required = outcome_common_keys | outcome_condition_keys[condition]
                if status == "runtime_failed":
                    required |= outcome_failure_keys
                allowed = required
                # A DOHAA controller is absent only when the shared initial call failed.
                if condition == "dohaa" and status == "runtime_failed" and "controller" not in outcome:
                    required = required - {"controller"}
                outcome_keys = set(outcome)
                if outcome_keys != required:
                    unknown = sorted(outcome_keys - allowed)
                    missing = sorted(required - outcome_keys)
                    raise ValueError(
                        f"pre-score {row_index}/{condition} schema mismatch; "
                        f"unknown={unknown}, missing={missing}"
                    )
                if outcome.get("condition") != condition:
                    raise ValueError(f"pre-score {row_index}/{condition} condition label mismatch")

    assert_exact_prescore_schema(prescore)

    def assert_inference_only(value: Any, path: str = "prescore") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                lowered = str(key).lower()
                child_path = f"{path}.{key}"
                if lowered == "oracle_feedback_events":
                    if isinstance(child, bool) or not isinstance(child, int) or child != 0:
                        raise ValueError(f"{child_path} must be the integer zero")
                    continue
                if any(token in lowered for token in forbidden_oracle_tokens):
                    raise ValueError(f"pre-score contains forbidden oracle key: {child_path}")
                if any(token in lowered for token in scorer_key_tokens):
                    raise ValueError(f"pre-score contains scorer-owned key or alias: {child_path}")
                assert_inference_only(child, child_path)
            return
        if isinstance(value, list):
            for index, child in enumerate(value):
                assert_inference_only(child, f"{path}[{index}]")
            return
        if isinstance(value, str):
            lowered = value.lower()
            if any(token in lowered for token in forbidden_oracle_tokens):
                raise ValueError(f"pre-score contains forbidden oracle token at {path}")

    assert_inference_only(prescore)

    scorer_fields = ("initial_score", "final_score", "improved", "regressed", "repair_transition")

    def inference_projection(rows: Any, *, reject_scorer_fields: bool) -> dict[str, Any]:
        if not isinstance(rows, list):
            raise ValueError("case rows must be a list")
        projected: dict[str, Any] = {}
        for raw_row in rows:
            if not isinstance(raw_row, dict) or not isinstance(raw_row.get("case_id"), str):
                raise ValueError("invalid case row in pre-score binding")
            row = json.loads(canonical_json(raw_row))
            case_id = row["case_id"]
            if case_id in projected:
                raise ValueError("duplicate case row in pre-score binding")
            if reject_scorer_fields and "public_summary" in row:
                raise ValueError("pre-score artifact already contains scorer-owned public_summary")
            row.pop("public_summary", None)
            outcomes = row.get("conditions")
            if not isinstance(outcomes, dict):
                raise ValueError("case row lacks conditions in pre-score binding")
            for outcome in outcomes.values():
                if not isinstance(outcome, dict):
                    raise ValueError("invalid outcome in pre-score binding")
                if reject_scorer_fields and any(field in outcome for field in scorer_fields):
                    raise ValueError("pre-score artifact already contains scorer-owned fields")
                proposal = outcome.get("initial_proposal")
                proposal_hash = outcome.get("initial_proposal_sha256")
                recomputed_hash = canonical_sha(proposal) if isinstance(proposal, dict) else None
                if proposal is not None and not isinstance(proposal, dict):
                    raise ValueError("pre-score initial proposal must be an object or null")
                if proposal_hash != recomputed_hash:
                    raise ValueError("pre-score initial proposal hash mismatch")
                for scorer_field in scorer_fields:
                    outcome.pop(scorer_field, None)
            shared_hash = row.get("shared_initial_proposal_sha256")
            shared_outcome_hashes = [
                outcomes[name].get("initial_proposal_sha256")
                for name in ("direct", "self_reflection", "dohaa")
            ]
            if shared_hash is None:
                if any(value is not None for value in shared_outcome_hashes):
                    raise ValueError("pre-score shared proposal failure has non-null branch hash")
            elif not isinstance(shared_hash, str) or SHA256_RE.fullmatch(shared_hash) is None or any(
                value != shared_hash for value in shared_outcome_hashes
            ):
                raise ValueError("pre-score shared proposal hashes do not match proposal payloads")
            projected[case_id] = row
        return projected

    prescore_projection = inference_projection(prescore.get("cases"), reject_scorer_fields=True)
    result_projection = inference_projection(result.get("cases"), reject_scorer_fields=False)
    if result_projection != prescore_projection:
        raise ValueError("post-score result mutated inference-owned committed case data")


def audit_production_feedback(result: dict[str, Any]) -> dict[str, Any]:
    controller_names = result.get("controller_production_gate_names")
    scoring_names = result.get("scoring_production_gate_names")
    alias_names = result.get("production_gate_names")
    if not isinstance(controller_names, list) or set(controller_names) != CONTROLLER_GATE_ALLOWLIST:
        raise ValueError("top-level controller production-gate allowlist mismatch")
    if len(controller_names) != len(set(controller_names)):
        raise ValueError("duplicate controller production gate")
    if not isinstance(scoring_names, list) or set(scoring_names) != SCORING_GATE_ALLOWLIST:
        raise ValueError("top-level scoring production-gate allowlist mismatch")
    if len(scoring_names) != len(set(scoring_names)) or alias_names != scoring_names:
        raise ValueError("scoring production-gate alias mismatch")
    feedback_count = 0
    controllers_audited = 0
    for row in result.get("cases", []):
        dohaa = row.get("conditions", {}).get("dohaa", {})
        controller = dohaa.get("controller")
        if controller is None:
            if dohaa.get("status") != "runtime_failed":
                raise ValueError(f"missing DOHAA controller audit in {row.get('case_id')}")
            continue
        if not isinstance(controller, dict):
            raise ValueError("invalid DOHAA controller audit object")
        names = controller.get("production_gate_names")
        if not isinstance(names, list) or set(names) != CONTROLLER_GATE_ALLOWLIST:
            raise ValueError(f"DOHAA controller gate allowlist mismatch in {row.get('case_id')}")
        if controller.get("oracle_feedback_events") != 0:
            raise ValueError(f"DOHAA controller oracle feedback in {row.get('case_id')}")
        events = controller.get("feedback_events")
        if not isinstance(events, list):
            raise ValueError("DOHAA controller feedback event list missing")
        for event in events:
            if not isinstance(event, dict):
                raise ValueError("invalid DOHAA controller feedback event")
            gate, code = str(event.get("gate", "")), str(event.get("code", ""))
            lowered = f"{gate} {code}".lower()
            if gate not in CONTROLLER_GATE_ALLOWLIST:
                raise ValueError(f"non-production feedback gate: {gate}")
            if "result.mismatch" in lowered or any(token in lowered for token in ORACLE_GATE_TOKENS):
                raise ValueError("oracle-derived DOHAA feedback event detected")
        feedback_count += len(events)
        controllers_audited += 1
    return {
        "status": "VERIFIED_FROM_RAW_CONTROLLER_EVENTS",
        "controller_gate_names": sorted(CONTROLLER_GATE_ALLOWLIST),
        "scoring_gate_names": sorted(SCORING_GATE_ALLOWLIST),
        "semantic_assertions_controller_available": False,
        "semantic_assertions_scoring_only": True,
        "controllers_audited": controllers_audited,
        "feedback_events_audited": feedback_count,
        "forbidden_feedback_events": 0,
    }


def build_case_matrix(
    result: dict[str, Any], expected_count: int, expected_visible_hashes: dict[str, str]
) -> list[dict[str, Any]]:
    rows = result.get("cases")
    if not isinstance(rows, list) or len(rows) != expected_count:
        raise ValueError("raw case count differs from frozen suite")
    matrix: list[dict[str, Any]] = []
    seen: set[str] = set()
    if require_int(result.get("oracle_feedback_events"), "oracle_feedback_events") != 0:
        raise ValueError("oracle feedback contamination detected")
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            raise ValueError(f"case row {index} is not an object")
        case_id, domain = row.get("case_id"), row.get("domain")
        if not isinstance(case_id, str) or not case_id or case_id in seen:
            raise ValueError(f"invalid or duplicate case_id at row {index}")
        if not isinstance(domain, str) or not domain:
            raise ValueError(f"invalid domain for {case_id}")
        expected_visible_hash = expected_visible_hashes.get(case_id)
        if not isinstance(expected_visible_hash, str):
            raise ValueError(f"missing suite-derived visible-input hash for {case_id}")
        visible_hash = row.get("visible_input_sha256")
        condition_visible_hashes = row.get("condition_visible_input_sha256")
        if not isinstance(visible_hash, str) or SHA256_RE.fullmatch(visible_hash) is None:
            raise ValueError(f"invalid visible-input hash for {case_id}")
        if not isinstance(condition_visible_hashes, dict) or set(condition_visible_hashes) != set(CONDITIONS):
            raise ValueError(f"invalid condition visible-input hashes for {case_id}")
        seen.add(case_id)
        if require_int(row.get("oracle_feedback_events"), f"{case_id}.oracle_feedback_events") != 0:
            raise ValueError(f"oracle feedback contamination in {case_id}")
        outcomes = row.get("conditions")
        if not isinstance(outcomes, dict) or set(outcomes) != set(CONDITIONS):
            raise ValueError(f"unexpected conditions for {case_id}")
        cells: dict[str, Any] = {}
        shared_hash = row.get("shared_initial_proposal_sha256")
        if shared_hash is not None and (not isinstance(shared_hash, str) or SHA256_RE.fullmatch(shared_hash) is None):
            raise ValueError(f"invalid shared initial proposal hash for {case_id}")
        for condition in CONDITIONS:
            outcome = outcomes[condition]
            if not isinstance(outcome, dict):
                raise ValueError(f"invalid outcome {case_id}/{condition}")
            status = outcome.get("status")
            if status not in {"completed", "runtime_failed"}:
                raise ValueError(f"unexpected status for {case_id}/{condition}: {status}")
            if require_int(outcome.get("oracle_feedback_events"), f"{case_id}/{condition}.oracle_feedback_events") != 0:
                raise ValueError(f"oracle feedback contamination in {case_id}/{condition}")
            transport = outcome.get("transport") if isinstance(outcome.get("transport"), dict) else {}
            calls = require_int(
                outcome.get("attributed_logical_model_calls", outcome.get("runtime_calls")),
                f"{case_id}/{condition}.attributed_logical_model_calls",
            )
            attempts = require_int(transport.get("request_attempts", calls), f"{case_id}/{condition}.request_attempts")
            retries = require_int(
                transport.get("transport_retries", transport.get("retries", 0)),
                f"{case_id}/{condition}.retries",
            )
            recovered_calls = require_int(
                transport.get("recovered_logical_calls"),
                f"{case_id}/{condition}.recovered_logical_calls",
            )
            if "transport_retries" in transport and "retries" in transport:
                if require_int(transport["retries"], f"{case_id}/{condition}.retries_alias") != retries:
                    raise ValueError(f"transport retry alias mismatch for {case_id}/{condition}")
            if attempts != calls + retries:
                raise ValueError(f"transport attempts must equal logical calls plus retries for {case_id}/{condition}")
            if recovered_calls > retries:
                raise ValueError(f"recovered logical calls exceed retries for {case_id}/{condition}")
            tokens, usage_complete = usage_fields(outcome)
            initial_hash = outcome.get("initial_proposal_sha256")
            if initial_hash is not None and (not isinstance(initial_hash, str) or SHA256_RE.fullmatch(initial_hash) is None):
                raise ValueError(f"invalid initial proposal hash for {case_id}/{condition}")
            outcome_visible_hash = outcome.get("visible_input_sha256")
            if not isinstance(outcome_visible_hash, str) or SHA256_RE.fullmatch(outcome_visible_hash) is None:
                raise ValueError(f"invalid outcome visible-input hash for {case_id}/{condition}")
            final_pass = score_pass(outcome)
            if status == "completed":
                initial_pass = validated_score_pass(
                    outcome.get("initial_score"), f"{case_id}/{condition}.initial_score"
                )
                improved, regressed = (not initial_pass and final_pass), (initial_pass and not final_pass)
            else:
                improved = regressed = False
            recovered = recovered_calls > 0
            if "recovered_after_retry" in transport and bool(transport["recovered_after_retry"]) != recovered:
                raise ValueError(f"transport recovery flag mismatch for {case_id}/{condition}")
            cells[condition] = {
                "status": status,
                "pass": final_pass,
                "attributed_logical_calls": calls,
                "transport_request_attempts": attempts,
                "transport_retries": retries,
                "recovered_logical_calls": recovered_calls,
                "recovered_after_retry": recovered,
                "error_code": str(outcome.get("error_code")) if outcome.get("error_code") is not None else None,
                "improved": improved,
                "regressed": regressed,
                "failed_production_gates": failed_production_gates(outcome),
                "elapsed_seconds": round(finite_number(outcome.get("elapsed_seconds")), 6),
                "reported_total_tokens": tokens,
                "usage_complete": usage_complete,
                "initial_proposal_sha256": initial_hash,
                "visible_input_sha256": outcome_visible_hash,
            }
        shared_identity = shared_hash is not None and all(
            cells[name]["initial_proposal_sha256"] == shared_hash
            for name in ("direct", "self_reflection", "dohaa")
        )
        visible_identity = visible_hash == expected_visible_hash and all(
            condition_visible_hashes[name] == expected_visible_hash
            and cells[name]["visible_input_sha256"] == expected_visible_hash
            for name in CONDITIONS
        )
        matrix.append(
            {
                "case_id": case_id,
                "domain": domain,
                "visible_input_sha256": visible_hash,
                "condition_visible_input_sha256": dict(condition_visible_hashes),
                "visible_input_identity_verified": visible_identity,
                "execution_order": list(row.get("execution_order", [])),
                "branch_order": list(row.get("branch_order", [])),
                "shared_initial_proposal_sha256": shared_hash,
                "shared_initial_identity_verified": shared_identity,
                "physical_model_calls": physical_calls(row.get("physical_model_calls"), case_id),
                "conditions": cells,
            }
        )
    return sorted(matrix, key=lambda item: item["case_id"])


def recompute(matrix: list[dict[str, Any]]) -> dict[str, Any]:
    if not matrix:
        raise ValueError("empty case matrix")
    condition_summary: dict[str, Any] = {}
    for condition in CONDITIONS:
        cells = [row["conditions"][condition] for row in matrix]
        completed = [cell for cell in cells if cell["status"] == "completed"]
        passes = sum(bool(cell["pass"]) for cell in cells)
        tokens_known = all(cell["reported_total_tokens"] is not None for cell in cells)
        condition_summary[condition] = {
            "unique_cases": len(cells),
            "completed": len(completed),
            "runtime_failures": len(cells) - len(completed),
            "final_passes": passes,
            "final_pass_rate": round(passes / len(cells), 6),
            "semantic_pass_rate_among_completed": round(passes / len(completed), 6) if completed else 0.0,
            "improved": sum(bool(cell["improved"]) for cell in completed),
            "regressed": sum(bool(cell["regressed"]) for cell in completed),
            "average_attributed_logical_model_calls": average(cell["attributed_logical_calls"] for cell in cells),
            "average_transport_request_attempts": average(cell["transport_request_attempts"] for cell in cells),
            "total_transport_retries": sum(cell["transport_retries"] for cell in cells),
            "recovered_transport_cases": sum(bool(cell["recovered_after_retry"]) for cell in cells),
            "average_elapsed_seconds": average(cell["elapsed_seconds"] for cell in cells),
            "reported_total_tokens": sum(int(cell["reported_total_tokens"]) for cell in cells) if tokens_known else None,
            "usage_complete": tokens_known and all(bool(cell["usage_complete"]) for cell in cells),
        }
    comparisons: dict[str, Any] = {}
    for name, left, right in PAIRINGS:
        wins = sum(row["conditions"][left]["pass"] and not row["conditions"][right]["pass"] for row in matrix)
        losses = sum(row["conditions"][right]["pass"] and not row["conditions"][left]["pass"] for row in matrix)
        ties = len(matrix) - wins - losses
        both_pass = sum(row["conditions"][left]["pass"] and row["conditions"][right]["pass"] for row in matrix)
        both_fail = sum(not row["conditions"][left]["pass"] and not row["conditions"][right]["pass"] for row in matrix)
        comparisons[name] = {
            "left": left,
            "right": right,
            "wins": wins,
            "losses": losses,
            "ties": ties,
            "both_pass_ties": both_pass,
            "both_fail_ties": both_fail,
            "discordant_cases": wins + losses,
            "mean_pass_rate_difference": round((wins - losses) / len(matrix), 6),
            "exact_two_sided_sign_test_p": exact_two_sided_sign_p(wins, losses),
        }
    domains: dict[str, Any] = {}
    for domain in sorted({row["domain"] for row in matrix}):
        subset = [row for row in matrix if row["domain"] == domain]
        domains[domain] = {
            condition: {
                "passes": sum(row["conditions"][condition]["pass"] for row in subset),
                "cases": len(subset),
                "runtime_failures": sum(row["conditions"][condition]["status"] != "completed" for row in subset),
            }
            for condition in CONDITIONS
        }
    failures = [
        (row["domain"], condition, row["conditions"][condition])
        for row in matrix
        for condition in CONDITIONS
        if row["conditions"][condition]["status"] != "completed"
    ]
    failures_by_code = Counter(cell["error_code"] or "unclassified" for _, _, cell in failures)
    failures_by_condition = Counter(condition for _, condition, _ in failures)
    failures_by_domain = Counter(domain for domain, _, _ in failures)
    failures_joint = Counter(f"{condition}/{cell['error_code'] or 'unclassified'}" for _, condition, cell in failures)
    physical = {
        key: sum(row["physical_model_calls"][key] for row in matrix)
        for key in ("total", "logical_inference_steps", "transport_retries")
    }
    attributed = {
        condition: sum(row["conditions"][condition]["attributed_logical_calls"] for row in matrix)
        for condition in CONDITIONS
    }
    branch_balance: dict[str, dict[str, int]] = {}
    initial_balance: dict[str, dict[str, int]] = {}
    for domain in sorted({row["domain"] for row in matrix}):
        counts: Counter[str] = Counter()
        initial_counts: Counter[str] = Counter()
        for row in matrix:
            if row["domain"] != domain:
                continue
            order = row["branch_order"]
            label = "_then_".join(order) if isinstance(order, list) and order else "UNKNOWN"
            counts[label] += 1
            initial_order = row["execution_order"]
            initial_label = "_then_".join(initial_order) if isinstance(initial_order, list) and initial_order else "UNKNOWN"
            initial_counts[initial_label] += 1
        branch_balance[domain] = dict(sorted(counts.items()))
        initial_balance[domain] = dict(sorted(initial_counts.items()))
    identity_violations = sum(not row["shared_initial_identity_verified"] for row in matrix)
    visible_identity_violations = sum(not row["visible_input_identity_verified"] for row in matrix)
    return {
        "conditions": condition_summary,
        "comparisons": comparisons,
        "domain_summary": domains,
        "runtime_failure_counts": {
            "by_code": dict(sorted(failures_by_code.items())),
            "by_condition": dict(sorted(failures_by_condition.items())),
            "by_domain": dict(sorted(failures_by_domain.items())),
            "by_condition_and_code": dict(sorted(failures_joint.items())),
        },
        "model_call_accounting": {
            "physical_model_calls": physical,
            "attributed_logical_calls_by_condition": attributed,
            "attributed_logical_calls_total": sum(attributed.values()),
            "sharing_semantic_advantage": False,
            "explanation": "Shared initial inference reduces physical compute only; it is not counted as a semantic advantage.",
        },
        "branch_order_balance": branch_balance,
        "initial_call_order_balance": initial_balance,
        "shared_initial_identity_violations": identity_violations,
        "visible_input_identity_violations": visible_identity_violations,
    }


def assessment_from(protocol: dict[str, Any], computed: dict[str, Any], oracle_zero: bool) -> tuple[str, dict[str, bool]]:
    validate_protocol_contract(protocol)
    direct = computed["conditions"]["direct"]
    dohaa = computed["conditions"]["dohaa"]
    primary = computed["comparisons"]["dohaa_vs_direct"]
    checks = {
        "dohaa_final_pass_rate_gt_direct": dohaa["final_pass_rate"] > direct["final_pass_rate"],
        "dohaa_wins_gt_losses_vs_direct": primary["wins"] > primary["losses"],
        "dohaa_vs_direct_p_lte_0_05": primary["exact_two_sided_sign_test_p"] <= 0.05,
        "zero_dohaa_losses": primary["losses"] == 0,
        "zero_dohaa_unrecovered_runtime_failures": dohaa["runtime_failures"] == 0,
        "zero_oracle_feedback_events": oracle_zero,
        "zero_visible_input_identity_violations": computed["visible_input_identity_violations"] == 0,
        "zero_shared_initial_identity_violations": computed["shared_initial_identity_violations"] == 0,
    }
    return ("PASS" if all(checks.values()) else "NOT_PASSED", checks)


def public_hardware(path: Path | None) -> dict[str, Any]:
    if path is None:
        return {
            "status": "UNKNOWN", "cost_status": "UNKNOWN",
            "affordable_hardware_demonstrated": False, "evidence": None,
        }
    evidence = read_json(path)
    if not isinstance(evidence, dict):
        raise ValueError("hardware evidence must be a JSON object")
    cost_status = str(evidence.get("cost_status", "UNKNOWN"))
    affordable = bool(evidence.get("affordable_hardware_demonstrated", False))
    if affordable and cost_status == "UNKNOWN":
        raise ValueError("hardware affordability cannot be asserted while cost evidence is UNKNOWN")
    return {
        "status": "SUPPLIED_SANITIZED_EVIDENCE",
        "cost_status": cost_status,
        "affordable_hardware_demonstrated": affordable,
        "evidence": evidence,
        "file_sha256": file_sha(path),
    }


def public_execution(result: dict[str, Any], path: Path | None) -> dict[str, Any]:
    runtime = result.get("runtime_policy") if isinstance(result.get("runtime_policy"), dict) else {}
    commit = runtime.get("execution_code_commit")
    if path is None or not path.is_file():
        raise ValueError("execution metadata is required for the package-manifest commitment chain")
    metadata = read_json(path)
    if not isinstance(metadata, dict):
        raise ValueError("execution metadata must be a JSON object")
    metadata_commit = metadata.get("execution_code_commit")
    package_manifest_sha = metadata.get("package_manifest_sha256")
    if metadata.get("execution_code_commit_kind") != "package_manifest_sha256":
        raise ValueError("execution metadata commitment kind is not package_manifest_sha256")
    if not isinstance(commit, str) or SHA256_RE.fullmatch(commit) is None:
        raise ValueError("runtime execution commit is not a SHA-256")
    if metadata_commit != commit or package_manifest_sha != commit:
        raise ValueError("runtime and execution metadata do not share one package-manifest commitment")
    native = metadata.get("native_reasoning")
    if not isinstance(native, dict) or native != {
        "request": "high",
        "public_label": "native_reasoning_requested",
        "attestation_status": "requested_configured_not_attested",
    }:
        raise ValueError("execution metadata native-reasoning boundary mismatch")
    if metadata.get("model_artifact_attestation_status") != "operator_declared_not_attested":
        raise ValueError("execution metadata overstates model artifact attestation")
    return {
        "execution_code_commit": commit,
        "package_manifest_sha256": commit,
        "execution_code_commit_kind": "package_manifest_sha256",
        "execution_code_commit_status": "PACKAGE_MANIFEST_SHA256_CHAIN_VERIFIED_EXECUTION_NOT_INDEPENDENTLY_ATTESTED",
        "metadata_status": "SUPPLIED_SANITIZED_EVIDENCE",
        "metadata": metadata,
        "metadata_file_sha256": file_sha(path),
    }


def validate_runtime_against_protocol(result: dict[str, Any], protocol: dict[str, Any]) -> dict[str, Any]:
    runtime = result.get("runtime_policy")
    if not isinstance(runtime, dict):
        raise ValueError("runtime_policy missing")
    execution = protocol.get("execution_policy", {})
    model = protocol.get("model_policy", {})
    retry = execution.get("transport_retry", {})
    exact_pairs = (
        (result.get("seed"), execution.get("condition_order_seed"), "condition_order_seed"),
        (result.get("sampling_seed"), execution.get("sampling_seed"), "result sampling_seed"),
        (runtime.get("sampling_seed"), execution.get("sampling_seed"), "runtime sampling_seed"),
        (result.get("repetitions"), execution.get("confirmatory_runs"), "confirmatory_runs"),
        (runtime.get("temperature"), model.get("temperature"), "temperature"),
        (runtime.get("top_p"), model.get("top_p"), "top_p"),
        (runtime.get("timeout_seconds_per_request"), execution.get("timeout_seconds_per_request"), "timeout"),
        (
            runtime.get("maximum_transport_retries_per_logical_call"),
            retry.get("maximum_retries_per_logical_call"),
            "maximum transport retries",
        ),
        (runtime.get("retry_delay_seconds"), retry.get("retry_delay_seconds"), "retry delay"),
        (runtime.get("model_alias"), model.get("default_model_alias"), "model alias"),
        (runtime.get("model_artifact_id"), model.get("default_model_artifact_id"), "model artifact ID"),
    )
    for observed, expected, label in exact_pairs:
        if observed != expected:
            raise ValueError(f"runtime/protocol mismatch: {label}")
    if sorted(runtime.get("retryable_codes", [])) != sorted(retry.get("retryable_codes", [])):
        raise ValueError("runtime/protocol mismatch: retryable codes")
    if runtime.get("redirects_allowed") is not False:
        raise ValueError("runtime locality boundary requires redirects_allowed=false")
    if runtime.get("proxy_environment_used") is not False:
        raise ValueError("runtime locality boundary requires proxy_environment_used=false")
    reasoning = runtime.get("condition_reasoning_effort")
    expected_reasoning = {
        "direct": "none",
        "native_reasoning_requested": "high",
        "self_reflection": "none",
        "dohaa": "none",
    }
    if reasoning != expected_reasoning:
        raise ValueError("runtime/protocol mismatch: requested reasoning efforts")
    reasoning_attestation = "requested_configured_not_independently_attested_for_all_conditions"
    if runtime.get("reasoning_configuration_attestation") != reasoning_attestation:
        raise ValueError("reasoning configuration attestation boundary is missing or changed")
    if model.get("reasoning_configuration_attestation") != reasoning_attestation:
        raise ValueError("protocol reasoning configuration attestation boundary is missing or changed")
    commit = runtime.get("execution_code_commit")
    if not isinstance(commit, str) or not commit:
        raise ValueError("execution code commit missing")
    for key in ("evaluator_sha256", "production_gates_sha256"):
        value = runtime.get(key)
        if not isinstance(value, str) or SHA256_RE.fullmatch(value) is None:
            raise ValueError(f"runtime {key} missing or invalid")
    return runtime


def render(args: argparse.Namespace) -> int:
    required = (args.result, args.suite, args.commitment, args.protocol)
    if any(path is None or not path.is_file() for path in required):
        raise SystemExit("missing required result/suite/commitment/protocol input")
    if args.output_dir.exists():
        raise SystemExit(f"refusing to overwrite output directory: {args.output_dir}")
    args.output_dir.mkdir(parents=True, mode=0o700)
    result, suite = read_json(args.result), read_json(args.suite)
    commitment, protocol = read_json(args.commitment), read_json(args.protocol)
    validate_protocol_contract(protocol)
    suite_sha = canonical_sha(suite)
    suite_id = suite.get("suite_id")
    if not isinstance(suite_id, str) or suite_id != protocol.get("suite_policy", {}).get("suite_id"):
        raise SystemExit("suite ID differs from protocol")
    if result.get("suite_id") != suite_id or commitment.get("suite_id") != suite_id:
        raise SystemExit("suite ID differs across suite, commitment, and result")
    if result.get("suite_sha256") != suite_sha or commitment.get("suite_sha256") != suite_sha:
        raise SystemExit("suite, commitment, and result do not match")
    if result.get("suite_commitment") != commitment:
        raise SystemExit("result embedded commitment differs from supplied commitment")
    if result.get("suite_commitment_sha256") != canonical_sha(commitment):
        raise SystemExit("result embedded commitment hash differs from supplied commitment")
    if result.get("protocol_id") != protocol.get("protocol_id"):
        raise SystemExit("protocol ID mismatch")
    if result.get("protocol_sha256") != canonical_sha(protocol):
        raise SystemExit("result does not match supplied protocol")
    if tuple(result.get("conditions", [])) != CONDITIONS:
        raise SystemExit("unexpected condition set or order")
    expected_count = int(protocol.get("suite_policy", {}).get("case_count", 0))
    if expected_count <= 0 or len(suite.get("cases", [])) != expected_count:
        raise SystemExit("suite count differs from protocol")
    runtime = validate_runtime_against_protocol(result, protocol)
    oracle_boundary = validate_oracle_boundary(
        result, args.prescore_artifact, args.prescore_commitment
    )
    validate_prescore_case_binding(result, args.prescore_artifact)
    production_feedback_audit = audit_production_feedback(result)
    expected_visible_hashes = {
        case.get("case_id"): visible_contract_sha(case.get("contract"))
        for case in suite.get("cases", [])
        if isinstance(case, dict) and isinstance(case.get("case_id"), str)
        and isinstance(case.get("contract"), dict)
    }
    matrix = build_case_matrix(result, expected_count, expected_visible_hashes)
    suite_map = {case.get("case_id"): case.get("domain") for case in suite.get("cases", [])}
    matrix_map = {row["case_id"]: row["domain"] for row in matrix}
    if len(suite_map) != expected_count or suite_map != matrix_map:
        raise SystemExit("exact case_id/domain set differs between suite and result")
    computed = recompute(matrix)
    for balance_name in ("initial_call_order_balance", "branch_order_balance"):
        if not all(
            sorted(counts.values()) == [4, 4] and "UNKNOWN" not in counts
            for counts in computed[balance_name].values()
        ):
            raise SystemExit(f"{balance_name} is not 4/4 within every domain")
    reported_identity_violations = require_int(
        result.get("shared_initial_identity_violations"),
        "shared_initial_identity_violations",
    )
    if reported_identity_violations != computed["shared_initial_identity_violations"]:
        raise SystemExit("shared-initial identity accounting differs from case rows")
    reported_visible_violations = require_int(
        result.get("visible_input_identity_violations"),
        "visible_input_identity_violations",
    )
    if reported_visible_violations != computed["visible_input_identity_violations"]:
        raise SystemExit("visible-input identity accounting differs from suite-derived case hashes")
    raw_physical = physical_calls(result.get("physical_model_calls"), "evaluation")
    if raw_physical != computed["model_call_accounting"]["physical_model_calls"]:
        raise SystemExit("global physical call accounting differs from case rows")
    if result.get("attributed_logical_calls_by_condition") != computed["model_call_accounting"]["attributed_logical_calls_by_condition"]:
        raise SystemExit("global attributed logical-call accounting differs from case rows")
    assessment, checks = assessment_from(protocol, computed, True)

    source_paths = [
        args.suite, args.commitment, args.protocol, args.runner_source,
        args.gates_source, args.generator_source, args.prescore_commitment,
        Path(__file__).resolve(),
    ]
    hashes = {path.name: file_sha(path) for path in source_paths if path is not None}
    if args.runner_source is not None and runtime.get("evaluator_sha256") not in (None, file_sha(args.runner_source)):
        raise SystemExit("executed evaluator hash differs from collected runner")
    if args.gates_source is not None and runtime.get("production_gates_sha256") not in (None, file_sha(args.gates_source)):
        raise SystemExit("executed production-gates hash differs from collected source")
    hardware = public_hardware(args.hardware_evidence)
    execution = public_execution(result, args.execution_metadata)
    if commitment.get("protocol_commit") != execution["execution_code_commit"]:
        raise SystemExit("suite commitment protocol_commit differs from the runtime package commitment")
    if execution["metadata"] is not None:
        metadata = execution["metadata"]
        declared_hashes = metadata.get("files_sha256", {})
        expected_hashes = {
            "suite": file_sha(args.suite),
            "protocol": file_sha(args.protocol),
            "runner": file_sha(args.runner_source) if args.runner_source else None,
            "production_gates": file_sha(args.gates_source) if args.gates_source else None,
        }
        if declared_hashes != expected_hashes:
            raise SystemExit("execution metadata source hashes differ from collected sources")
        if metadata.get("model_alias") != runtime.get("model_alias") or metadata.get("model_artifact_id") != runtime.get("model_artifact_id"):
            raise SystemExit("execution metadata model declaration differs from runtime result")
    public = {
        "schema_version": "hpadmin-comparative-public-evidence/3.0",
        "assessment": assessment,
        "assessment_checks": checks,
        "aggregate_derivation": "RECOMPUTED_FROM_RAW_CASES_SUMMARY_IGNORED",
        "scoring_reproducibility": {
            "case_pass_labels_source": "PRIVATE_POST_COMMIT_SCORER",
            "proposals_published": False,
            "independent_offline_rescoring_supported": False,
            "postscore_inference_owned_fields_match_prescore_commitment": True,
            "public_verifier_scope": "AGGREGATES_AND_EXACT_PVALUES_FROM_COMMITTED_CASE_LABELS",
        },
        "evaluation_id": result.get("evaluation_id"),
        "suite": {
            "suite_id": result.get("suite_id"), "suite_sha256": suite_sha, "case_count": expected_count,
            "domain_counts": dict(sorted(Counter(row["domain"] for row in matrix).items())),
            "commitment_id": commitment.get("commitment_id"), "commitment_sha256": canonical_sha(commitment),
            "frozen_at": commitment.get("frozen_at"),
            "post_publication_status": "RETIRED_PUBLIC_SUITE_DO_NOT_REUSE_AS_CONFIRMATORY_HOLDOUT",
        },
        "protocol": {
            "protocol_id": protocol.get("protocol_id"), "protocol_sha256": canonical_sha(protocol),
            "primary_comparison": protocol.get("analysis_plan", {}).get("primary_comparison"),
            "secondary_comparisons": protocol.get("analysis_plan", {}).get("secondary_comparisons"),
            "latency_role": protocol.get("analysis_plan", {}).get("latency"),
        },
        "model": {
            "adapter": runtime.get("adapter"), "hermes_dohaa_version": runtime.get("hermes_dohaa_version"),
            "model_alias": runtime.get("model_alias"), "model_artifact_id": runtime.get("model_artifact_id"),
            "model_artifact_status": "OPERATOR_DECLARED_NOT_INDEPENDENTLY_ATTESTED",
            "local_endpoint_status": "OPERATOR_OBSERVED_NOT_INDEPENDENTLY_ATTESTED_BY_RENDERER",
            "condition_reasoning_effort_requested": runtime.get("condition_reasoning_effort"),
            "condition_reasoning_configuration_status": "REQUESTED_CONFIGURED_NOT_INDEPENDENTLY_ATTESTED_FOR_ALL_CONDITIONS",
            "condition_reasoning_verified": {condition: False for condition in CONDITIONS},
            "native_reasoning_status": "REQUESTED_AND_CONFIGURED_NOT_INDEPENDENTLY_ATTESTED",
            "native_reasoning_verified": False, "temperature": runtime.get("temperature"),
            "top_p": runtime.get("top_p"), "sampling_seed": runtime.get("sampling_seed"),
        },
        "execution": {
            "started_at": result.get("started_at"), "completed_at": result.get("completed_at"),
            "elapsed_seconds": duration_seconds(result.get("started_at"), result.get("completed_at")),
            "condition_order_seed": result.get("seed"), "repetitions": result.get("repetitions"),
            "timeout_seconds_per_request": runtime.get("timeout_seconds_per_request"),
            "maximum_transport_retries_per_logical_call": runtime.get("maximum_transport_retries_per_logical_call"),
            "retryable_codes": runtime.get("retryable_codes"),
            "redirects_allowed": runtime.get("redirects_allowed"),
            "proxy_environment_used": runtime.get("proxy_environment_used"),
            **execution,
        },
        "oracle_boundary": oracle_boundary,
        "production_feedback_audit": production_feedback_audit,
        "conditions": computed["conditions"], "comparisons": computed["comparisons"],
        "domain_summary": computed["domain_summary"], "runtime_failure_counts": computed["runtime_failure_counts"],
        "model_call_accounting": computed["model_call_accounting"], "case_matrix": matrix,
        "branch_order_balance": computed["branch_order_balance"],
        "initial_call_order_balance": computed["initial_call_order_balance"],
        "shared_initial_identity_violations": computed["shared_initial_identity_violations"],
        "visible_input_identity_violations": computed["visible_input_identity_violations"],
        "hardware": hardware,
        "prior_evidence": {
            "v2_status": "INVALIDATED_DEVELOPMENT_EVIDENCE", "v2_primary_claim_valid": False,
            "reason": "Six of eight reported V2 DOHAA wins depended on oracle-only retry feedback.",
            "included_in_v3_analysis": False,
        },
        "safety": {
            "synthetic_data_only": True, "side_effects": "NONE", "payment_execution": "DISABLED",
            "bank_access": "DISABLED", "email_sending": "DISABLED", "original_modification": "DISABLED",
            "human_authority_retained": True,
        },
        "source_hashes": {
            "raw_result_sha256": file_sha(args.result), "public_files": hashes,
            "evaluator_sha256_reported_by_runtime": runtime.get("evaluator_sha256"),
            "production_gates_sha256_reported_by_runtime": runtime.get("production_gates_sha256"),
        },
        "claim_boundary": protocol.get("claim_boundary"),
        "system_interpretation": {
            "dohaa_system": "LLM + deployable deterministic policy validator + bounded repair",
            "abstract_reasoning_attribution_supported": False,
            "comparison_against_standalone_policy_engine": False,
            "task_design_scope": "New instances of five frozen administrative schemas; not wholly new task designs.",
        },
    }
    evidence_path = args.output_dir / "PUBLIC-HPADMIN-COMPARATIVE-EVIDENCE-v3.json"
    evidence_path.write_text(json.dumps(public, ensure_ascii=False, sort_keys=True, indent=2) + "\n", encoding="utf-8")

    labels = {
        "direct": "Direct", "native_reasoning_requested": "Razonamiento solicitado (high; no atestado)",
        "self_reflection": "Self-reflection", "dohaa": "DOHAA",
    }
    primary = computed["comparisons"]["dohaa_vs_direct"]
    lines = [
        "# HPADMIN V3: comparación local controlada", "",
        f"**Resultado según criterios preregistrados:** `{assessment}`", "",
        "Los agregados y valores p fueron recalculados desde las etiquetas `pass` de la matriz caso por caso; no se utilizó el resumen privado. Como las propuestas no se publican, el bundle verifica compromisos y recomputa estadísticas, pero no re-puntúa independientemente cada propuesta.", "",
        "| Condición | Aciertos estrictos | Tasa | Fallos runtime | Llamadas atribuidas medias | Reintentos |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for name in CONDITIONS:
        row = computed["conditions"][name]
        lines.append(f"| {labels[name]} | {row['final_passes']}/{expected_count} | {100 * row['final_pass_rate']:.2f}% | {row['runtime_failures']} | {row['average_attributed_logical_model_calls']:.3g} | {row['total_transport_retries']} |")
    secondary_lines = []
    for name, _, _ in PAIRINGS[1:]:
        pair = computed["comparisons"][name]
        secondary_lines.append(
            f"- `{name}`: W={pair['wins']}, L={pair['losses']}, "
            f"empates={pair['ties']} (ambos pasan={pair['both_pass_ties']}, ambos fallan={pair['both_fail_ties']}), "
            f"p={pair['exact_two_sided_sign_test_p']:.12g}."
        )
    lines += [
        "", "## Comparación primaria", "",
        f"DOHAA vs Direct: **{primary['wins']} victorias, {primary['losses']} derrotas y {primary['ties']} empates** (ambos pasan={primary['both_pass_ties']}, ambos fallan={primary['both_fail_ties']}); p exacta bilateral={primary['exact_two_sided_sign_test_p']:.12g}.",
        "La p exacta es una regla de decisión prerregistrada sobre esta suite fija; no implica muestreo poblacional, independencia entre casos ni generalización fuera de la suite.",
        "", "## Comparaciones secundarias", "", *secondary_lines,
        "", "## Cómputo físico y atribuido", "",
        f"Solicitudes físicas globales: **{computed['model_call_accounting']['physical_model_calls']['total']}**. Llamadas lógicas atribuidas: **{computed['model_call_accounting']['attributed_logical_calls_total']}**. La inferencia inicial compartida reduce cómputo físico; no se cuenta como ventaja semántica.",
        "", "## Balance del orden de ramas", "",
        "Cada dominio conserva balance 4/4 tanto para el orden de llamadas iniciales como para el orden de refinamiento Self-reflection/DOHAA. El detalle recomputable está en `initial_call_order_balance`, `branch_order_balance` y la matriz.",
        f"La identidad del input visible se recalculó contra el contrato canónico de la suite para las cuatro condiciones; violaciones={computed['visible_input_identity_violations']}.",
        "", "## Frontera del oráculo", "",
        f"El output previo al scoring quedó comprometido con SHA-256 `{oracle_boundary['prescore_output_sha256']}`. Después se cargó el oráculo para puntuar. `oracle_feedback_events=0`; el controlador no accedió al resultado esperado ni a `result_equals`.",
        f"Se auditaron {production_feedback_audit['feedback_events_audited']} eventos de feedback DOHAA: todos provinieron de la allowlist exacta de compuertas de producción; eventos prohibidos=0. `semantic_assertions` fue exclusivo del scorer y nunca estuvo disponible al controlador.",
        "", "## Invalidez de V2", "",
        "V2 queda como evidencia de desarrollo invalidada para su afirmación primaria: seis de sus ocho victorias DOHAA dependieron de feedback exclusivo del oráculo. No participa en V3.",
        "", "## Razonamiento nativo", "",
        "`high` fue solicitado y configurado, pero no existe telemetría independiente que pruebe su activación interna: se rotula **solicitado, no atestado**.",
        "De igual modo, `none` en Direct, Self-reflection y DOHAA describe la configuración solicitada; este bundle no atesta independientemente el estado interno de razonamiento de ninguna de las cuatro condiciones.",
        "El identificador del artefacto del modelo también es declarado por el operador y no está independientemente atestado por este bundle.",
        "El endpoint local fue observado por el operador; el renderer no lo atesta independientemente. Durante la ejecución se exigieron `redirects_allowed=false` y `proxy_environment_used=false`; la atestación pública complementaria verifica la observación local sin convertirla en una prueba externa independiente.",
        "", "## Hardware", "",
    ]
    if hardware["status"] == "UNKNOWN":
        lines.append("`UNKNOWN`: no se aportó evidencia sanitizada. Este bundle no demuestra por sí solo operación sobre hardware accesible.")
    else:
        lines.append("Se incluyó evidencia sanitizada de la configuración observada; la asequibilidad solo se afirma si su campo explícito es verdadero.")
    lines += [
        "", "## Alcance de la afirmación", "",
        "DOHAA se evalúa aquí como sistema completo: LLM + validador determinístico de políticas desplegable + reparación acotada. Un PASS solo respalda esta comparación preregistrada sobre la suite sintética, el modelo declarado y esta ejecución. Los presupuestos de cómputo pueden diferir y se informan.", "",
        "No atribuye la mejora a razonamiento abstracto, no compara DOHAA contra un motor de políticas determinístico independiente y no demuestra superioridad universal, pagos autónomos seguros, rendimiento productivo ni reemplazo de autoridad humana.",
        "Los casos son instancias nuevas de cinco esquemas administrativos congelados; no son cinco diseños de tarea completamente nuevos.",
        "", "## Integridad", "",
        f"- Suite canónica SHA-256: `{suite_sha}`", f"- Resultado privado SHA-256: `{file_sha(args.result)}`",
        f"- Compromiso: `{commitment.get('commitment_id')}`", f"- Compromiso de código (SHA-256 del manifiesto del paquete): `{execution['execution_code_commit']}`. La cadena es verificable; no constituye por sí sola atestación independiente de ejecución.",
        "- El verificador enlaza las fuentes públicas ejecutables con el manifiesto original. La autenticidad posterior a la ejecución requiere publicar externamente, por un canal inmutable, el digest del bundle o del manifiesto.",
        "- La matriz pública omite propuestas, prompts, contratos, inputs y respuestas esperadas.",
    ]
    report_path = args.output_dir / "PUBLIC-HPADMIN-COMPARATIVE-REPORT-v3.md"
    report_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"ASSESSMENT={assessment}")
    print(f"PUBLIC_EVIDENCE={evidence_path}")
    print(f"PUBLIC_REPORT={report_path}")
    return 0


def verify_public(public_dir: Path) -> int:
    evidence_path = public_dir / "PUBLIC-HPADMIN-COMPARATIVE-EVIDENCE-v3.json"
    protocol_path = public_dir / "HPADMIN-COMPARATIVE-PROTOCOL-v3.json"
    suite_path = public_dir / "hpadmin-comparative-suite-v3.json"
    commitment_path = public_dir / "hpadmin-comparative-suite-v3.commitment.json"
    for path in (evidence_path, protocol_path, suite_path, commitment_path):
        if not path.is_file():
            raise SystemExit(f"missing public verification input: {path.name}")
    evidence, protocol = read_json(evidence_path), read_json(protocol_path)
    suite, commitment = read_json(suite_path), read_json(commitment_path)
    if evidence.get("schema_version") != "hpadmin-comparative-public-evidence/3.0":
        raise SystemExit("unexpected public evidence schema")
    validate_protocol_contract(protocol)
    expected_scoring_boundary = {
        "case_pass_labels_source": "PRIVATE_POST_COMMIT_SCORER",
        "proposals_published": False,
        "independent_offline_rescoring_supported": False,
        "postscore_inference_owned_fields_match_prescore_commitment": True,
        "public_verifier_scope": "AGGREGATES_AND_EXACT_PVALUES_FROM_COMMITTED_CASE_LABELS",
    }
    if evidence.get("scoring_reproducibility") != expected_scoring_boundary:
        raise SystemExit("public scoring/recomputation boundary is missing or changed")
    matrix = evidence.get("case_matrix")
    if not isinstance(matrix, list):
        raise SystemExit("public case_matrix missing")
    allowed_row = {
        "case_id", "domain", "execution_order", "branch_order", "shared_initial_identity_verified",
        "shared_initial_proposal_sha256", "physical_model_calls", "conditions",
        "visible_input_sha256", "condition_visible_input_sha256", "visible_input_identity_verified",
    }
    allowed_cell = {
        "status", "pass", "attributed_logical_calls", "transport_request_attempts", "transport_retries",
        "recovered_logical_calls", "recovered_after_retry", "error_code", "improved", "regressed", "failed_production_gates",
        "elapsed_seconds", "reported_total_tokens", "usage_complete",
        "initial_proposal_sha256",
        "visible_input_sha256",
    }
    expected_visible_hashes = {
        case.get("case_id"): visible_contract_sha(case.get("contract"))
        for case in suite.get("cases", [])
        if isinstance(case, dict) and isinstance(case.get("case_id"), str)
        and isinstance(case.get("contract"), dict)
    }
    for row in matrix:
        if set(row) != allowed_row or set(row.get("conditions", {})) != set(CONDITIONS):
            raise SystemExit("case matrix contains unexpected keys or conditions")
        if not isinstance(row.get("case_id"), str) or not row["case_id"] or not isinstance(row.get("domain"), str) or not row["domain"]:
            raise SystemExit("invalid case identity in public matrix")
        if not isinstance(row.get("shared_initial_identity_verified"), bool) or not isinstance(row.get("visible_input_identity_verified"), bool):
            raise SystemExit("identity flags must be booleans")
        if not isinstance(row["branch_order"], list) or len(row["branch_order"]) != 2 or set(row["branch_order"]) != {"self_reflection", "dohaa"}:
            raise SystemExit("invalid branch order in public matrix")
        if not isinstance(row["execution_order"], list) or len(row["execution_order"]) != 2 or set(row["execution_order"]) != {"shared_reasoning_off_base", "native_reasoning_requested"}:
            raise SystemExit("invalid initial-call order in public matrix")
        if physical_calls(row.get("physical_model_calls"), row["case_id"]) != row.get("physical_model_calls"):
            raise SystemExit("public physical-call counters are invalid or non-canonical")
        shared_hash = row.get("shared_initial_proposal_sha256")
        if shared_hash is not None and SHA256_RE.fullmatch(str(shared_hash)) is None:
            raise SystemExit("invalid shared initial proposal hash")
        recomputed_identity = shared_hash is not None and all(
            row["conditions"][name].get("initial_proposal_sha256") == shared_hash
            for name in ("direct", "self_reflection", "dohaa")
        )
        if row.get("shared_initial_identity_verified") is not recomputed_identity:
            raise SystemExit("shared initial identity flag is not reproduced by hashes")
        expected_visible = expected_visible_hashes.get(row.get("case_id"))
        visible_hashes = row.get("condition_visible_input_sha256")
        if not isinstance(expected_visible, str) or not isinstance(visible_hashes, dict) or set(visible_hashes) != set(CONDITIONS):
            raise SystemExit("visible-input identity data is missing")
        recomputed_visible_identity = row.get("visible_input_sha256") == expected_visible and all(
            visible_hashes[name] == expected_visible
            and row["conditions"][name].get("visible_input_sha256") == expected_visible
            for name in CONDITIONS
        )
        if row.get("visible_input_identity_verified") is not recomputed_visible_identity:
            raise SystemExit("visible-input identity flag is not reproduced from suite contracts")
        for cell in row["conditions"].values():
            if set(cell) != allowed_cell:
                raise SystemExit("case matrix contains non-whitelisted fields")
            if cell.get("status") not in {"completed", "runtime_failed"}:
                raise SystemExit("invalid public outcome status")
            for boolean_key in ("pass", "recovered_after_retry", "improved", "regressed", "usage_complete"):
                if not isinstance(cell.get(boolean_key), bool):
                    raise SystemExit(f"public outcome {boolean_key} must be boolean")
            calls = require_int(cell.get("attributed_logical_calls"), "public.attributed_logical_calls")
            attempts = require_int(cell.get("transport_request_attempts"), "public.transport_request_attempts")
            require_int(cell.get("transport_retries"), "public.transport_retries")
            recovered_calls = require_int(cell.get("recovered_logical_calls"), "public.recovered_logical_calls")
            if attempts != calls + cell["transport_retries"] or recovered_calls > cell["transport_retries"]:
                raise SystemExit("public request/retry/recovery accounting is inconsistent")
            if cell.get("recovered_after_retry") is not (recovered_calls > 0):
                raise SystemExit("public transport accounting is inconsistent")
            if cell["status"] == "runtime_failed" and cell["pass"] is not False:
                raise SystemExit("runtime-failed outcomes cannot pass")
            elapsed = cell.get("elapsed_seconds")
            if isinstance(elapsed, bool) or not isinstance(elapsed, (int, float)) or not math.isfinite(float(elapsed)) or elapsed < 0:
                raise SystemExit("invalid public elapsed time")
            tokens = cell.get("reported_total_tokens")
            if tokens is not None:
                require_int(tokens, "public.reported_total_tokens")
            if cell.get("error_code") is not None and not isinstance(cell.get("error_code"), str):
                raise SystemExit("invalid public error code")
            failed_gates = cell.get("failed_production_gates")
            if not isinstance(failed_gates, list) or any(not isinstance(name, str) or not name for name in failed_gates) or len(failed_gates) != len(set(failed_gates)):
                raise SystemExit("invalid failed-production-gate list")
            initial_hash = cell.get("initial_proposal_sha256")
            if initial_hash is not None and SHA256_RE.fullmatch(str(initial_hash)) is None:
                raise SystemExit("invalid initial proposal hash in public matrix")
            if any(any(token in str(name).lower() for token in ORACLE_GATE_TOKENS) for name in cell["failed_production_gates"]):
                raise SystemExit("oracle/scoring gate leaked into production-gate matrix")
    computed = recompute(matrix)
    for balance_name in ("initial_call_order_balance", "branch_order_balance"):
        if not all(
            sorted(counts.values()) == [4, 4] and "UNKNOWN" not in counts
            for counts in computed[balance_name].values()
        ):
            raise SystemExit(f"public {balance_name} is not 4/4 within every domain")
    for key in (
        "conditions", "comparisons", "domain_summary", "runtime_failure_counts",
        "model_call_accounting", "branch_order_balance", "initial_call_order_balance",
        "shared_initial_identity_violations",
        "visible_input_identity_violations",
    ):
        if evidence.get(key) != computed[key]:
            raise SystemExit(f"public matrix does not reproduce {key}")
    oracle = evidence.get("oracle_boundary", {})
    if oracle.get("oracle_feedback_events") != 0 or oracle.get("verified_from_raw_cases") is not True:
        raise SystemExit("oracle feedback zero is not verified")
    if oracle.get("oracle_loaded_after_prescore_commit") is not True or SHA256_RE.fullmatch(str(oracle.get("prescore_output_sha256", ""))) is None:
        raise SystemExit("pre-score commitment/oracle loading order is not verified")
    if oracle.get("semantic_assertions_available_during_inference") is not False:
        raise SystemExit("semantic assertions cannot be available during inference")
    if oracle.get("semantic_assertions_loaded_only_by_scorer") is not True:
        raise SystemExit("semantic assertions must be loaded only by the scorer")
    if oracle.get("prescore_digest_verification") not in {
        "RECOMPUTED_FROM_PRIVATE_PRESCORE_ARTIFACT",
        "RECOMPUTED_FROM_EMBEDDED_PRIVATE_PRESCORE_PAYLOAD",
    }:
        raise SystemExit("pre-score digest is only self-attested")
    feedback_audit = evidence.get("production_feedback_audit", {})
    if feedback_audit.get("status") != "VERIFIED_FROM_RAW_CONTROLLER_EVENTS":
        raise SystemExit("production feedback audit missing")
    if feedback_audit.get("forbidden_feedback_events") != 0:
        raise SystemExit("forbidden production feedback was reported")
    if set(feedback_audit.get("controller_gate_names", [])) != CONTROLLER_GATE_ALLOWLIST:
        raise SystemExit("public controller gate allowlist mismatch")
    if set(feedback_audit.get("scoring_gate_names", [])) != SCORING_GATE_ALLOWLIST:
        raise SystemExit("public scoring gate allowlist mismatch")
    if feedback_audit.get("semantic_assertions_controller_available") is not False:
        raise SystemExit("semantic assertions cannot be available to the controller")
    if feedback_audit.get("semantic_assertions_scoring_only") is not True:
        raise SystemExit("semantic assertions must remain scorer-only")
    manifest_path = public_dir / "hpadmin-comparative-prescore-v3.commitment.json"
    if not manifest_path.is_file() or file_sha(manifest_path) != oracle.get("prescore_commitment_manifest_sha256"):
        raise SystemExit("pre-score commitment manifest missing or mismatched")
    manifest = read_json(manifest_path)
    if manifest.get("prescore_canonical_sha256", manifest.get("canonical_sha256")) != oracle.get("prescore_output_sha256"):
        raise SystemExit("pre-score public commitment manifest canonical hash mismatch")
    if manifest.get("prescore_file_sha256", manifest.get("file_sha256")) != oracle.get("prescore_output_file_sha256"):
        raise SystemExit("pre-score public commitment manifest file hash mismatch")
    if oracle.get("prescore_output_canonical_sha256") != oracle.get("prescore_output_sha256"):
        raise SystemExit("pre-score canonical hash aliases differ")
    if SHA256_RE.fullmatch(str(oracle.get("prescore_output_file_sha256", ""))) is None:
        raise SystemExit("pre-score file hash is missing")
    if manifest.get("oracle_feedback_events") != 0:
        raise SystemExit("pre-score manifest reports oracle feedback")
    assessment, checks = assessment_from(protocol, computed, True)
    if evidence.get("assessment") != assessment or evidence.get("assessment_checks") != checks:
        raise SystemExit("matrix does not reproduce assessment")
    if canonical_sha(suite) != evidence.get("suite", {}).get("suite_sha256"):
        raise SystemExit("suite canonical hash mismatch")
    if canonical_sha(protocol) != evidence.get("protocol", {}).get("protocol_sha256"):
        raise SystemExit("protocol canonical hash mismatch")
    if canonical_sha(commitment) != evidence.get("suite", {}).get("commitment_sha256"):
        raise SystemExit("commitment canonical hash mismatch")
    suite_sha = canonical_sha(suite)
    suite_id = suite.get("suite_id")
    if commitment.get("suite_sha256") != suite_sha:
        raise SystemExit("commitment does not bind canonical suite")
    if manifest.get("suite_commitment_sha256") != canonical_sha(commitment):
        raise SystemExit("pre-score manifest does not bind the suite commitment")
    if not suite_id or commitment.get("suite_id") != suite_id:
        raise SystemExit("commitment suite ID mismatch")
    if protocol.get("suite_policy", {}).get("suite_id") != suite_id:
        raise SystemExit("protocol suite ID mismatch")
    if evidence.get("suite", {}).get("suite_id") != suite_id:
        raise SystemExit("evidence suite ID mismatch")
    if evidence.get("suite", {}).get("commitment_id") != commitment.get("commitment_id"):
        raise SystemExit("evidence commitment ID mismatch")
    suite_map = {case.get("case_id"): case.get("domain") for case in suite.get("cases", [])}
    matrix_map = {row.get("case_id"): row.get("domain") for row in matrix}
    if len(suite_map) != len(matrix) or suite_map != matrix_map:
        raise SystemExit("public matrix case_id/domain set differs from suite")
    execution_policy = protocol.get("execution_policy", {})
    model_policy = protocol.get("model_policy", {})
    public_execution = evidence.get("execution", {})
    public_model = evidence.get("model", {})
    public_policy_pairs = (
        (public_execution.get("condition_order_seed"), execution_policy.get("condition_order_seed")),
        (public_execution.get("repetitions"), execution_policy.get("confirmatory_runs")),
        (public_execution.get("timeout_seconds_per_request"), execution_policy.get("timeout_seconds_per_request")),
        (public_model.get("temperature"), model_policy.get("temperature")),
        (public_model.get("top_p"), model_policy.get("top_p")),
        (public_model.get("sampling_seed"), execution_policy.get("sampling_seed")),
        (public_model.get("model_alias"), model_policy.get("default_model_alias")),
        (public_model.get("model_artifact_id"), model_policy.get("default_model_artifact_id")),
    )
    if any(observed != expected for observed, expected in public_policy_pairs):
        raise SystemExit("public runtime metadata differs from protocol")
    public_hashes = evidence.get("source_hashes", {}).get("public_files")
    if not isinstance(public_hashes, dict) or set(public_hashes) != REQUIRED_PUBLIC_SOURCE_FILES:
        raise SystemExit("public source-hash manifest is missing required files or has extras")
    for filename, expected in public_hashes.items():
        if not isinstance(filename, str) or Path(filename).name != filename:
            raise SystemExit("unsafe source-hash filename")
        if not isinstance(expected, str) or SHA256_RE.fullmatch(expected) is None:
            raise SystemExit(f"invalid source hash: {filename}")
        path = public_dir / filename
        if not path.is_file() or file_sha(path) != expected:
            raise SystemExit(f"source hash mismatch: {filename}")
    hardware = evidence.get("hardware", {})
    if hardware.get("status") == "UNKNOWN" and hardware.get("affordable_hardware_demonstrated") is not False:
        raise SystemExit("hardware affordability cannot be asserted with UNKNOWN evidence")
    if hardware.get("status") == "UNKNOWN" and hardware.get("cost_status") != "UNKNOWN":
        raise SystemExit("hardware cost cannot be asserted with UNKNOWN evidence")
    if hardware.get("status") == "SUPPLIED_SANITIZED_EVIDENCE":
        hardware_path = public_dir / "hardware-evidence-v3.json"
        if not hardware_path.is_file() or file_sha(hardware_path) != hardware.get("file_sha256"):
            raise SystemExit("hardware evidence file/hash mismatch")
        if hardware.get("affordable_hardware_demonstrated") is True and hardware.get("cost_status") == "UNKNOWN":
            raise SystemExit("hardware affordability cannot be asserted with UNKNOWN cost evidence")
    execution = evidence.get("execution", {})
    if execution.get("metadata_status") != "SUPPLIED_SANITIZED_EVIDENCE":
        raise SystemExit("execution metadata is required")
    if execution.get("redirects_allowed") is not False:
        raise SystemExit("public execution evidence must prove redirects were disabled")
    if execution.get("proxy_environment_used") is not False:
        raise SystemExit("public execution evidence must prove proxy environment was not used")
    metadata_path = public_dir / "execution-metadata-v3.json"
    if not metadata_path.is_file() or file_sha(metadata_path) != execution.get("metadata_file_sha256"):
        raise SystemExit("execution metadata file/hash mismatch")
    metadata = read_json(metadata_path)
    expected_execution_hashes = {
        "suite": file_sha(suite_path),
        "protocol": file_sha(protocol_path),
        "runner": file_sha(public_dir / "run_hpadmin_comparative_v3.py"),
        "production_gates": file_sha(public_dir / "hpadmin_v3_gates.py"),
    }
    if metadata.get("files_sha256") != expected_execution_hashes:
        raise SystemExit("execution metadata does not bind public execution sources")
    original_manifest_path = public_dir / "PACKAGE-SHA256SUMS"
    if not original_manifest_path.is_file():
        raise SystemExit("original package manifest is missing")
    package_manifest_sha = file_sha(original_manifest_path)
    try:
        package_entries = parse_package_manifest(original_manifest_path)
    except ValueError as exc:
        raise SystemExit(str(exc)) from exc
    if not PACKAGE_MANIFEST_PUBLIC_BINDINGS.issubset(package_entries):
        missing = sorted(PACKAGE_MANIFEST_PUBLIC_BINDINGS - set(package_entries))
        raise SystemExit(f"package manifest does not cover required public execution sources: {missing}")
    for filename in sorted(PACKAGE_MANIFEST_PUBLIC_BINDINGS):
        public_source = public_dir / filename
        if not public_source.is_file() or file_sha(public_source) != package_entries[filename]:
            raise SystemExit(f"package-manifest source binding mismatch: {filename}")
    commitment_chain = (
        commitment.get("protocol_commit"),
        execution.get("execution_code_commit"),
        execution.get("package_manifest_sha256"),
        metadata.get("execution_code_commit"),
        metadata.get("package_manifest_sha256"),
        package_manifest_sha,
    )
    if any(value != package_manifest_sha for value in commitment_chain):
        raise SystemExit("suite/runtime/metadata/package-manifest commitment chain mismatch")
    if metadata.get("execution_code_commit_kind") != "package_manifest_sha256" or execution.get("execution_code_commit_kind") != "package_manifest_sha256":
        raise SystemExit("execution commitment kind mismatch")
    if metadata.get("native_reasoning") != {
        "request": "high",
        "public_label": "native_reasoning_requested",
        "attestation_status": "requested_configured_not_attested",
    }:
        raise SystemExit("native-reasoning metadata boundary mismatch")
    if metadata.get("model_artifact_attestation_status") != "operator_declared_not_attested":
        raise SystemExit("model artifact attestation was overstated")
    if execution.get("execution_code_commit_status") != "PACKAGE_MANIFEST_SHA256_CHAIN_VERIFIED_EXECUTION_NOT_INDEPENDENTLY_ATTESTED":
        raise SystemExit("execution commit attestation boundary changed")
    if evidence.get("model", {}).get("native_reasoning_verified") is not False:
        raise SystemExit("native reasoning must remain requested/unattested without telemetry")
    if evidence.get("model", {}).get("native_reasoning_status") != "REQUESTED_AND_CONFIGURED_NOT_INDEPENDENTLY_ATTESTED":
        raise SystemExit("native reasoning status is missing or overstated")
    if evidence.get("model", {}).get("condition_reasoning_configuration_status") != "REQUESTED_CONFIGURED_NOT_INDEPENDENTLY_ATTESTED_FOR_ALL_CONDITIONS":
        raise SystemExit("all-condition reasoning configuration boundary is missing or overstated")
    if evidence.get("model", {}).get("condition_reasoning_verified") != {condition: False for condition in CONDITIONS}:
        raise SystemExit("reasoning cannot be marked verified for any condition")
    if evidence.get("model", {}).get("model_artifact_status") != "OPERATOR_DECLARED_NOT_INDEPENDENTLY_ATTESTED":
        raise SystemExit("model artifact status is missing or overstated")
    if evidence.get("model", {}).get("local_endpoint_status") != "OPERATOR_OBSERVED_NOT_INDEPENDENTLY_ATTESTED_BY_RENDERER":
        raise SystemExit("local endpoint observation boundary is missing or overstated")
    prior = evidence.get("prior_evidence", {})
    if prior.get("v2_status") != "INVALIDATED_DEVELOPMENT_EVIDENCE" or prior.get("v2_primary_claim_valid") is not False:
        raise SystemExit("V2 invalidation disclosure is missing or changed")
    print("HPADMIN_COMPARATIVE_PUBLIC_V3=AGGREGATES_RECOMPUTED_AND_COMMITMENTS_VERIFIED")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-public-dir", type=Path)
    parser.add_argument("--result", type=Path)
    parser.add_argument("--suite", type=Path)
    parser.add_argument("--commitment", type=Path)
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--runner-source", type=Path)
    parser.add_argument("--gates-source", type=Path)
    parser.add_argument("--generator-source", type=Path)
    parser.add_argument("--execution-metadata", type=Path)
    parser.add_argument("--hardware-evidence", type=Path)
    parser.add_argument("--prescore-artifact", type=Path)
    parser.add_argument("--prescore-commitment", type=Path)
    args = parser.parse_args()
    if args.verify_public_dir is not None:
        return verify_public(args.verify_public_dir)
    if args.output_dir is None:
        parser.error("--output-dir is required when rendering")
    return render(args)


if __name__ == "__main__":
    raise SystemExit(main())
