#!/usr/bin/env python3
import hashlib, json, re
from pathlib import Path
root = Path(__file__).resolve().parent
read = lambda name: json.loads((root / name).read_text(encoding="utf-8"))
sha = lambda name: hashlib.sha256((root / name).read_bytes()).hexdigest()
metadata = read("execution-metadata-v3.json")
model = read("model-evidence-v3.json")
imports = read("upstream-import-evidence-v3.json")
commitment = read("hpadmin-comparative-suite-v3.commitment.json")
package = sha("PACKAGE-SHA256SUMS")
assert metadata["execution_code_commit_kind"] == "package_manifest_sha256"
assert metadata["execution_code_commit"] == metadata["package_manifest_sha256"] == package
assert commitment["protocol_commit"] == package
assert metadata["model_observation_sha256"] == sha("model-evidence-v3.json")
assert metadata["upstream_import_evidence_sha256"] == sha("upstream-import-evidence-v3.json")
assert model["endpoint_scope"] == "LOCAL_ONLY_VALIDATED" and model["discovery_redirects_allowed"] is False and model["proxy_environment_used"] is False
assert model["instance_id"] == metadata["model_alias"]
assert imports["package_manifest_sha256"] == package and imports["tracked_worktree_clean"] is True
assert imports["upstream_commit"] == metadata["upstream_commit"]
assert imports["deployed_runner_sha256"] == sha("run_hpadmin_comparative_v3.py")
assert imports["deployed_gates_sha256"] == sha("hpadmin_v3_gates.py")
assert imports["import_root"] == "src/hermes_dohaa"
assert imports["imported_tracked_sources_sha256"]
assert all(not Path(name).is_absolute() and ".." not in Path(name).parts for name in imports["imported_tracked_sources_sha256"])
assert all(re.fullmatch(r"[0-9a-f]{64}", value) for value in imports["imported_tracked_sources_sha256"].values())
print("HPADMIN_COMPARATIVE_PUBLIC_ATTESTATIONS_V3=VERIFIED")
