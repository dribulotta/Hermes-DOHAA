# HPADMIN Comparative V3 — public review bundle

This sanitized bundle publishes a case-by-condition matrix and enough code and commitments to recompute every aggregate and exact paired sign test. It also binds the package manifest, imported tracked upstream sources, and a redirect-free local-endpoint model observation.

Run the offline verifier:

    bash verify-public-evidence-v3.sh

The V2 primary claim is invalidated development evidence and is not included in V3. Native reasoning is labeled requested/configured, not independently attested. Hardware and cost remain UNKNOWN unless a sanitized evidence file is included. The now-public suite is retired and must never be reused as a confirmatory holdout.
