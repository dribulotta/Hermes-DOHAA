#!/usr/bin/env python3
"""Production-real assurance gates for the HPADMIN V3 comparison.

The policy expectation in this module is derived only from ``TaskContract``
inputs that are visible to every experimental arm.  The protected evaluation
oracle is deliberately not part of this module's API or state.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any, Mapping, Sequence

from hermes_dohaa.assurance.gates import (
    ActionPolicyGate,
    ClaimEvidenceGate,
    Gate,
    GateFailureCode,
    GateResult,
    RequiredEvidenceGate,
    ResultSpecGate,
    SemanticAssertionsGate,
)
from hermes_dohaa.contracts.models import TaskContract
from hermes_dohaa.runtime.base import Proposal


SUPPORTED_DOMAINS = frozenset(
    {
        "invoice_reconciliation",
        "payment_schedule",
        "budget_reconciliation",
        "procurement_selection",
        "exception_triage",
    }
)

POLICY_MISMATCH_CODE = "hpadmin.production_policy_mismatch"


class ProductionPolicyInputError(ValueError):
    """Raised when visible policy inputs cannot produce a safe verdict."""


def _mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ProductionPolicyInputError(f"{label} must be an object")
    return value


def _sequence(value: Any, label: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ProductionPolicyInputError(f"{label} must be a list")
    return value


def _integer(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ProductionPolicyInputError(f"{label} must be an integer")
    return value


def _boolean(value: Any, label: str) -> bool:
    if not isinstance(value, bool):
        raise ProductionPolicyInputError(f"{label} must be a boolean")
    return value


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ProductionPolicyInputError(f"{label} must be non-empty text")
    return value.strip()


def _text_set(value: Any, label: str) -> set[str]:
    items = _sequence(value, label)
    output = {_text(item, f"{label} item") for item in items}
    if len(output) != len(items):
        raise ProductionPolicyInputError(f"{label} contains duplicates")
    return output


def _control(inputs: Mapping[str, Any]) -> tuple[bool, bool]:
    control = _mapping(inputs.get("control"), "inputs.control")
    return (
        _boolean(control.get("execution_enabled"), "control.execution_enabled"),
        _boolean(
            control.get("requires_human_approval"),
            "control.requires_human_approval",
        ),
    )


def _add_business_days(start: str, days: int, holidays: Sequence[Any]) -> str:
    try:
        current = date.fromisoformat(start)
        blocked = {date.fromisoformat(_text(item, "holiday")) for item in holidays}
    except ValueError as exc:
        raise ProductionPolicyInputError(f"invalid ISO calendar date: {exc}") from exc
    direction = 1 if days >= 0 else -1
    remaining = abs(days)
    while remaining:
        current += timedelta(days=direction)
        if current.weekday() < 5 and current not in blocked:
            remaining -= 1
    return current.isoformat()


def _invoice_expectation(inputs: Mapping[str, Any]) -> dict[str, Any]:
    lines = [
        _integer(value, "line_net_amounts_minor item")
        for value in _sequence(
            inputs.get("line_net_amounts_minor"),
            "inputs.line_net_amounts_minor",
        )
    ]
    taxes = [
        _integer(value, "tax_components_minor item")
        for value in _sequence(
            inputs.get("tax_components_minor"),
            "inputs.tax_components_minor",
        )
    ]
    if not lines:
        raise ProductionPolicyInputError("line_net_amounts_minor cannot be empty")
    subtotal = sum(lines)
    tax_total = sum(taxes)
    payable = (
        subtotal
        + tax_total
        - _integer(inputs.get("withholding_minor"), "inputs.withholding_minor")
        - _integer(inputs.get("prepaid_minor"), "inputs.prepaid_minor")
    )
    declared_subtotal = _integer(
        inputs.get("declared_subtotal_minor"),
        "inputs.declared_subtotal_minor",
    )
    declared_payable = _integer(
        inputs.get("declared_payable_minor"),
        "inputs.declared_payable_minor",
    )
    supplier_status = _text(inputs.get("supplier_status"), "inputs.supplier_status")
    duplicate = _boolean(
        inputs.get("duplicate_detected"),
        "inputs.duplicate_detected",
    )
    if supplier_status == "BLOCKED":
        decision, reason = "REJECTED", "SUPPLIER_BLOCKED"
    elif duplicate:
        decision, reason = "REJECTED", "DUPLICATE_INVOICE"
    elif declared_subtotal != subtotal:
        decision, reason = "REVIEW_REQUIRED", "SUBTOTAL_MISMATCH"
    elif declared_payable != payable:
        decision, reason = "REVIEW_REQUIRED", "TOTAL_MISMATCH"
    else:
        decision, reason = "VALID", "MATCHED"
    execution_enabled, human_approval = _control(inputs)
    return {
        "computed_subtotal_minor": subtotal,
        "computed_tax_minor": tax_total,
        "computed_payable_minor": payable,
        "decision": decision,
        "reason_code": reason,
        "execution_enabled": execution_enabled,
        "requires_human_approval": human_approval,
    }


def _schedule_expectation(inputs: Mapping[str, Any]) -> dict[str, Any]:
    start = _text(inputs.get("start_date"), "inputs.start_date")
    terms = _integer(
        inputs.get("terms_business_days"),
        "inputs.terms_business_days",
    )
    lead = _integer(
        inputs.get("approval_lead_business_days"),
        "inputs.approval_lead_business_days",
    )
    if terms < 0 or lead < 0:
        raise ProductionPolicyInputError("business-day terms and lead must be non-negative")
    holidays = _sequence(inputs.get("holidays"), "inputs.holidays")
    review_date = _add_business_days(start, terms, holidays)
    approval_deadline = _add_business_days(review_date, -lead, holidays)
    hold = _boolean(inputs.get("compliance_hold"), "inputs.compliance_hold")
    amount = _integer(inputs.get("amount_minor"), "inputs.amount_minor")
    threshold = _integer(
        inputs.get("approval_threshold_minor"),
        "inputs.approval_threshold_minor",
    )
    if hold:
        status, reason = "REVIEW_REQUIRED", "COMPLIANCE_HOLD"
    elif amount > threshold:
        status, reason = "REVIEW_REQUIRED", "AMOUNT_ABOVE_THRESHOLD"
    else:
        status, reason = "SCHEDULED_FOR_REVIEW", "READY_FOR_REVIEW"
    execution_enabled, human_approval = _control(inputs)
    return {
        "scheduled_review_date": review_date,
        "approval_deadline": approval_deadline,
        "status": status,
        "reason_code": reason,
        "execution_enabled": execution_enabled,
        "requires_human_approval": human_approval,
    }


def _budget_expectation(inputs: Mapping[str, Any]) -> dict[str, Any]:
    raw_centers = _sequence(inputs.get("cost_centers"), "inputs.cost_centers")
    if not raw_centers:
        raise ProductionPolicyInputError("cost_centers cannot be empty")
    centers: list[dict[str, Any]] = []
    identifiers: set[str] = set()
    for index, raw in enumerate(raw_centers):
        center = _mapping(raw, f"cost_centers[{index}]")
        center_id = _text(center.get("center_id"), f"cost_centers[{index}].center_id")
        if center_id in identifiers:
            raise ProductionPolicyInputError("cost center IDs must be unique")
        identifiers.add(center_id)
        centers.append(
            {
                "center_id": center_id,
                "approved_minor": _integer(
                    center.get("approved_minor"),
                    f"cost_centers[{index}].approved_minor",
                ),
                "spent_minor": _integer(
                    center.get("spent_minor"),
                    f"cost_centers[{index}].spent_minor",
                ),
                "committed_minor": _integer(
                    center.get("committed_minor"),
                    f"cost_centers[{index}].committed_minor",
                ),
                "reserve_minor": _integer(
                    center.get("reserve_minor"),
                    f"cost_centers[{index}].reserve_minor",
                ),
            }
        )
    approved = sum(item["approved_minor"] for item in centers)
    obligated = sum(
        item["spent_minor"] + item["committed_minor"] + item["reserve_minor"]
        for item in centers
    )
    available = approved - obligated
    largest = max(
        enumerate(centers),
        key=lambda pair: (pair[1]["committed_minor"], -pair[0]),
    )[1]["center_id"]
    any_negative = any(
        item["approved_minor"]
        - item["spent_minor"]
        - item["committed_minor"]
        - item["reserve_minor"]
        < 0
        for item in centers
    )
    floor = _integer(
        inputs.get("global_reserve_floor_minor"),
        "inputs.global_reserve_floor_minor",
    )
    if any_negative:
        status, reason = "REVIEW_REQUIRED", "COST_CENTER_OVERCOMMITTED"
    elif available < floor:
        status, reason = "REVIEW_REQUIRED", "RESERVE_FLOOR_BREACHED"
    else:
        status, reason = "RECONCILED", "WITHIN_BUDGET"
    execution_enabled, human_approval = _control(inputs)
    return {
        "total_approved_minor": approved,
        "total_obligated_minor": obligated,
        "total_available_minor": available,
        "largest_commitment_center": largest,
        "status": status,
        "reason_code": reason,
        "execution_enabled": execution_enabled,
        "requires_human_approval": human_approval,
    }


def _procurement_expectation(inputs: Mapping[str, Any]) -> dict[str, Any]:
    policy = _mapping(inputs.get("policy"), "inputs.policy")
    eligible_required = _boolean(
        policy.get("eligible_required"),
        "policy.eligible_required",
    )
    sanctions_required = _boolean(
        policy.get("sanctions_clear_required"),
        "policy.sanctions_clear_required",
    )
    maximum_risk = _integer(
        policy.get("maximum_risk_score"),
        "policy.maximum_risk_score",
    )
    maximum_delivery = _integer(
        policy.get("maximum_delivery_business_days"),
        "policy.maximum_delivery_business_days",
    )
    threshold = _integer(
        policy.get("human_approval_threshold_minor"),
        "policy.human_approval_threshold_minor",
    )
    bids = []
    identifiers: set[str] = set()
    for index, raw in enumerate(_sequence(inputs.get("bids"), "inputs.bids")):
        bid = _mapping(raw, f"bids[{index}]")
        vendor_id = _text(bid.get("vendor_id"), f"bids[{index}].vendor_id")
        if vendor_id in identifiers:
            raise ProductionPolicyInputError("vendor IDs must be unique")
        identifiers.add(vendor_id)
        bids.append(
            {
                "vendor_id": vendor_id,
                "eligible": _boolean(bid.get("eligible"), f"bids[{index}].eligible"),
                "sanctions_clear": _boolean(
                    bid.get("sanctions_clear"),
                    f"bids[{index}].sanctions_clear",
                ),
                "risk_score": _integer(bid.get("risk_score"), f"bids[{index}].risk_score"),
                "delivery_business_days": _integer(
                    bid.get("delivery_business_days"),
                    f"bids[{index}].delivery_business_days",
                ),
                "total_minor": _integer(bid.get("total_minor"), f"bids[{index}].total_minor"),
                "position": index,
            }
        )
    qualified = [
        bid
        for bid in bids
        if (not eligible_required or bid["eligible"])
        and (not sanctions_required or bid["sanctions_clear"])
        and bid["risk_score"] <= maximum_risk
        and bid["delivery_business_days"] <= maximum_delivery
    ]
    if not qualified:
        raise ProductionPolicyInputError("policy produces no qualified bid")
    selected = min(qualified, key=lambda bid: (bid["total_minor"], bid["position"]))
    if len(qualified) == 1:
        status, reason = "REVIEW_REQUIRED", "SINGLE_QUALIFIED_BID"
    elif selected["total_minor"] > threshold:
        status, reason = "REVIEW_REQUIRED", "AMOUNT_ABOVE_THRESHOLD"
    else:
        status, reason = "PROPOSAL_READY", "LOWEST_COMPLIANT_BID"
    execution_enabled, human_approval = _control(inputs)
    return {
        "qualified_bid_count": len(qualified),
        "selected_vendor_id": selected["vendor_id"],
        "selected_total_minor": selected["total_minor"],
        "status": status,
        "reason_code": reason,
        "execution_enabled": execution_enabled,
        "requires_human_approval": human_approval,
    }


def _exception_expectation(inputs: Mapping[str, Any]) -> dict[str, Any]:
    request = _mapping(inputs.get("request"), "inputs.request")
    policy = _mapping(inputs.get("policy"), "inputs.policy")
    action = _text(request.get("action"), "request.action")
    role = _text(request.get("requester_role"), "request.requester_role")
    classification = _text(
        request.get("data_classification"),
        "request.data_classification",
    )
    destination = _text(request.get("destination"), "request.destination")
    amount = _integer(request.get("amount_minor"), "request.amount_minor")
    forbidden = _text_set(policy.get("forbidden_actions"), "policy.forbidden_actions")
    approval_actions = _text_set(
        policy.get("approval_required_actions"),
        "policy.approval_required_actions",
    )
    allowed = _text_set(policy.get("allowed_actions"), "policy.allowed_actions")
    authorized_roles = _text_set(
        policy.get("authorized_roles"),
        "policy.authorized_roles",
    )
    egress_forbidden = _text_set(
        policy.get("external_egress_forbidden_classifications"),
        "policy.external_egress_forbidden_classifications",
    )
    threshold = _integer(
        policy.get("amount_approval_threshold_minor"),
        "policy.amount_approval_threshold_minor",
    )
    if action in forbidden:
        decision, reason = "DENY", "ACTION_FORBIDDEN"
    elif destination == "external" and classification in egress_forbidden:
        decision, reason = "DENY", "DATA_EGRESS_FORBIDDEN"
    elif role not in authorized_roles:
        decision, reason = "ESCALATE", "ROLE_NOT_AUTHORIZED"
    elif action in approval_actions or amount > threshold:
        decision, reason = "ESCALATE", "HUMAN_APPROVAL_REQUIRED"
    elif action in allowed:
        decision, reason = "ALLOW", "PROPOSAL_ONLY"
    else:
        raise ProductionPolicyInputError("action matches no declared policy rule")
    execution_enabled, human_approval = _control(inputs)
    return {
        "decision": decision,
        "reason_code": reason,
        "execution_enabled": execution_enabled,
        "requires_human_approval": human_approval,
    }


def derive_production_result(domain: str, contract: TaskContract) -> dict[str, Any]:
    """Derive the enforceable result from visible contract facts and policy."""

    if domain not in SUPPORTED_DOMAINS:
        raise ProductionPolicyInputError(f"unsupported HPADMIN domain: {domain}")
    inputs = _mapping(contract.inputs, "contract.inputs")
    if domain == "invoice_reconciliation":
        return _invoice_expectation(inputs)
    if domain == "payment_schedule":
        return _schedule_expectation(inputs)
    if domain == "budget_reconciliation":
        return _budget_expectation(inputs)
    if domain == "procurement_selection":
        return _procurement_expectation(inputs)
    return _exception_expectation(inputs)


@dataclass(frozen=True, slots=True)
class ProductionDomainPolicyGate:
    """Validate a proposal against contract-visible administrative policy."""

    domain: str
    name: str = "production_domain_policy"

    def evaluate(self, contract: TaskContract, proposal: Proposal) -> GateResult:
        try:
            expected = derive_production_result(self.domain, contract)
        except ProductionPolicyInputError as exc:
            return GateResult(
                self.name,
                False,
                f"Visible production policy inputs are invalid: {exc}",
                failure_code=GateFailureCode.POLICY_INPUT_INVALID,
                details={"domain": self.domain, "input_error": str(exc)},
            )
        actual = proposal.result if isinstance(proposal.result, Mapping) else {}
        violations = [
            field
            for field, value in expected.items()
            if actual.get(field) != value
        ]
        extra = sorted(set(actual) - set(expected)) if isinstance(actual, Mapping) else []
        if violations or extra:
            return GateResult(
                self.name,
                False,
                "Proposal conflicts with values derived from visible production policy",
                failure_code=POLICY_MISMATCH_CODE,
                details={
                    "domain": self.domain,
                    "violating_fields": violations,
                    "unexpected_fields": extra,
                    "derivation_source": "task_contract_visible_inputs",
                    "expected_values_disclosed": False,
                },
            )
        return GateResult(
            self.name,
            True,
            "Proposal matches values derived from visible production policy",
            details={
                "domain": self.domain,
                "derivation_source": "task_contract_visible_inputs",
            },
        )


def production_controller_gates(domain: str, contract: TaskContract) -> tuple[Gate, ...]:
    """Return gates safe to place inside the DOHAA feedback loop."""

    gates: list[Gate] = []
    if "result_spec" in contract.inputs:
        gates.append(ResultSpecGate())
    gates.extend(
        (
            ProductionDomainPolicyGate(domain),
            ActionPolicyGate(),
            ClaimEvidenceGate(),
            RequiredEvidenceGate(),
        )
    )
    return tuple(gates)


def production_scoring_gates(domain: str, contract: TaskContract) -> tuple[Gate, ...]:
    """Return post-inference production gates, including semantic assertions."""

    gates: list[Gate] = []
    if "result_spec" in contract.inputs:
        gates.append(ResultSpecGate())
    if "semantic_assertions" in contract.inputs:
        gates.append(SemanticAssertionsGate())
    gates.extend(
        (
            ProductionDomainPolicyGate(domain),
            ActionPolicyGate(),
            ClaimEvidenceGate(),
            RequiredEvidenceGate(),
        )
    )
    return tuple(gates)


def assert_production_gate_set(gates: Sequence[Gate]) -> None:
    """Fail closed if an oracle-style gate is ever inserted into the controller."""

    names = tuple(getattr(gate, "name", "") for gate in gates)
    forbidden_names = {"result_equals", "oracle"}
    if any(name in forbidden_names or "oracle" in name for name in names):
        raise AssertionError(f"oracle-capable gate found in controller set: {names}")
    allowed_types = {
        ResultSpecGate,
        ProductionDomainPolicyGate,
        ActionPolicyGate,
        ClaimEvidenceGate,
        RequiredEvidenceGate,
    }
    unexpected_types = tuple(
        type(gate).__name__ for gate in gates if type(gate) not in allowed_types
    )
    if unexpected_types:
        raise AssertionError(
            f"unapproved controller gate types: {unexpected_types}"
        )
    if "production_domain_policy" not in names:
        raise AssertionError("production domain policy gate is required")
