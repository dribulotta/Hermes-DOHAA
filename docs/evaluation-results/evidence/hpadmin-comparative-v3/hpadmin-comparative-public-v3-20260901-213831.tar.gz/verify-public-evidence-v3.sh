#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$SCRIPT_DIR"
sha256sum -c SHA256SUMS
python3 generate_hpadmin_comparative_suite_v3.py --output hpadmin-comparative-suite-v3.json --check
python3 verify-attestations-v3.py
python3 render_hpadmin_comparative_report_v3.py --verify-public-dir .
