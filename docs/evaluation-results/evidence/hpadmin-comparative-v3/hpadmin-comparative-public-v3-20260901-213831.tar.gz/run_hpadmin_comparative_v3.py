#!/usr/bin/env python3
"""Oracle-isolated HPADMIN V3 comparative evaluator.

The CLI exposes three OS-separable phases: ``prepare`` (root reads the oracle
and emits visible contracts), ``infer`` (an unprivileged process performs all
model/controller work without oracle access), and ``score`` (root loads the
oracle only after the immutable pre-score output exists).
"""

from __future__ import annotations

import argparse
import hashlib
import http.server
import ipaddress
import json
import math
import os
import re
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Mapping, Sequence
from uuid import uuid4

from hermes_dohaa import __version__
from hermes_dohaa.controller.engine import DohaaController, RunReasonCode
from hermes_dohaa.contracts.models import TaskContract
from hermes_dohaa.evidence.ledger import EvidenceLedger
from hermes_dohaa.runtime.base import Proposal, VerifierFeedback
from hermes_dohaa.runtime.hermes_api import HermesApiError, HermesApiRuntime
from hermes_dohaa.runtime.usage import summarize_usage

from hpadmin_v3_gates import (
    assert_production_gate_set,
    derive_production_result,
    production_controller_gates,
    production_scoring_gates,
)


CONDITIONS = ("direct", "native_reasoning_requested", "self_reflection", "dohaa")
SHARED_CONDITIONS = ("direct", "self_reflection", "dohaa")
INITIAL_UNITS = ("shared_reasoning_off_base", "native_reasoning_requested")
BRANCHES = ("self_reflection", "dohaa")
SUPPORTED_DOMAIN_ORDER = (
    "invoice_reconciliation",
    "payment_schedule",
    "budget_reconciliation",
    "procurement_selection",
    "exception_triage",
)
PAIRINGS = (
    ("dohaa_vs_direct", "dohaa", "direct"),
    ("dohaa_vs_native_reasoning_requested", "dohaa", "native_reasoning_requested"),
    ("dohaa_vs_self_reflection", "dohaa", "self_reflection"),
    ("native_reasoning_requested_vs_direct", "native_reasoning_requested", "direct"),
    ("self_reflection_vs_direct", "self_reflection", "direct"),
)
RETRYABLE_CODES = frozenset({"response.connection_failed", "response.timeout"})
COMMIT_PATTERN = re.compile(r"[0-9a-f]{40,64}")
REASONING_CONFIGURATION_ATTESTATION = (
    "requested_configured_not_independently_attested_for_all_conditions"
)
PRESCORE_TOP_LEVEL_KEYS = frozenset(
    {
        "schema_version", "evaluation_id", "suite_id", "suite_sha256",
        "suite_commitment", "suite_commitment_sha256", "protocol_id",
        "protocol_sha256", "started_at", "inference_completed_at", "seed",
        "sampling_seed", "repetitions", "conditions",
        "oracle_feedback_events", "visible_input_identity_violations",
        "controller_production_gate_names", "scoring_production_gate_names",
        "runtime_policy", "counterbalancing", "physical_model_calls",
        "attributed_logical_calls_by_condition", "cases",
    }
)
PRESCORE_ROW_KEYS = frozenset(
    {
        "case_id", "domain", "repetition", "sampling_seed",
        "visible_input_sha256", "condition_visible_input_sha256",
        "initial_call_order", "execution_order", "branch_order",
        "shared_initial_proposal_sha256",
        "shared_initial_identity_verified", "oracle_feedback_events",
        "conditions", "physical_model_calls",
    }
)
PRESCORE_OUTCOME_COMMON_KEYS = frozenset(
    {
        "condition", "status", "runtime_calls",
        "attributed_logical_model_calls", "elapsed_seconds", "usage",
        "usage_summary", "initial_proposal", "final_proposal",
        "initial_proposal_sha256", "transport", "oracle_feedback_events",
        "visible_input_sha256",
    }
)
PRESCORE_OUTCOME_FAILURE_KEYS = frozenset(
    {"error_type", "error_code", "error", "error_details"}
)


@dataclass(slots=True)
class _ObservedRuntime:
    """Count logical calls without importing the oracle-aware eval runner."""

    delegate: Any
    calls: int = 0
    elapsed_seconds: float = 0.0
    proposals: tuple[Proposal, ...] = ()

    def propose(self, contract, feedback) -> Proposal:
        started = time.perf_counter()
        self.calls += 1
        try:
            proposal = self.delegate.propose(contract, feedback)
        finally:
            self.elapsed_seconds += time.perf_counter() - started
        self.proposals = (*self.proposals, proposal)
        return proposal


class _FailClosedRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        del newurl
        raise urllib.error.HTTPError(
            req.full_url,
            code,
            "HTTP redirects are disabled for local inference",
            headers,
            fp,
        )


def write_evaluation_result(path: str | Path, result: dict[str, Any]) -> None:
    """Atomically commit JSON without importing oracle-aware eval helpers."""

    target = Path(path)
    if not target.parent.is_dir():
        raise FileNotFoundError(
            f"evaluation output directory does not exist: {target.parent}"
        )
    payload = json.dumps(
        result,
        ensure_ascii=False,
        sort_keys=True,
        indent=2,
        allow_nan=False,
    )
    descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{target.name}.",
        dir=target.parent,
        text=True,
    )
    temporary = Path(temporary_name)
    try:
        os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
            handle.write(payload)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temporary, target)
    finally:
        temporary.unlink(missing_ok=True)


def require_root_phase(phase: str) -> None:
    if os.geteuid() != 0:
        raise PermissionError(f"{phase} must run as root")


def require_root_private_file(path: Path, mode: int, label: str) -> None:
    if path.is_symlink():
        raise PermissionError(f"{label} must not be a symbolic link")
    metadata = path.stat()
    if metadata.st_uid != 0 or metadata.st_gid != 0:
        raise PermissionError(f"{label} must be owned by root:root")
    if metadata.st_mode & 0o777 != mode:
        raise PermissionError(f"{label} must have mode {mode:04o}")


def validate_local_hermes_url(url: str) -> str:
    if not isinstance(url, str) or not url.strip() or url != url.strip():
        raise ValueError("Hermes URL must be non-empty text without outer whitespace")
    try:
        parsed = urllib.parse.urlsplit(url)
        port = parsed.port
    except ValueError as exc:
        raise ValueError(f"Hermes URL is invalid: {exc}") from exc
    if parsed.scheme not in {"http", "https"}:
        raise ValueError("Hermes URL scheme must be http or https")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Hermes URL must not contain user information")
    if parsed.query or parsed.fragment:
        raise ValueError("Hermes URL must not contain a query or fragment")
    if parsed.path not in {"", "/v1"}:
        raise ValueError("Hermes URL path must be empty or /v1")
    if parsed.hostname is None:
        raise ValueError("Hermes URL must contain an IP-literal host")
    try:
        address = ipaddress.ip_address(urllib.parse.unquote(parsed.hostname))
    except ValueError as exc:
        raise ValueError("Hermes URL host must be an IP literal") from exc
    if port is not None and not 1 <= port <= 65535:
        raise ValueError("Hermes URL port is invalid")
    if isinstance(address, ipaddress.IPv4Address):
        allowed = (
            address in ipaddress.ip_network("127.0.0.0/8")
            or address in ipaddress.ip_network("10.0.0.0/8")
            or address in ipaddress.ip_network("172.16.0.0/12")
            or address in ipaddress.ip_network("192.168.0.0/16")
            or address in ipaddress.ip_network("169.254.0.0/16")
        )
        scope = "loopback_rfc1918_or_link_local_ipv4"
    else:
        allowed = (
            address == ipaddress.ip_address("::1")
            or address.is_link_local
            or address in ipaddress.ip_network("fc00::/7")
        )
        scope = "loopback_ula_or_link_local_ipv6"
    if not allowed:
        raise ValueError(
            "Hermes URL must use loopback, RFC1918, ULA, or link-local addressing"
        )
    return scope


def install_local_only_urllib_transport() -> None:
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        _FailClosedRedirectHandler(),
    )
    urllib.request.install_opener(opener)


@dataclass(frozen=True, slots=True)
class VisibleCase:
    case_id: str
    domain: str
    contract: TaskContract


@dataclass(slots=True)
class RetryingRuntime:
    delegate: HermesApiRuntime
    maximum_retries: int = 1
    retry_delay_seconds: float = 5.0
    request_attempts: int = 0
    retries: int = 0
    recovered_logical_calls: int = 0
    logical_calls: int = 0
    events: list[dict[str, Any]] = field(default_factory=list)

    @property
    def usage_records(self) -> list[dict[str, Any]]:
        return list(self.delegate.usage_records)

    def propose(self, contract, feedback: Sequence[VerifierFeedback | str]) -> Proposal:
        self.logical_calls += 1
        logical_call = self.logical_calls
        encountered = False
        for attempt in range(1, self.maximum_retries + 2):
            self.request_attempts += 1
            try:
                proposal = self.delegate.propose(contract, feedback)
            except HermesApiError as exc:
                retryable = exc.code in RETRYABLE_CODES
                will_retry = retryable and attempt <= self.maximum_retries
                self.events.append({
                    "logical_call": logical_call, "attempt": attempt,
                    "error_code": exc.code, "retryable": retryable,
                    "will_retry": will_retry,
                })
                if not will_retry:
                    raise
                encountered = True
                self.retries += 1
                if self.retry_delay_seconds:
                    time.sleep(self.retry_delay_seconds)
                continue
            if encountered:
                self.recovered_logical_calls += 1
            return proposal
        raise RuntimeError("unreachable transport retry state")


@dataclass(slots=True)
class SharedFirstRuntime:
    initial: Proposal
    delegate: RetryingRuntime
    served: bool = False

    @property
    def usage_records(self) -> list[dict[str, Any]]:
        return self.delegate.usage_records

    def propose(self, contract, feedback: Sequence[VerifierFeedback | str]) -> Proposal:
        if not self.served:
            if feedback:
                raise AssertionError("shared initial proposal must precede feedback")
            self.served = True
            return self.initial
        return self.delegate.propose(contract, feedback)


@dataclass(slots=True)
class FeedbackAuditRuntime:
    delegate: Any
    feedback_events: list[dict[str, Any]] = field(default_factory=list)
    oracle_feedback_events: int = 0

    @property
    def usage_records(self) -> list[dict[str, Any]]:
        return list(getattr(self.delegate, "usage_records", []))

    def propose(self, contract, feedback: Sequence[VerifierFeedback | str]) -> Proposal:
        for item in feedback:
            if isinstance(item, VerifierFeedback):
                # Preserve the complete production feedback record in the raw
                # result.  Production gates are responsible for keeping this
                # payload free of oracle values; retaining it here makes that
                # invariant independently auditable after the run.
                self.feedback_events.append(item.to_dict())
                if item.gate == "result_equals" or item.code == "result.mismatch":
                    self.oracle_feedback_events += 1
        return self.delegate.propose(contract, feedback)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def canonical_sha(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def file_sha(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require_execution_commitment(
    committed: Any,
    declared: Any,
    *,
    boundary: str,
) -> None:
    if (
        not isinstance(committed, str)
        or not isinstance(declared, str)
        or committed != declared
    ):
        raise ValueError(f"execution-code commitment mismatch at {boundary}")


def _require_exact_keys(
    value: Any,
    expected: frozenset[str],
    path: str,
) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValueError(f"pre-score object required at {path}")
    actual = set(value)
    if any(not isinstance(key, str) for key in actual):
        raise ValueError(f"pre-score object key is not text at {path}")
    if actual != expected:
        raise ValueError(
            "pre-score schema mismatch at "
            f"{path}; unknown={sorted(actual - expected)}, "
            f"missing={sorted(expected - actual)}"
        )
    return value


def _require_zero_oracle_marker(value: Any, path: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value != 0:
        raise ValueError(
            f"pre-score oracle feedback marker must equal integer zero at {path}"
        )


def assert_prescore_is_oracle_free(value: Any) -> None:
    """Validate the exact inference-owned schema before loading the scorer."""

    top = _require_exact_keys(value, PRESCORE_TOP_LEVEL_KEYS, "$")
    if top.get("schema_version") != "hpadmin-inference-commitment/3.0":
        raise ValueError("unsupported pre-score schema version")
    if top.get("conditions") != list(CONDITIONS):
        raise ValueError("pre-score condition list differs from V3")
    _require_zero_oracle_marker(
        top.get("oracle_feedback_events"),
        "$.oracle_feedback_events",
    )
    rows = top.get("cases")
    if not isinstance(rows, list):
        raise ValueError("pre-score cases must be a list")
    for row_index, raw_row in enumerate(rows):
        row_path = f"$.cases[{row_index}]"
        row = _require_exact_keys(raw_row, PRESCORE_ROW_KEYS, row_path)
        _require_zero_oracle_marker(
            row.get("oracle_feedback_events"),
            f"{row_path}.oracle_feedback_events",
        )
        outcomes = row.get("conditions")
        if not isinstance(outcomes, Mapping) or set(outcomes) != set(CONDITIONS):
            raise ValueError(f"pre-score condition map differs from V3 at {row_path}")
        for condition in CONDITIONS:
            outcome_path = f"{row_path}.conditions.{condition}"
            raw_outcome = outcomes[condition]
            if not isinstance(raw_outcome, Mapping):
                raise ValueError(f"pre-score outcome object required at {outcome_path}")
            status = raw_outcome.get("status")
            if status not in {"completed", "runtime_failed"}:
                raise ValueError(f"invalid pre-score outcome status at {outcome_path}")
            expected_keys = set(PRESCORE_OUTCOME_COMMON_KEYS)
            if condition in SHARED_CONDITIONS:
                expected_keys.add("shared_initial_proposal_sha256")
            if condition == "native_reasoning_requested":
                expected_keys.update(
                    {"reasoning_effort_requested", "reasoning_attestation"}
                )
            if status == "runtime_failed":
                expected_keys.update(PRESCORE_OUTCOME_FAILURE_KEYS)
            if (
                condition == "dohaa"
                and raw_outcome.get("shared_initial_proposal_sha256") is not None
            ):
                expected_keys.add("controller")
            outcome = _require_exact_keys(
                raw_outcome,
                frozenset(expected_keys),
                outcome_path,
            )
            if outcome.get("condition") != condition:
                raise ValueError(f"pre-score outcome condition mismatch at {outcome_path}")
            _require_zero_oracle_marker(
                outcome.get("oracle_feedback_events"),
                f"{outcome_path}.oracle_feedback_events",
            )


def trial_seed(base_seed: int, case_id: str) -> int:
    payload = f"{base_seed}:{case_id}:1".encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:4], "big") & 0x7FFFFFFF


def session_id(evaluation_id: str, case_id: str, purpose: str) -> str:
    payload = f"{evaluation_id}:{case_id}:{purpose}".encode("utf-8")
    return f"evaluation-v3:{hashlib.sha256(payload).hexdigest()}"


def proposal_sha(proposal: Proposal) -> str:
    return canonical_sha(proposal.to_dict())


def controller_contract(contract: TaskContract) -> TaskContract:
    """Return the scorer-free contract used by every inference condition."""

    raw = contract.to_dict()
    raw["inputs"].pop("semantic_assertions", None)
    return TaskContract.from_dict(raw)


def make_runtime(config: Mapping[str, Any], case: VisibleCase, purpose: str, effort: str) -> RetryingRuntime:
    delegate = HermesApiRuntime(
        base_url=config["base_url"], model=config["model"],
        timeout_seconds=config["timeout_seconds"],
        session_id=session_id(config["evaluation_id"], case.case_id, purpose),
        reasoning_effort=effort, temperature=config["temperature"],
        top_p=config["top_p"], sampling_seed=config["sampling_seed"],
    )
    return RetryingRuntime(delegate, config["maximum_retries"], config["retry_delay_seconds"])


def error_fields(exc: Exception) -> dict[str, Any]:
    return {
        "error_type": type(exc).__name__,
        "error_code": exc.code if isinstance(exc, HermesApiError) else None,
        "error": exc.message if isinstance(exc, HermesApiError) else str(exc),
        "error_details": exc.to_dict().get("details", {}) if isinstance(exc, HermesApiError) else {},
    }


def transport(retrying: RetryingRuntime, attributed_calls: int) -> dict[str, Any]:
    return {
        "attributed_logical_model_calls": attributed_calls,
        "physical_model_calls": retrying.request_attempts,
        "logical_inference_steps": retrying.logical_calls,
        "request_attempts": retrying.request_attempts,
        "transport_retries": retrying.retries,
        "retries": retrying.retries,
        "recovered_logical_calls": retrying.recovered_logical_calls,
        "recovered_after_retry": retrying.recovered_logical_calls > 0,
        "events": list(retrying.events),
    }


def branch_transport(
    shared: RetryingRuntime,
    continuation: RetryingRuntime,
    attributed_calls: int,
) -> dict[str, Any]:
    """Account for the shared initial call in one logical branch outcome."""

    combined = transport(continuation, attributed_calls)
    combined["request_attempts"] += shared.request_attempts
    combined["physical_model_calls"] += shared.request_attempts
    combined["logical_inference_steps"] += shared.logical_calls
    combined["transport_retries"] += shared.retries
    combined["retries"] += shared.retries
    combined["recovered_logical_calls"] += shared.recovered_logical_calls
    combined["recovered_after_retry"] = combined["recovered_logical_calls"] > 0
    combined["events"] = [
        {"purpose": "shared_reasoning_off_base", **event}
        for event in shared.events
    ] + [
        {"purpose": "branch_refinement", **event}
        for event in continuation.events
    ]
    return combined


def completed_outcome(
    condition: str, observed: _ObservedRuntime, usage: list[dict[str, Any]],
    transport_data: dict[str, Any], *, initial: Proposal | None = None,
    final: Proposal | None = None, oracle_feedback_events: int = 0,
) -> dict[str, Any]:
    first = initial or (observed.proposals[0] if observed.proposals else None)
    last = final or (observed.proposals[-1] if observed.proposals else None)
    return {
        "condition": condition, "status": "completed",
        "runtime_calls": observed.calls,
        "attributed_logical_model_calls": observed.calls,
        "elapsed_seconds": round(observed.elapsed_seconds, 6),
        "usage": usage,
        "usage_summary": summarize_usage(usage, int(transport_data["request_attempts"])),
        "initial_proposal": first.to_dict() if first else None,
        "final_proposal": last.to_dict() if last else None,
        "initial_proposal_sha256": proposal_sha(first) if first else None,
        "transport": transport_data,
        "oracle_feedback_events": oracle_feedback_events,
    }


def failed_outcome(
    condition: str, *, attributed_calls: int, elapsed_seconds: float,
    usage: list[dict[str, Any]], transport_data: dict[str, Any], exc: Exception,
    initial: Proposal | None = None,
) -> dict[str, Any]:
    result = {
        "condition": condition, "status": "runtime_failed",
        "runtime_calls": attributed_calls,
        "attributed_logical_model_calls": attributed_calls,
        "elapsed_seconds": round(elapsed_seconds, 6), "usage": usage,
        "usage_summary": summarize_usage(usage, int(transport_data["request_attempts"])),
        "initial_proposal": initial.to_dict() if initial else None,
        "final_proposal": None,
        "initial_proposal_sha256": proposal_sha(initial) if initial else None,
        "transport": transport_data, "oracle_feedback_events": 0,
    }
    result.update(error_fields(exc))
    return result


def unit_record(label: str, observed: _ObservedRuntime, retrying: RetryingRuntime) -> dict[str, Any]:
    usage = retrying.usage_records
    return {
        "purpose": label, "physical_model_calls": retrying.request_attempts,
        "logical_inference_steps": retrying.logical_calls,
        "transport_retries": retrying.retries,
        "recovered_logical_calls": retrying.recovered_logical_calls,
        "elapsed_seconds": round(observed.elapsed_seconds, 6), "usage": usage,
        "usage_summary": summarize_usage(usage, retrying.request_attempts),
    }


def physical_totals(units: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    usage = [record for unit in units.values() for record in unit.get("usage", [])]
    total = sum(int(unit.get("physical_model_calls", 0)) for unit in units.values())
    logical_calls = sum(int(unit.get("logical_inference_steps", 0)) for unit in units.values())
    retries = sum(int(unit.get("transport_retries", 0)) for unit in units.values())
    return {
        "total": total,
        "total_request_attempts": total,
        "logical_calls": logical_calls,
        "logical_inference_steps": logical_calls,
        "total_transport_retries": retries,
        "transport_retries": retries,
        "shared_initial_physical_calls": int(units.get("shared_reasoning_off_base", {}).get("physical_model_calls", 0)),
        "branch_refinement_physical_calls": sum(int(units.get(name, {}).get("physical_model_calls", 0)) for name in ("self_reflection_refinement", "dohaa_refinement")),
        "by_purpose": {name: int(unit.get("physical_model_calls", 0)) for name, unit in units.items()},
        "transport_retries_by_purpose": {name: int(unit.get("transport_retries", 0)) for name, unit in units.items()},
        "usage_summary": summarize_usage(usage, total),
    }


def balanced_assignments(cases: Sequence[VisibleCase], seed: int, units: tuple[str, str], namespace: str) -> dict[str, tuple[str, str]]:
    by_domain: dict[str, list[VisibleCase]] = {}
    for case in cases:
        by_domain.setdefault(case.domain, []).append(case)
    assignment: dict[str, tuple[str, str]] = {}
    for domain, rows in sorted(by_domain.items()):
        ranked = sorted(rows, key=lambda row: hashlib.sha256(f"{namespace}:{seed}:{domain}:{row.case_id}".encode()).digest())
        if len(ranked) % 2:
            raise ValueError(f"domain must have an even case count: {domain}")
        for index, case in enumerate(ranked):
            assignment[case.case_id] = units if index < len(ranked) // 2 else units[::-1]
    return assignment


def run_native(case: VisibleCase, config: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    retrying = make_runtime(config, case, "native_reasoning_requested", config["native_reasoning_effort"])
    observed = _ObservedRuntime(retrying)
    try:
        proposal = observed.propose(case.contract, ())
        outcome = completed_outcome("native_reasoning_requested", observed, retrying.usage_records, transport(retrying, 1), final=proposal)
    except Exception as exc:
        outcome = failed_outcome("native_reasoning_requested", attributed_calls=observed.calls, elapsed_seconds=observed.elapsed_seconds, usage=retrying.usage_records, transport_data=transport(retrying, observed.calls), exc=exc)
    outcome["reasoning_effort_requested"] = config["native_reasoning_effort"]
    outcome["reasoning_attestation"] = "requested_unattested"
    return outcome, {"native_reasoning_requested": unit_record("native_reasoning_requested", observed, retrying)}


def run_shared_initial(case: VisibleCase, config: Mapping[str, Any]):
    """Execute only the shared reasoning-off initial call."""

    shared_retry = make_runtime(config, case, "shared_reasoning_off_base", "none")
    shared_observed = _ObservedRuntime(shared_retry)
    units: dict[str, Any] = {}
    try:
        shared = shared_observed.propose(case.contract, ())
    except Exception as exc:
        units["shared_reasoning_off_base"] = unit_record("shared_reasoning_off_base", shared_observed, shared_retry)
        outcomes = {
            name: failed_outcome(name, attributed_calls=1, elapsed_seconds=shared_observed.elapsed_seconds, usage=shared_retry.usage_records, transport_data=dict(transport(shared_retry, 1)), exc=exc)
            for name in SHARED_CONDITIONS
        }
        for outcome in outcomes.values():
            outcome["shared_initial_proposal_sha256"] = None
        return None, shared_observed, shared_retry, outcomes, units
    units["shared_reasoning_off_base"] = unit_record("shared_reasoning_off_base", shared_observed, shared_retry)
    shared_hash = proposal_sha(shared)
    direct = completed_outcome("direct", shared_observed, shared_retry.usage_records, transport(shared_retry, 1), initial=shared, final=shared)
    direct["shared_initial_proposal_sha256"] = shared_hash
    outcomes: dict[str, Any] = {"direct": direct}
    return shared, shared_observed, shared_retry, outcomes, units


def run_shared_refinements(
    case: VisibleCase,
    config: Mapping[str, Any],
    shared: Proposal,
    shared_observed: _ObservedRuntime,
    shared_retry: RetryingRuntime,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Run the two branches only after both initial-call units are final."""

    shared_hash = proposal_sha(shared)
    outcomes: dict[str, Any] = {}
    units: dict[str, Any] = {}

    for branch in config["branch_order"]:
        continuation = make_runtime(config, case, f"{branch}_refinement", "none")
        audited = FeedbackAuditRuntime(SharedFirstRuntime(shared, continuation))
        observed = _ObservedRuntime(audited)
        unit_name = f"{branch}_refinement"
        if branch == "self_reflection":
            try:
                first = observed.propose(case.contract, ())
                feedback = VerifierFeedback(
                    gate="self_reflection", code="reflection.review",
                    reason="Independently review the previous proposal for factual, logical, policy, and evidence errors. Return a corrected proposal when needed. Previous proposal JSON: " + canonical_json(first.to_dict()),
                )
                final = observed.propose(case.contract, (feedback,))
                combined = branch_transport(
                    shared_retry,
                    continuation,
                    observed.calls,
                )
                outcome = completed_outcome(branch, observed, shared_retry.usage_records + continuation.usage_records, combined, initial=shared, final=final, oracle_feedback_events=audited.oracle_feedback_events)
                outcome["elapsed_seconds"] = round(shared_observed.elapsed_seconds + observed.elapsed_seconds, 6)
            except Exception as exc:
                combined = branch_transport(
                    shared_retry,
                    continuation,
                    observed.calls,
                )
                outcome = failed_outcome(branch, attributed_calls=observed.calls, elapsed_seconds=shared_observed.elapsed_seconds + observed.elapsed_seconds, usage=shared_retry.usage_records + continuation.usage_records, transport_data=combined, exc=exc, initial=shared)
        else:
            controlled_contract = controller_contract(case.contract)
            gates = production_controller_gates(case.domain, controlled_contract)
            assert_production_gate_set(gates)
            with EvidenceLedger() as ledger:
                controller = DohaaController(observed, gates, ledger).run(controlled_contract)
                chain_valid = ledger.verify_chain()
            if audited.oracle_feedback_events:
                raise AssertionError("oracle-derived feedback reached DOHAA")
            combined = branch_transport(
                shared_retry,
                continuation,
                observed.calls,
            )
            if controller.reason_code is RunReasonCode.RUNTIME_FAILED:
                outcome = failed_outcome(branch, attributed_calls=observed.calls, elapsed_seconds=shared_observed.elapsed_seconds + observed.elapsed_seconds, usage=shared_retry.usage_records + continuation.usage_records, transport_data=combined, exc=RuntimeError(controller.reason), initial=shared)
                outcome["error_code"] = controller.runtime_error_code
                outcome["error_details"] = controller.runtime_error_details or {}
            else:
                outcome = completed_outcome(branch, observed, shared_retry.usage_records + continuation.usage_records, combined, initial=shared, final=controller.proposal, oracle_feedback_events=audited.oracle_feedback_events)
                outcome["elapsed_seconds"] = round(shared_observed.elapsed_seconds + observed.elapsed_seconds, 6)
            outcome["controller"] = {
                "run_id": controller.run_id, "status": controller.status.value,
                "attempts": controller.attempts, "reason_code": controller.reason_code.value,
                "reason": controller.reason, "ledger_chain_valid": chain_valid,
                "production_gate_names": [gate.name for gate in gates],
                "feedback_events": audited.feedback_events,
                "oracle_feedback_events": audited.oracle_feedback_events,
                "semantic_assertions_available_to_controller": False,
                "expected_values_disclosed_in_feedback": False,
            }
        outcome["shared_initial_proposal_sha256"] = shared_hash
        outcome["initial_proposal_sha256"] = shared_hash
        outcomes[branch] = outcome
        units[unit_name] = unit_record(unit_name, observed, continuation)
    return outcomes, units


def load_visible(path: Path) -> tuple[list[VisibleCase], dict[str, Any]]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    serialized = canonical_json(raw)
    if "expected_result" in serialized or "ResultEqualsGate" in serialized:
        raise ValueError("visible inference suite contains forbidden oracle material")
    if any(
        "semantic_assertions" in item.get("contract", {}).get("inputs", {})
        for item in raw.get("cases", [])
    ):
        raise ValueError("semantic assertions are scorer-only in V3")
    cases = [
        VisibleCase(item["case_id"], item["domain"], TaskContract.from_dict(item["contract"]))
        for item in raw["cases"]
    ]
    if len({case.case_id for case in cases}) != len(cases):
        raise ValueError("visible inference suite contains duplicate case IDs")
    if any(case.contract.max_attempts != 2 for case in cases):
        raise ValueError("every V3 contract must cap DOHAA at two attempts")
    return cases, raw


def validate_protocol(protocol: Mapping[str, Any], visible: Mapping[str, Any], args) -> None:
    if protocol.get("status") != "preregistered":
        raise ValueError("protocol must be preregistered")
    if [item.get("id") for item in protocol.get("conditions", [])] != list(CONDITIONS):
        raise ValueError("condition IDs/order differ from V3 runner")
    suite_policy = protocol.get("suite_policy", {})
    if suite_policy.get("suite_id") != visible.get("suite_id") or suite_policy.get("case_count") != len(visible["cases"]):
        raise ValueError("protocol suite identity/count mismatch")
    counts: dict[str, int] = {}
    for case in visible["cases"]:
        counts[case["domain"]] = counts.get(case["domain"], 0) + 1
    if suite_policy.get("domain_counts") != dict(sorted(counts.items())):
        raise ValueError("protocol domain counts mismatch")
    if len(visible["cases"]) != 40 or counts != {
        domain: 8 for domain in SUPPORTED_DOMAIN_ORDER
    }:
        raise ValueError("V3 requires exactly 40 cases and eight cases per domain")
    if (
        suite_policy.get("semantic_assertions_in_visible_suite") is not False
        or suite_policy.get("semantic_assertions_location")
        != "scorer_only_hidden_oracle"
        or suite_policy.get("semantic_assertions_available_to_conditions")
        is not False
        or suite_policy.get("visible_case_input_byte_identical_across_all_conditions")
        is not True
    ):
        raise ValueError("visible-input/scorer-only suite policy differs from V3")
    shared = protocol.get("shared_initial_proposal", {})
    if (
        shared.get("enabled") is not True
        or shared.get("shared_by_conditions") != list(SHARED_CONDITIONS)
        or shared.get("reasoning_request") != "none"
    ):
        raise ValueError("shared-initial protocol mismatch")
    oracle = protocol.get("oracle_isolation", {})
    for name in (
        "oracle_available_during_inference", "oracle_available_to_controllers",
        "oracle_available_to_prompts", "oracle_available_to_production_gates",
    ):
        if oracle.get(name) is not False:
            raise ValueError(f"oracle isolation must be false: {name}")
    if oracle.get("semantic_assertions_available_during_inference_or_repair") is not False:
        raise ValueError("semantic assertions must be unavailable during inference")
    model = protocol.get("model_policy", {})
    execution = protocol.get("execution_policy", {})
    retry = execution.get("transport_retry", {})
    initial_order = execution.get("counterbalanced_initial_call_order", {})
    branch_order = execution.get("counterbalanced_branch_refinement_order", {})
    expected_initial_orders = [list(INITIAL_UNITS), list(INITIAL_UNITS[::-1])]
    expected_branch_orders = [list(BRANCHES), list(BRANCHES[::-1])]
    if (
        initial_order.get("seed") != args.seed
        or initial_order.get("units") != list(INITIAL_UNITS)
        or initial_order.get("orders") != expected_initial_orders
    ):
        raise ValueError("initial-call counterbalancing differs from protocol")
    if (
        branch_order.get("seed") != args.seed
        or branch_order.get("units") != list(BRANCHES)
        or branch_order.get("orders") != expected_branch_orders
    ):
        raise ValueError("branch counterbalancing differs from protocol")
    if (
        model.get("same_model_artifact_for_all_conditions") is not True
        or model.get("local_inference_only") is not True
        or retry.get("same_policy_for_all_model_calls") is not True
        or retry.get("retry_may_change_semantic_prompt_or_controller_state") is not False
        or retry.get("shared_initial_retry_applies_identically_to_all_three_shared_branches") is not True
    ):
        raise ValueError("model or transport fairness policy differs from V3")
    expected_condition_policy = {
        "direct": (1, "none", "shared_reasoning_off_base"),
        "native_reasoning_requested": (1, "high", "independent_native_reasoning_request"),
        "self_reflection": (2, "none", "shared_reasoning_off_base"),
        "dohaa": (2, "none", "shared_reasoning_off_base"),
    }
    for condition in protocol.get("conditions", []):
        condition_id = condition["id"]
        observed = (
            condition.get("maximum_attributed_logical_calls"),
            condition.get("reasoning_request"),
            condition.get("initial_proposal_source"),
        )
        if observed != expected_condition_policy[condition_id]:
            raise ValueError(f"condition policy differs from V3: {condition_id}")
    checks = {
        "model alias": (args.hermes_model, model.get("default_model_alias")),
        "model artifact": (args.model_artifact_id, model.get("default_model_artifact_id")),
        "model sampling seed": (args.sampling_seed, model.get("sampling_seed")),
        "temperature": (args.temperature, model.get("temperature")),
        "top_p": (args.top_p, model.get("top_p")),
        "condition order seed": (args.seed, execution.get("condition_order_seed")),
        "execution sampling seed": (args.sampling_seed, execution.get("sampling_seed")),
        "repetitions": (args.repetitions, execution.get("confirmatory_runs")),
        "timeout": (args.timeout_seconds, execution.get("timeout_seconds_per_request")),
        "maximum retries": (args.maximum_transport_retries, retry.get("maximum_retries_per_logical_call")),
        "retry delay": (args.retry_delay_seconds, retry.get("retry_delay_seconds")),
    }
    mismatches = [name for name, (actual, expected) in checks.items() if actual != expected]
    if mismatches:
        raise ValueError("CLI differs from preregistered protocol: " + ", ".join(mismatches))
    if set(retry.get("retryable_codes", [])) != RETRYABLE_CODES:
        raise ValueError("retryable error codes differ from protocol")
    if args.native_reasoning_effort != "high":
        raise ValueError("native reasoning request must be high")
    if (
        args.execution_code_commit != args.execution_code_commit.strip().lower()
        or COMMIT_PATTERN.fullmatch(args.execution_code_commit) is None
    ):
        raise ValueError("execution code commit must be a 40-64 character lowercase hex digest")
    visible_commitment = visible.get("suite_commitment")
    if not isinstance(visible_commitment, Mapping):
        raise ValueError("visible suite commitment is missing")
    require_execution_commitment(
        visible_commitment.get("protocol_commit"),
        args.execution_code_commit,
        boundary="pre-inference",
    )


def command_prepare(args) -> int:
    """Root-only phase: validate protected suite and emit oracle-free contracts."""
    from hermes_dohaa.evaluation import EvaluationSuite, SuiteCommitment

    require_root_phase("prepare")
    require_root_private_file(args.suite, 0o600, "protected suite")
    require_root_private_file(
        args.suite_commitment,
        0o600,
        "protected suite commitment",
    )
    suite = EvaluationSuite.from_json_file(args.suite)
    commitment = SuiteCommitment.from_json_file(args.suite_commitment)
    commitment.verify(suite)
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    visible = {
        "schema_version": "hpadmin-visible-suite/3.0",
        "suite_id": suite.suite_id, "suite_sha256": suite.sha256(),
        "suite_commitment": commitment.to_dict(),
        "suite_commitment_sha256": commitment.sha256(),
        "protocol_sha256": canonical_sha(protocol),
        "cases": [
            {
                "case_id": case.case_id,
                "domain": case.domain,
                "contract": controller_contract(case.contract).to_dict(),
            }
            for case in suite.cases
        ],
    }
    text = canonical_json(visible)
    if (
        "expected_result" in text
        or "ResultEqualsGate" in text
        or "semantic_assertions" in text
    ):
        raise AssertionError("oracle leaked into visible contracts")
    write_evaluation_result(args.visible_output, visible)
    print(json.dumps({"status": "visible_suite_prepared", "output": str(args.visible_output), "sha256": canonical_sha(visible)}))
    return 0


def command_infer(args) -> int:
    """Unprivileged phase: inference/controller work with no oracle file argument."""
    if os.geteuid() == 0:
        raise PermissionError("infer must run as an unprivileged account")
    endpoint_scope = validate_local_hermes_url(args.hermes_url)
    install_local_only_urllib_transport()
    if args.visible_suite.is_symlink() or args.visible_suite.stat().st_uid != 0:
        raise PermissionError("visible suite must be a root-owned regular path")
    if os.access(args.visible_suite, os.W_OK):
        raise PermissionError("inference account must not be able to modify visible suite")
    if os.access(args.protocol, os.W_OK):
        raise PermissionError("inference account must not be able to modify protocol")
    if args.prescore_output.exists():
        raise SystemExit(f"refusing to overwrite pre-score output: {args.prescore_output}")
    cases, visible = load_visible(args.visible_suite)
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    validate_protocol(protocol, visible, args)
    initial_orders = balanced_assignments(cases, args.seed, INITIAL_UNITS, "initial")
    branch_orders = balanced_assignments(cases, args.seed, BRANCHES, "branch")
    first_counts = {unit: 0 for unit in INITIAL_UNITS}
    branch_first_counts = {branch: 0 for branch in BRANCHES}
    per_domain_initial: dict[str, dict[str, int]] = {}
    per_domain_branch: dict[str, dict[str, int]] = {}
    for case in cases:
        first_counts[initial_orders[case.case_id][0]] += 1
        branch_first_counts[branch_orders[case.case_id][0]] += 1
        per_domain_initial.setdefault(case.domain, {unit: 0 for unit in INITIAL_UNITS})[initial_orders[case.case_id][0]] += 1
        per_domain_branch.setdefault(case.domain, {branch: 0 for branch in BRANCHES})[branch_orders[case.case_id][0]] += 1
    expected_global = len(cases) // 2
    if first_counts != {unit: expected_global for unit in INITIAL_UNITS}:
        raise AssertionError("initial unit order is not globally balanced")
    if branch_first_counts != {branch: expected_global for branch in BRANCHES}:
        raise AssertionError("branch order is not globally balanced")
    if any(set(counts.values()) != {4} for counts in per_domain_initial.values()):
        raise AssertionError("initial unit order is not 4/4 within every domain")
    if any(set(counts.values()) != {4} for counts in per_domain_branch.values()):
        raise AssertionError("branch order is not 4/4 within every domain")

    evaluation_id = str(uuid4())
    started_at = utc_now()
    rows: list[dict[str, Any]] = []
    all_units: dict[str, list[dict[str, Any]]] = {}
    for case in cases:
        seed = trial_seed(args.sampling_seed, case.case_id)
        config = {
            "base_url": args.hermes_url, "model": args.hermes_model,
            "timeout_seconds": args.timeout_seconds, "temperature": args.temperature,
            "top_p": args.top_p, "sampling_seed": seed,
            "maximum_retries": args.maximum_transport_retries,
            "retry_delay_seconds": args.retry_delay_seconds,
            "evaluation_id": evaluation_id,
            "native_reasoning_effort": args.native_reasoning_effort,
            "branch_order": branch_orders[case.case_id],
        }
        outcomes: dict[str, Any] = {}
        units: dict[str, Any] = {}
        shared_context = None
        for unit in initial_orders[case.case_id]:
            if unit == "shared_reasoning_off_base":
                shared, shared_observed, shared_retry, initial_outcomes, initial_units = run_shared_initial(case, config)
                outcomes.update(initial_outcomes)
                units.update(initial_units)
                if shared is not None:
                    shared_context = (shared, shared_observed, shared_retry)
            else:
                native, native_units = run_native(case, config)
                outcomes["native_reasoning_requested"] = native
                units.update(native_units)
        if shared_context is not None:
            refinements, refinement_units = run_shared_refinements(
                case, config, *shared_context
            )
            outcomes.update(refinements)
            units.update(refinement_units)
        if set(outcomes) != set(CONDITIONS):
            raise AssertionError(f"condition output missing: {case.case_id}")
        visible_input_hash = canonical_sha(case.contract.to_dict())
        for outcome in outcomes.values():
            outcome["visible_input_sha256"] = visible_input_hash
        hashes = [outcomes[name].get("initial_proposal_sha256") for name in SHARED_CONDITIONS]
        shared_failed = all(outcomes[name]["status"] == "runtime_failed" for name in SHARED_CONDITIONS)
        identity_ok = not shared_failed and None not in hashes and len(set(hashes)) == 1
        oracle_events = sum(int(outcomes[name].get("oracle_feedback_events", 0)) for name in CONDITIONS)
        if oracle_events:
            raise AssertionError(f"oracle feedback before scoring: {case.case_id}")
        rows.append({
            "case_id": case.case_id, "domain": case.domain, "repetition": 1,
            "sampling_seed": seed,
            "visible_input_sha256": visible_input_hash,
            "condition_visible_input_sha256": {
                condition: visible_input_hash for condition in CONDITIONS
            },
            "initial_call_order": list(initial_orders[case.case_id]),
            "execution_order": list(initial_orders[case.case_id]),
            "branch_order": list(branch_orders[case.case_id]),
            "shared_initial_proposal_sha256": hashes[0] if identity_ok and not shared_failed else None,
            "shared_initial_identity_verified": identity_ok,
            "oracle_feedback_events": oracle_events,
            "conditions": outcomes,
            "physical_model_calls": physical_totals(units),
        })
        for name, record in units.items():
            all_units.setdefault(name, []).append(record)

    oracle_events = sum(row["oracle_feedback_events"] for row in rows)
    if oracle_events != 0:
        raise AssertionError("oracle feedback invariant violated")
    aggregated_units = {
        name: {
            "physical_model_calls": sum(int(item["physical_model_calls"]) for item in items),
            "logical_inference_steps": sum(int(item["logical_inference_steps"]) for item in items),
            "transport_retries": sum(int(item["transport_retries"]) for item in items),
            "usage": [record for item in items for record in item.get("usage", [])],
        }
        for name, items in sorted(all_units.items())
    }
    prescore = {
        "schema_version": "hpadmin-inference-commitment/3.0",
        "evaluation_id": evaluation_id, "suite_id": visible["suite_id"],
        "suite_sha256": visible["suite_sha256"],
        "suite_commitment": visible["suite_commitment"],
        "suite_commitment_sha256": visible["suite_commitment_sha256"],
        "protocol_id": protocol["protocol_id"], "protocol_sha256": canonical_sha(protocol),
        "started_at": started_at, "inference_completed_at": utc_now(),
        "seed": args.seed, "sampling_seed": args.sampling_seed,
        "repetitions": args.repetitions,
        "conditions": list(CONDITIONS), "oracle_feedback_events": 0,
        "visible_input_identity_violations": 0,
        "controller_production_gate_names": [gate.name for gate in production_controller_gates(cases[0].domain, cases[0].contract)],
        "scoring_production_gate_names": [
            "result_spec", "semantic_assertions", "production_domain_policy",
            "action_policy", "claim_evidence", "required_evidence",
        ],
        "runtime_policy": {
            "adapter": "hermes_api", "hermes_dohaa_version": __version__,
            "model_alias": args.hermes_model, "model_artifact_id": args.model_artifact_id,
            "model_identity_attestation": "operator_declared_unattested",
            "native_reasoning_status": "requested_unattested",
            "reasoning_configuration_attestation": (
                REASONING_CONFIGURATION_ATTESTATION
            ),
            "condition_reasoning_effort": {"direct": "none", "native_reasoning_requested": "high", "self_reflection": "none", "dohaa": "none"},
            "temperature": args.temperature, "top_p": args.top_p,
            "sampling_seed": args.sampling_seed,
            "timeout_seconds_per_request": args.timeout_seconds,
            "maximum_transport_retries_per_logical_call": args.maximum_transport_retries,
            "retry_delay_seconds": args.retry_delay_seconds,
            "retryable_codes": sorted(RETRYABLE_CODES),
            "execution_code_commit": args.execution_code_commit,
            "execution_code_commit_attestation": "operator_declared_unattested",
            "evaluator_sha256": file_sha(Path(__file__)),
            "production_gates_sha256": file_sha(Path(__file__).with_name("hpadmin_v3_gates.py")),
            "semantic_assertions_available_during_inference": False,
            "inference_endpoint_scope": endpoint_scope,
            "inference_redirects_allowed": False,
            "redirects_allowed": False,
            "proxy_environment_used": False,
        },
        "counterbalancing": {
            "initial_unit_first_counts": first_counts,
            "initial_unit_first_counts_by_domain": per_domain_initial,
            "branch_first_counts": branch_first_counts,
            "branch_first_counts_by_domain": per_domain_branch,
            "assignments_frozen_before_inference": True,
        },
        "physical_model_calls": physical_totals(aggregated_units),
        "attributed_logical_calls_by_condition": {
            condition: sum(row["conditions"][condition]["attributed_logical_model_calls"] for row in rows)
            for condition in CONDITIONS
        },
        "cases": rows,
    }
    write_evaluation_result(args.prescore_output, prescore)
    committed = json.loads(args.prescore_output.read_text(encoding="utf-8"))
    if canonical_sha(committed) != canonical_sha(prescore):
        raise AssertionError("atomic pre-score commitment mismatch")
    print(json.dumps({"status": "inference_committed", "output": str(args.prescore_output), "prescore_output_sha256": canonical_sha(prescore), "oracle_feedback_events": 0, "physical_model_calls": prescore["physical_model_calls"]}, ensure_ascii=False))
    return 0


def score_proposal(case, raw: Any) -> dict[str, Any]:
    from hermes_dohaa.assurance.gates import ResultEqualsGate
    from hermes_dohaa.evaluation.runner import _score_dimensions, structural_distance

    if raw is None:
        return {"all_gates_passed": False, "production_all_gates_passed": False, "gate_results": []}
    proposal = Proposal.from_dict(raw)
    production = production_scoring_gates(case.domain, case.contract)
    production_results = tuple(gate.evaluate(case.contract, proposal) for gate in production)
    oracle_result = ResultEqualsGate(case.expected_result).evaluate(case.contract, proposal)
    results = (*production_results, oracle_result)
    return {
        "all_gates_passed": all(result.passed for result in results),
        "production_all_gates_passed": all(result.passed for result in production_results),
        "oracle_passed": oracle_result.passed,
        "gate_results": [result.to_dict() for result in results],
        "production_gate_results": [result.to_dict() for result in production_results],
        "oracle_gate_result": oracle_result.to_dict(),
        "dimensions": _score_dimensions(results),
        "oracle_distance": structural_distance(proposal.result, case.expected_result),
    }


def repair_transition(initial: Mapping[str, Any], final: Mapping[str, Any]) -> str:
    before, after = bool(initial.get("all_gates_passed")), bool(final.get("all_gates_passed"))
    if before and after:
        return "passed_unchanged"
    if not before and after:
        return "repaired"
    if before and not after:
        return "regressed"
    return "unchanged_failure"


def passed(outcome: Mapping[str, Any]) -> bool:
    return bool(outcome.get("status") == "completed" and isinstance(outcome.get("final_score"), Mapping) and outcome["final_score"].get("all_gates_passed") is True)


def average(values: Sequence[float | int]) -> float:
    return round(sum(values) / len(values), 6) if values else 0.0


def counts(values: Sequence[str]) -> dict[str, int]:
    result: dict[str, int] = {}
    for value in values:
        result[value] = result.get(value, 0) + 1
    return dict(sorted(result.items()))


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    summary: dict[str, Any] = {}
    for condition in CONDITIONS:
        outcomes = [row["conditions"][condition] for row in rows]
        completed = [item for item in outcomes if item["status"] == "completed"]
        final_passes = sum(passed(item) for item in outcomes)
        usage = [record for item in outcomes for record in item.get("usage", [])]
        request_attempts = sum(int(item["transport"]["request_attempts"]) for item in outcomes)
        usage_summary = summarize_usage(usage, request_attempts)
        summary[condition] = {
            "cases": len(outcomes), "unique_cases": len(outcomes),
            "completed": len(completed), "runtime_failures": len(outcomes) - len(completed),
            "final_passes": final_passes,
            "final_pass_rate": round(final_passes / len(outcomes), 6),
            "semantic_pass_rate_among_completed": round(final_passes / len(completed), 6) if completed else 0.0,
            "improved": sum(bool(item.get("improved")) for item in completed),
            "regressed": sum(bool(item.get("regressed")) for item in completed),
            "repair_transitions": counts([str(item.get("repair_transition")) for item in outcomes]),
            "average_attributed_logical_model_calls": average([int(item["attributed_logical_model_calls"]) for item in outcomes]),
            "average_elapsed_seconds": average([float(item["elapsed_seconds"]) for item in outcomes]),
            "reported_total_tokens": usage_summary["reported_total_tokens"],
            "usage_complete": usage_summary["complete"],
            "oracle_feedback_events": sum(int(item["oracle_feedback_events"]) for item in outcomes),
        }
    failures = [(row, condition, row["conditions"][condition]) for row in rows for condition in CONDITIONS if row["conditions"][condition]["status"] == "runtime_failed"]
    summary["runtime_failure_counts"] = {
        "by_code": counts([str(item.get("error_code") or "unclassified") for _, _, item in failures]),
        "by_condition": counts([condition for _, condition, _ in failures]),
        "by_domain": counts([row["domain"] for row, _, _ in failures]),
        "by_condition_and_code": counts([f"{condition}/{item.get('error_code') or 'unclassified'}" for _, condition, item in failures]),
    }
    return summary


def exact_two_sided_sign_p(wins: int, losses: int) -> float:
    n = wins + losses
    if n == 0:
        return 1.0
    tail = min(wins, losses)
    return round(min(1.0, 2.0 * sum(math.comb(n, k) for k in range(tail + 1)) / (2**n)), 12)


def paired(rows: list[dict[str, Any]], left: str, right: str) -> dict[str, Any]:
    wins = losses = both_pass = both_fail = 0
    for row in rows:
        lp, rp = passed(row["conditions"][left]), passed(row["conditions"][right])
        if lp and not rp:
            wins += 1
        elif rp and not lp:
            losses += 1
        elif lp:
            both_pass += 1
        else:
            both_fail += 1
    return {
        "left": left, "right": right, "wins": wins, "losses": losses,
        "ties": both_pass + both_fail, "both_pass_ties": both_pass,
        "both_fail_ties": both_fail, "discordant_cases": wins + losses,
        "mean_pass_rate_difference": round((wins - losses) / len(rows), 6),
        "exact_two_sided_sign_test_p": exact_two_sided_sign_p(wins, losses),
    }


def domain_summary(rows: list[dict[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for domain in sorted({row["domain"] for row in rows}):
        domain_rows = [row for row in rows if row["domain"] == domain]
        result[domain] = {
            condition: {
                "passes": sum(passed(row["conditions"][condition]) for row in domain_rows),
                "cases": len(domain_rows),
                "runtime_failures": sum(row["conditions"][condition]["status"] == "runtime_failed" for row in domain_rows),
            }
            for condition in CONDITIONS
        }
    return result


def command_score(args) -> int:
    """Root-only phase: load oracle after a read-only pre-score commit exists."""
    require_root_phase("score")
    require_root_private_file(args.suite, 0o600, "protected suite")
    require_root_private_file(
        args.suite_commitment,
        0o600,
        "protected suite commitment",
    )
    if args.output.exists():
        raise SystemExit(f"refusing to overwrite final output: {args.output}")
    require_root_private_file(
        args.prescore_input,
        0o400,
        "pre-score inference commitment",
    )
    prescore = json.loads(args.prescore_input.read_text(encoding="utf-8"))
    assert_prescore_is_oracle_free(prescore)
    prescore_hash = canonical_sha(prescore)
    if prescore.get("oracle_feedback_events") != 0:
        raise ValueError("pre-score output records oracle feedback contamination")
    if prescore.get("visible_input_identity_violations") != 0:
        raise ValueError("pre-score output records visible-input identity violations")
    from hermes_dohaa.evaluation import EvaluationSuite, SuiteCommitment

    suite = EvaluationSuite.from_json_file(args.suite)
    commitment = SuiteCommitment.from_json_file(args.suite_commitment)
    commitment.verify(suite)
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    runtime_policy = prescore.get("runtime_policy")
    if not isinstance(runtime_policy, Mapping):
        raise ValueError("pre-score runtime policy is missing")
    require_execution_commitment(
        commitment.protocol_commit,
        runtime_policy.get("execution_code_commit"),
        boundary="pre-scoring",
    )
    controller_name_sets = {
        tuple(
            gate.name
            for gate in production_controller_gates(
                case.domain,
                controller_contract(case.contract),
            )
        )
        for case in suite.cases
    }
    scoring_name_sets = {
        tuple(
            gate.name
            for gate in production_scoring_gates(case.domain, case.contract)
        )
        for case in suite.cases
    }
    if len(controller_name_sets) != 1 or len(scoring_name_sets) != 1:
        raise ValueError("production gate names must be uniform across V3 cases")
    controller_gate_names = list(next(iter(controller_name_sets)))
    scoring_gate_names = list(next(iter(scoring_name_sets)))
    if (
        prescore.get("suite_id") != suite.suite_id
        or prescore.get("suite_sha256") != suite.sha256()
        or prescore.get("suite_commitment") != commitment.to_dict()
        or prescore.get("suite_commitment_sha256") != commitment.sha256()
        or prescore.get("protocol_id") != protocol.get("protocol_id")
        or prescore.get("protocol_sha256") != canonical_sha(protocol)
        or prescore.get("conditions") != list(CONDITIONS)
        or prescore.get("controller_production_gate_names") != controller_gate_names
        or prescore.get("scoring_production_gate_names") != scoring_gate_names
    ):
        raise ValueError("pre-score output does not match suite/protocol")
    rows = prescore["cases"]
    row_map = {row["case_id"]: row for row in rows}
    if (
        len(rows) != len(suite.cases)
        or set(row_map) != {case.case_id for case in suite.cases}
    ):
        raise ValueError("pre-score case set differs from protected suite")
    visible_input_identity_violations = 0
    for case in suite.cases:
        row = row_map[case.case_id]
        expected_visible_sha = canonical_sha(
            controller_contract(case.contract).to_dict()
        )
        expected_condition_hashes = {
            condition: expected_visible_sha for condition in CONDITIONS
        }
        visible_identity_ok = (
            row.get("domain") == case.domain
            and row.get("visible_input_sha256") == expected_visible_sha
            and row.get("condition_visible_input_sha256")
            == expected_condition_hashes
            and all(
                row.get("conditions", {})
                .get(condition, {})
                .get("visible_input_sha256")
                == expected_visible_sha
                for condition in CONDITIONS
            )
        )
        if not visible_identity_ok:
            visible_input_identity_violations += 1
        for condition in CONDITIONS:
            outcome = row["conditions"][condition]
            if outcome["status"] != "completed":
                outcome.update({"initial_score": None, "final_score": None, "improved": False, "regressed": False, "repair_transition": "runtime_failed"})
                continue
            initial = score_proposal(case, outcome.get("initial_proposal"))
            final = score_proposal(case, outcome.get("final_proposal"))
            outcome.update({
                "initial_score": initial, "final_score": final,
                "improved": not initial["all_gates_passed"] and final["all_gates_passed"],
                "regressed": initial["all_gates_passed"] and not final["all_gates_passed"],
                "repair_transition": repair_transition(initial, final),
            })
        row["public_summary"] = {
            condition: {
                "status": row["conditions"][condition]["status"],
                "strict_pass": passed(row["conditions"][condition]),
                "attributed_logical_model_calls": row["conditions"][condition]["attributed_logical_model_calls"],
                "transport_retries": row["conditions"][condition]["transport"]["transport_retries"],
                "failed_production_gates": [
                    result["gate"] for result in (row["conditions"][condition].get("final_score") or {}).get("production_gate_results", []) if result.get("passed") is not True
                ],
            }
            for condition in CONDITIONS
        }
    if visible_input_identity_violations:
        raise ValueError(
            "pre-score visible-input identity differs from protected suite"
        )
    comparisons = {name: paired(rows, left, right) for name, left, right in PAIRINGS}
    result = {
        "schema_version": "hpadmin-comparative-result/3.0",
        "evaluation_id": prescore["evaluation_id"], "suite_id": suite.suite_id,
        "suite_sha256": suite.sha256(), "protocol_id": protocol["protocol_id"],
        "protocol_sha256": canonical_sha(protocol),
        "suite_commitment": commitment.to_dict(), "suite_commitment_sha256": commitment.sha256(),
        "started_at": prescore["started_at"], "inference_completed_at": prescore["inference_completed_at"],
        "completed_at": utc_now(), "conditions": list(CONDITIONS),
        "seed": prescore["seed"], "sampling_seed": prescore["sampling_seed"],
        "repetitions": prescore["repetitions"],
        "runtime_policy": prescore["runtime_policy"],
        "controller_production_gate_names": controller_gate_names,
        "scoring_production_gate_names": scoring_gate_names,
        "production_gate_names": scoring_gate_names,
        "oracle_feedback_events": 0,
        "prescore_output_sha256": prescore_hash,
        "prescore_output_canonical_sha256": prescore_hash,
        "prescore_output_file_sha256": file_sha(args.prescore_input),
        "oracle_boundary": {
            "controller_expected_result_access": False,
            "controller_result_equals_gate": False,
            "scoring_after_controller": True,
            "oracle_loaded_after_prescore_commit": True,
            "oracle_feedback_events": 0,
            "asserted_zero_oracle_feedback_events": True,
            "inference_process_used_sanitized_visible_contracts": True,
            "semantic_assertions_available_during_inference": False,
            "semantic_assertions_loaded_only_by_scorer": True,
            "scorer_process_separate": True,
        },
        "shared_initial_proposal": {
            "enabled": True, "conditions": list(SHARED_CONDITIONS),
            "identity_violations": sum(not row["shared_initial_identity_verified"] for row in rows),
        },
        "shared_initial_identity_violations": sum(not row["shared_initial_identity_verified"] for row in rows),
        "visible_input_identity_violations": visible_input_identity_violations,
        "counterbalancing": prescore["counterbalancing"],
        "physical_model_calls": prescore["physical_model_calls"],
        "attributed_logical_calls_by_condition": prescore["attributed_logical_calls_by_condition"],
        "cases": rows, "summary": summarize(rows),
        "domain_summary": domain_summary(rows),
        "paired_comparisons": comparisons,
        "statistical_analysis": {"paired_sign_tests": comparisons},
    }
    write_evaluation_result(args.output, result)
    print(json.dumps({"status": "scored", "output": str(args.output), "prescore_output_sha256": prescore_hash, "oracle_feedback_events": 0, "summary": result["summary"], "paired_comparisons": comparisons}, ensure_ascii=False))
    return 0


def self_test_contract() -> TaskContract:
    return TaskContract.from_dict({
        "schema_version": "1.0", "contract_id": "oracle-isolation-trap",
        "objective": "Classify an inert request",
        "inputs": {
            "request": {"action": "payment.execute", "requester_role": "finance_manager", "data_classification": "internal", "destination": "internal", "amount_minor": 1},
            "policy": {"forbidden_actions": ["payment.execute"], "approval_required_actions": [], "allowed_actions": ["proposal.prepare"], "authorized_roles": ["finance_manager"], "external_egress_forbidden_classifications": ["restricted"], "amount_approval_threshold_minor": 100},
            "control": {"execution_enabled": False, "requires_human_approval": True},
            "result_spec": {
                "required_keys": ["decision", "reason_code", "execution_enabled", "requires_human_approval"], "additional_keys": False,
                "types": {"decision": "string", "reason_code": "string", "execution_enabled": "boolean", "requires_human_approval": "boolean"},
                "enums": {"decision": ["ALLOW", "DENY", "ESCALATE"], "reason_code": ["ACTION_FORBIDDEN", "PROPOSAL_ONLY"]},
            },
        },
        "constraints": ["inert"],
        "acceptance_criteria": [{"criterion_id": "strict", "description": "strict", "required_evidence": []}],
        "allowed_actions": [], "forbidden_actions": ["payment.execute"],
        "risk_level": "low", "max_attempts": 2, "requires_human_approval": False,
    })


class TrapRuntime:
    def __init__(self, proposals: Sequence[Proposal]) -> None:
        self.proposals, self.feedback = list(proposals), []

    def propose(self, contract, feedback):
        del contract
        self.feedback.append([item.to_dict() for item in feedback])
        return self.proposals.pop(0)


def self_test() -> int:
    assert "hermes_dohaa.evaluation.runner" not in sys.modules
    assert REASONING_CONFIGURATION_ATTESTATION == (
        "requested_configured_not_independently_attested_for_all_conditions"
    )
    assert exact_two_sided_sign_p(6, 0) == 0.03125
    contract = self_test_contract()
    scorer_contract_raw = contract.to_dict()
    scorer_contract_raw["inputs"]["semantic_assertions"] = [
        {"assertion_id": "scorer-only-trap", "operator": "equals"}
    ]
    scorer_contract = TaskContract.from_dict(scorer_contract_raw)
    inference_contract = controller_contract(scorer_contract)
    assert "semantic_assertions" in scorer_contract.inputs
    assert "semantic_assertions" not in inference_contract.inputs
    visible_sha = canonical_sha(inference_contract.to_dict())
    assert len({visible_sha for _condition in CONDITIONS}) == 1
    committed_code = "a" * 64
    require_execution_commitment(
        committed_code,
        committed_code,
        boundary="self-test",
    )
    try:
        require_execution_commitment(
            committed_code,
            "b" * 64,
            boundary="tamper-test",
        )
    except ValueError as exc:
        assert "commitment mismatch" in str(exc)
    else:
        raise AssertionError("tampered execution commitment was accepted")
    clean_outcomes: dict[str, Any] = {}
    for condition in CONDITIONS:
        outcome = {key: None for key in PRESCORE_OUTCOME_COMMON_KEYS}
        outcome.update(
            {
                "condition": condition,
                "status": "completed",
                "oracle_feedback_events": 0,
            }
        )
        if condition in SHARED_CONDITIONS:
            outcome["shared_initial_proposal_sha256"] = "c" * 64
        if condition == "native_reasoning_requested":
            outcome.update(
                {
                    "reasoning_effort_requested": "high",
                    "reasoning_attestation": "requested_unattested",
                }
            )
        if condition == "dohaa":
            outcome["controller"] = {"oracle_feedback_events": 0}
        clean_outcomes[condition] = outcome
    clean_row = {key: None for key in PRESCORE_ROW_KEYS}
    clean_row.update(
        {"oracle_feedback_events": 0, "conditions": clean_outcomes}
    )
    clean_prescore = {key: None for key in PRESCORE_TOP_LEVEL_KEYS}
    clean_prescore.update(
        {
            "schema_version": "hpadmin-inference-commitment/3.0",
            "conditions": list(CONDITIONS),
            "oracle_feedback_events": 0,
            "cases": [clean_row],
        }
    )
    assert_prescore_is_oracle_free(clean_prescore)
    prescore_tamper_locations = (
        ("top", "gold_answer"),
        ("row", "truth_payload"),
        ("outcome", "strict_pass_copy"),
        ("outcome", "scorecard"),
        ("top", "expected_result"),
        ("row", "oracle_gate_result"),
        ("outcome", "final_score_copy"),
        ("outcome", "public_summary"),
    )
    for location, key in prescore_tamper_locations:
        tampered = json.loads(json.dumps(clean_prescore))
        if location == "top":
            tampered[key] = {}
        elif location == "row":
            tampered["cases"][0][key] = {}
        else:
            tampered["cases"][0]["conditions"]["direct"][key] = {}
        try:
            assert_prescore_is_oracle_free(tampered)
        except ValueError:
            pass
        else:
            raise AssertionError(
                f"pre-score unknown {location} key accepted: {key}"
            )
    tampered_marker = json.loads(json.dumps(clean_prescore))
    tampered_marker["cases"][0]["conditions"]["dohaa"][
        "oracle_feedback_events"
    ] = 1
    try:
        assert_prescore_is_oracle_free(tampered_marker)
    except ValueError:
        pass
    else:
        raise AssertionError("non-zero oracle feedback marker was accepted")

    request_counts = {"redirect": 0, "destination": 0}

    class DestinationHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            request_counts["destination"] += 1
            self.send_response(204)
            self.end_headers()

        do_POST = do_GET

        def log_message(self, format, *args):
            del format, args

    destination = http.server.ThreadingHTTPServer(
        ("127.0.0.1", 0),
        DestinationHandler,
    )

    class RedirectHandler(http.server.BaseHTTPRequestHandler):
        def do_POST(self):
            request_counts["redirect"] += 1
            self.send_response(302)
            self.send_header(
                "Location",
                f"http://127.0.0.1:{destination.server_port}/must-not-arrive",
            )
            self.end_headers()

        def log_message(self, format, *args):
            del format, args

    redirect = http.server.ThreadingHTTPServer(("127.0.0.1", 0), RedirectHandler)
    threads = [
        threading.Thread(target=server.serve_forever, daemon=True)
        for server in (destination, redirect)
    ]
    for thread in threads:
        thread.start()
    try:
        assert validate_local_hermes_url(
            f"http://127.0.0.1:{redirect.server_port}"
        ).startswith("loopback_")
        for forbidden_url in ("http://localhost:8642", "https://8.8.8.8"):
            try:
                validate_local_hermes_url(forbidden_url)
            except ValueError:
                pass
            else:
                raise AssertionError(f"non-local/IP-literal URL accepted: {forbidden_url}")
        install_local_only_urllib_transport()
        redirect_runtime = HermesApiRuntime(
            base_url=f"http://127.0.0.1:{redirect.server_port}",
            model="redirect-test",
            timeout_seconds=2,
        )
        try:
            redirect_runtime.propose(contract, ())
        except HermesApiError as exc:
            assert exc.code == "response.http_error"
            assert exc.details.get("http_status") == 302
        else:
            raise AssertionError("HTTP redirect was accepted")
        assert request_counts == {"redirect": 1, "destination": 0}
    finally:
        for server in (redirect, destination):
            server.shutdown()
            server.server_close()
        for thread in threads:
            thread.join(timeout=2)
    correct = derive_production_result("exception_triage", contract)
    wrong = dict(correct, decision="ALLOW", reason_code="PROPOSAL_ONLY")
    traces, finals = [], []
    for _hidden_trap in (correct, wrong):
        runtime = TrapRuntime((Proposal(wrong), Proposal(correct)))
        audited = FeedbackAuditRuntime(runtime)
        gates = production_controller_gates("exception_triage", contract)
        assert_production_gate_set(gates)
        with EvidenceLedger() as ledger:
            controller = DohaaController(audited, gates, ledger).run(contract)
        assert controller.reason_code is RunReasonCode.SUCCEEDED
        assert audited.oracle_feedback_events == 0
        assert all(
            {"gate", "code", "reason", "evidence_ids"} <= set(event)
            for event in audited.feedback_events
        )
        traces.append(runtime.feedback)
        finals.append(controller.proposal.to_dict())
    assert traces[0] == traces[1] and finals[0] == finals[1]
    source = Path(__file__).with_name("hpadmin_v3_gates.py").read_text(encoding="utf-8")
    assert "ResultEqualsGate" not in source and ".expected_result" not in source
    print("HPADMIN_COMPARATIVE_V3_EXECUTION_COMMITMENT_TAMPER=PASS")
    print("HPADMIN_COMPARATIVE_V3_PRESCORE_ORACLE_TAMPER=PASS")
    print("HPADMIN_COMPARATIVE_V3_PRESCORE_EXACT_SCHEMA=PASS")
    print("HPADMIN_COMPARATIVE_V3_LOCAL_TRANSPORT_REDIRECT=PASS")
    print("HPADMIN_COMPARATIVE_V3_ORACLE_ISOLATION_TRAP=PASS")
    print("HPADMIN_COMPARATIVE_V3_SHARED_INITIAL_DESIGN=PASS")
    print("HPADMIN_COMPARATIVE_V3_RUNNER_SELF_TEST=PASS")
    return 0


def main() -> int:
    if sys.argv[1:] == ["--self-test"]:
        return self_test()
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    prepare = sub.add_parser("prepare")
    prepare.add_argument("--suite", type=Path, required=True)
    prepare.add_argument("--suite-commitment", type=Path, required=True)
    prepare.add_argument("--protocol", type=Path, required=True)
    prepare.add_argument("--visible-output", type=Path, required=True)

    infer = sub.add_parser("infer")
    infer.add_argument("--visible-suite", type=Path, required=True)
    infer.add_argument("--protocol", type=Path, required=True)
    infer.add_argument("--prescore-output", type=Path, required=True)
    infer.add_argument("--hermes-url", required=True)
    infer.add_argument("--hermes-model", required=True)
    infer.add_argument("--model-artifact-id", required=True)
    infer.add_argument("--execution-code-commit", required=True)
    infer.add_argument("--seed", type=int, default=20260903)
    infer.add_argument("--sampling-seed", type=int, default=20260903)
    infer.add_argument("--repetitions", type=int, default=1)
    infer.add_argument("--temperature", type=float, default=0.0)
    infer.add_argument("--top-p", type=float, default=1.0)
    infer.add_argument("--timeout-seconds", type=float, default=900.0)
    infer.add_argument("--native-reasoning-effort", default="high")
    infer.add_argument("--maximum-transport-retries", type=int, default=1)
    infer.add_argument("--retry-delay-seconds", type=float, default=5.0)

    score = sub.add_parser("score")
    score.add_argument("--suite", type=Path, required=True)
    score.add_argument("--suite-commitment", type=Path, required=True)
    score.add_argument("--protocol", type=Path, required=True)
    score.add_argument("--prescore-input", type=Path, required=True)
    score.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.command == "prepare":
        return command_prepare(args)
    if args.command == "infer":
        return command_infer(args)
    return command_score(args)


if __name__ == "__main__":
    raise SystemExit(main())
