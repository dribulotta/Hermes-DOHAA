#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
export PYTHONDONTWRITEBYTECODE=1
export PYTHONOPTIMIZE=
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
cd "$SCRIPT_DIR"
python3 -c 'import sys; sys.exit(0 if __debug__ else "Python optimization must be disabled")'
sha256sum -c SHA256SUMS
python3 verify-sanitized-public-evidence-v4.py
