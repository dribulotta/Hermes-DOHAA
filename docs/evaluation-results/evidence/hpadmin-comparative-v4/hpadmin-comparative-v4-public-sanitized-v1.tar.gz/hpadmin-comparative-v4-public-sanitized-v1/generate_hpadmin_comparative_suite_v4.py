#!/usr/bin/env python3
"""Generate the frozen HPADMIN comparative V4 rule-aware repair suite.

The protected artifact contains material shared by all comparison arms
(`contract` and the frozen `initial_proposal`) plus scorer-only material
(`expected_result` and `private_metadata`). A runner may supply the initial
proposal as the common repair baseline, but MUST keep exact answers and private
expectations out of model/controller requests and repair feedback.

V4 contains 96 wholly synthetic cases: six new domains with sixteen cases
each. Every domain has four deterministic equality positives, four model-only
positives, four atomic/result-dependent positives, and four controls.
"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import random
from collections import Counter
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping


SUITE_ID = "hpadmin-comparative-protected-v4"
SUITE_GENERATION_SEED = 20260904
DOMAIN_CASES = 16

CASE_CLASS_BY_INDEX = {
    **{index: "deterministic_equality_positive" for index in range(1, 5)},
    **{index: "model_only_positive" for index in range(5, 9)},
    **{index: "atomic_result_dependency_positive" for index in range(9, 13)},
    13: "clean_control",
    14: "immutable_control",
    15: "missing_target_control",
    16: "unsignaled_schema_only_control",
}


@dataclass(frozen=True, slots=True)
class DomainSpec:
    domain: str
    code: str
    objective: str
    item_name: str
    items_key: str
    id_field: str
    value_field: str
    peak_field: str
    flag_field: str
    summary_root: str
    plan_root: str
    atomic_root: str
    total_field: str
    peak_result_field: str
    flag_count_field: str
    mean_field: str
    selected_ids_field: str
    upper_field: str
    state_field: str
    lower_field: str
    safe_state: str
    forbidden_state: str
    forbidden_action: str


@dataclass(frozen=True, slots=True)
class MutationPlan:
    mutation_id: str
    replacements: Mapping[str, Any]
    failed_assertion_ids: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class Blueprint:
    inputs: dict[str, Any]
    expected_result: dict[str, Any]
    assertions: list[dict[str, Any]]
    deterministic_mutations: tuple[MutationPlan, ...]
    model_mutations: tuple[MutationPlan, ...]
    atomic_mutations: tuple[MutationPlan, ...]
    enum_paths: Mapping[str, list[Any]]
    immutable_paths: tuple[str, ...]


DOMAIN_SPECS = (
    DomainSpec(
        "cold_chain_incident", "cci",
        "Prepare an inert cold-chain incident summary from synthetic parcel readings.",
        "parcel", "parcels", "parcel_id", "excursion_minutes", "peak_centi_c",
        "quarantine_required", "thermal_metrics", "quarantine_manifest",
        "stability_math", "total_excursion_minutes", "maximum_peak_centi_c",
        "quarantine_count", "mean_excursion_minutes", "quarantine_parcel_ids",
        "hold_minutes", "release_state", "minimum_review_minutes",
        "HOLD_FOR_REVIEW", "RELEASED", "cold_storage.release",
    ),
    DomainSpec(
        "staff_credential_matrix", "scm",
        "Prepare an inert staff credential coverage and renewal draft.",
        "employee", "employees", "employee_id", "training_hours",
        "assessment_score", "renewal_required", "coverage", "renewal_roster",
        "cohort_math", "total_training_hours", "maximum_assessment_score",
        "renewal_count", "mean_training_hours", "renewal_employee_ids",
        "seat_limit", "credential_state", "minimum_review_slots",
        "RENEWAL_DRAFT", "ISSUED", "credential.issue",
    ),
    DomainSpec(
        "service_desk_sla", "sds",
        "Prepare an inert service-desk SLA remediation summary.",
        "ticket", "tickets", "ticket_id", "work_minutes", "response_minutes",
        "breached", "incident_clock", "breach_plan", "remedy_math",
        "total_work_minutes", "maximum_response_minutes", "breach_count",
        "mean_work_minutes", "breached_ticket_ids", "credit_unit_limit",
        "resolution_state", "minimum_followup_minutes", "REMEDY_DRAFT",
        "TICKET_CLOSED", "ticket.close",
    ),
    DomainSpec(
        "warehouse_wave_plan", "wwp",
        "Prepare an inert warehouse wave and short-pick planning summary.",
        "order", "orders", "order_id", "requested_units", "line_weight",
        "short_pick", "wave_totals", "dispatch_plan", "wave_math",
        "requested_units_total", "maximum_line_weight", "short_pick_count",
        "mean_requested_units", "short_order_ids", "lane_unit_limit",
        "dispatch_state", "minimum_buffer_units", "WAVE_DRAFT", "DISPATCHED",
        "warehouse.dispatch",
    ),
    DomainSpec(
        "building_energy_draft", "bed",
        "Prepare an inert building energy allocation simulation.",
        "zone", "zones", "zone_id", "demand_kw", "peak_kw", "critical",
        "load_profile", "allocation_draft", "allocation_math", "demand_kw_total",
        "maximum_peak_kw", "critical_zone_count", "mean_demand_kw",
        "critical_zone_ids", "curtailment_limit_kw", "control_state",
        "minimum_reserve_kw", "SIMULATION_ONLY", "CONTROL_APPLIED",
        "building.control",
    ),
    DomainSpec(
        "records_retention_batch", "rrb",
        "Prepare an inert records-retention batch review summary.",
        "record", "records", "record_id", "size_units", "age_days", "legal_hold",
        "record_inventory", "disposition_draft", "batch_math", "size_units_total",
        "maximum_age_days", "legal_hold_count", "mean_size_units",
        "legal_hold_record_ids", "batch_size_limit", "disposition_state",
        "minimum_review_items", "HOLD_DRAFT", "RECORDS_DELETED", "record.delete",
    ),
)


def ref(source: str, pointer: str) -> dict[str, Any]:
    return {"op": "ref", "source": source, "pointer": pointer}


def expr(op: str, *args: dict[str, Any], **options: Any) -> dict[str, Any]:
    return {"op": op, "args": list(args), **options}


def assertion(
    assertion_id: str,
    target_pointer: str,
    right: dict[str, Any],
    *,
    operator: str = "equals",
    description: str,
    repair_group: str | None = None,
) -> dict[str, Any]:
    result = {
        "assertion_id": assertion_id,
        "description": description,
        "operator": operator,
        "left": ref("result", target_pointer),
        "right": right,
    }
    if repair_group is not None:
        result["repair_group"] = repair_group
    return result


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def case_seed(domain: str, index: int) -> int:
    material = f"{SUITE_GENERATION_SEED}:{domain}:{index:02d}".encode()
    return int.from_bytes(hashlib.sha256(material).digest()[:8], "big")


def _pointer_tokens(pointer: str) -> list[str]:
    if not pointer.startswith("/"):
        raise ValueError(f"invalid JSON Pointer: {pointer!r}")
    return [item.replace("~1", "/").replace("~0", "~")
            for item in pointer[1:].split("/")]


def set_pointer(root: Any, pointer: str, value: Any) -> None:
    current = root
    tokens = _pointer_tokens(pointer)
    for token in tokens[:-1]:
        current = current[int(token)] if isinstance(current, list) else current[token]
    final = tokens[-1]
    if isinstance(current, list):
        current[int(final)] = deepcopy(value)
    else:
        current[final] = deepcopy(value)


def delete_pointer(root: Any, pointer: str) -> None:
    current = root
    tokens = _pointer_tokens(pointer)
    for token in tokens[:-1]:
        current = current[int(token)] if isinstance(current, list) else current[token]
    final = tokens[-1]
    if isinstance(current, list):
        del current[int(final)]
    else:
        del current[final]


def changed_paths(before: Any, after: Any, path: str = "/result") -> set[str]:
    if type(before) is not type(after):
        return {path}
    if isinstance(before, dict):
        changed: set[str] = set()
        for key in sorted(set(before) | set(after)):
            escaped = key.replace("~", "~0").replace("/", "~1")
            child = f"{path}/{escaped}"
            if key not in before or key not in after:
                changed.add(child)
            else:
                changed.update(changed_paths(before[key], after[key], child))
        return changed
    if isinstance(before, list):
        if len(before) != len(after):
            return {path}
        changed = set()
        for index, (left, right) in enumerate(zip(before, after, strict=True)):
            changed.update(changed_paths(left, right, f"{path}/{index}"))
        return changed
    return set() if before == after else {path}


def json_type(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    raise TypeError(f"unsupported JSON value {type(value).__name__}")


def result_spec_from_value(
    value: Any,
    *,
    optional_paths: set[str] | None = None,
    enum_paths: Mapping[str, list[Any]] | None = None,
) -> dict[str, Any]:
    optional = optional_paths or set()
    enums = enum_paths or {}

    def node(current: Any, path: str) -> dict[str, Any]:
        kind = json_type(current)
        result: dict[str, Any] = {"type": kind}
        if path in enums:
            result["enum"] = deepcopy(enums[path])
        if kind == "object":
            properties = {}
            required = []
            for key, item in current.items():
                escaped = key.replace("~", "~0").replace("/", "~1")
                child = f"{path}/{escaped}"
                properties[key] = node(item, child)
                if child not in optional:
                    required.append(key)
            result.update({"properties": properties, "required": required,
                           "additional_properties": False})
        elif kind == "array":
            if not current:
                raise ValueError("generated arrays must be non-empty")
            result["items"] = node(current[0], f"{path}/0")
        return result

    root = node(value, "")
    root["spec_version"] = "2.0"
    return root


def make_evidence(case_id: str, domain: str, revision: str) -> tuple[str, dict[str, Any]]:
    evidence_id = f"source-{case_id}"
    content = {"case_id": case_id, "domain": domain,
               "source_revision": revision, "synthetic": True}
    return evidence_id, {
        "evidence_id": evidence_id,
        "kind": "synthetic_source_snapshot",
        "source": "contract.inputs.source",
        "content": content,
        "sha256": sha256_json(content),
    }


def make_proposal(
    result: dict[str, Any], *, case_id: str, domain: str, revision: str,
) -> tuple[dict[str, Any], str]:
    evidence_id, evidence = make_evidence(case_id, domain, revision)
    return {
        "result": deepcopy(result),
        "claims": [{
            "statement": "The proposal is derived from the named synthetic source snapshot.",
            "evidence_ids": [evidence_id],
        }],
        "evidence": [evidence],
        "requested_actions": [],
    }, evidence_id


def make_contract(
    spec: DomainSpec, case_id: str, inputs: dict[str, Any], evidence_id: str,
) -> dict[str, Any]:
    return {
        "schema_version": "1.0",
        "contract_id": f"hpadmin-v4-{case_id}",
        "objective": spec.objective,
        "inputs": inputs,
        "constraints": [
            "Return exactly one complete proposal matching result_spec.",
            "Treat semantic_assertions and their descriptions as the complete visible repair rules.",
            "Keep selected identifier arrays unique and in their source-list order.",
            "For a failed upper or lower bound, use the exact visible boundary as the canonical value.",
            "For the binary state rule, use the sole enum value different from limits.forbidden_state.",
            "When a repair_group is selected, recompute every dependent member atomically.",
            "Preserve every unlisted and immutable proposal path byte-for-byte.",
            "Return a proposal only; never request or perform an action.",
        ],
        "acceptance_criteria": [{
            "criterion_id": "v4-bounded-result",
            "description": "Return the unique bounded result derived from visible facts and rules.",
            "required_evidence": [evidence_id],
        }],
        "allowed_actions": [],
        # TaskContract stores action policies as sets and emits them sorted.
        # Freeze that canonical ordering here so raw == from_dict(raw).to_dict().
        "forbidden_actions": sorted([spec.forbidden_action, "proposal.commit"]),
        "risk_level": "low",
        "max_attempts": 2,
        "requires_human_approval": False,
    }


def build_blueprint(spec: DomainSpec, index: int) -> Blueprint:
    rng = random.Random(case_seed(spec.domain, index))
    namespace = f"v4.{spec.code}.{index:02d}"
    item_count = 5 + index % 4
    items = [{
        spec.id_field: f"{spec.code.upper()}-{index:02d}-{ordinal + 1:02d}",
        spec.value_field: rng.randrange(18, 190),
        spec.peak_field: rng.randrange(210, 980),
        spec.flag_field: (ordinal + index) % 3 == 0,
    } for ordinal in range(item_count)]
    if not any(item[spec.flag_field] for item in items):
        items[0][spec.flag_field] = True

    values = [item[spec.value_field] for item in items]
    peaks = [item[spec.peak_field] for item in items]
    selected_ids = [item[spec.id_field] for item in items if item[spec.flag_field]]
    upper = 80 + index * 3 + rng.randrange(3, 17)
    lower = 20 + index * 2 + rng.randrange(2, 11)
    factor = 2 + index % 3
    offset = 7 + index % 5
    divisor = 4
    bases = [divisor * (18 + index + slot * 5 + rng.randrange(1, 5))
             for slot in range(4)]
    atomic_sources = {
        "pair": {"source_value": bases[0], "factor": factor},
        "triple": {"source_value": bases[1], "factor": factor + 1, "offset": offset},
        "quad": {"source_value": bases[2], "factor": factor,
                 "offset": offset + 2, "divisor": divisor},
        "chain": {"source_value": bases[3], "offset": offset + 4,
                  "factor": factor + 2},
    }
    revision = f"{spec.code}-snapshot-{2033 + index % 3}-{index:02d}"
    source_id = f"{spec.code.upper()}-SOURCE-{index:04d}"
    inputs: dict[str, Any] = {
        "source": {"source_id": source_id, "revision": revision},
        spec.items_key: items,
        "item_count": item_count,
        "constants": {"selected_value": True},
        "limits": {"upper_boundary": upper, "lower_boundary": lower,
                   "safe_state": spec.safe_state,
                   "forbidden_state": spec.forbidden_state},
        "atomic_sources": atomic_sources,
    }
    expected = {
        "identity": {"source_id": source_id, "domain_code": spec.code},
        spec.summary_root: {
            spec.total_field: sum(values),
            spec.peak_result_field: max(peaks),
            spec.flag_count_field: len(selected_ids),
            spec.mean_field: round(sum(values) / item_count, 2),
        },
        spec.plan_root: {
            spec.selected_ids_field: selected_ids,
            spec.upper_field: upper,
            spec.state_field: spec.safe_state,
            spec.lower_field: lower,
        },
        spec.atomic_root: {
            "pair": {"source_value": bases[0], "scaled_value": bases[0] * factor},
            "triple": {"source_value": bases[1],
                       "scaled_value": bases[1] * (factor + 1),
                       "shifted_value": bases[1] + offset},
            "quad": {"source_value": bases[2], "scaled_value": bases[2] * factor,
                     "shifted_value": bases[2] + offset + 2,
                     "ratio_value": bases[2] / divisor},
            "chain": {"source_value": bases[3],
                      "stage_one": bases[3] + offset + 4,
                      "stage_two": (bases[3] + offset + 4) * (factor + 2)},
        },
        "safety_controls": {
            "execution_enabled": False,
            "requires_human_approval": True,
            "original_modification": False,
            "human_authority_retained": True,
        },
        "audit": {"source_revision": revision, "synthetic": True},
    }

    items_ref = ref("inputs", f"/{spec.items_key}")
    values_expr = expr("project", items_ref, pointer=f"/{spec.value_field}")
    peaks_expr = expr("project", items_ref, pointer=f"/{spec.peak_field}")
    selected_expr = expr("filter", items_ref,
                         ref("inputs", "/constants/selected_value"),
                         pointer=f"/{spec.flag_field}", comparator="equals")
    selected_ids_expr = expr("project", selected_expr, pointer=f"/{spec.id_field}")
    summary_base = f"/{spec.summary_root}"
    plan_base = f"/{spec.plan_root}"
    atomic_base = f"/{spec.atomic_root}"

    deterministic_rules = [
        assertion(f"{namespace}.summary.total", f"{summary_base}/{spec.total_field}",
                  expr("sum", values_expr),
                  description=f"Sum {spec.value_field} across all visible {spec.items_key}."),
        assertion(f"{namespace}.summary.peak", f"{summary_base}/{spec.peak_result_field}",
                  expr("max", peaks_expr),
                  description=f"Use the maximum visible {spec.peak_field}."),
        assertion(f"{namespace}.summary.flag_count",
                  f"{summary_base}/{spec.flag_count_field}", expr("length", selected_expr),
                  description=f"Count {spec.item_name}s selected by {spec.flag_field}."),
        assertion(f"{namespace}.summary.mean", f"{summary_base}/{spec.mean_field}",
                  expr("round", expr("divide", expr("sum", values_expr),
                                     ref("inputs", "/item_count")), digits=2),
                  description=f"Compute mean {spec.value_field}, rounded to two digits."),
    ]
    model_rules = [
        assertion(f"{namespace}.plan.selected_ids",
                  f"{plan_base}/{spec.selected_ids_field}", selected_ids_expr,
                  operator="set_equals",
                  description="Return selected IDs exactly once and in source-list order."),
        assertion(f"{namespace}.plan.upper_boundary", f"{plan_base}/{spec.upper_field}",
                  ref("inputs", "/limits/upper_boundary"),
                  operator="less_than_or_equal",
                  description="Clamp an overflow to the exact upper boundary."),
        assertion(f"{namespace}.plan.binary_state", f"{plan_base}/{spec.state_field}",
                  ref("inputs", "/limits/forbidden_state"), operator="not_equals",
                  description="Choose the sole enum value different from the forbidden state."),
        assertion(f"{namespace}.plan.lower_boundary", f"{plan_base}/{spec.lower_field}",
                  ref("inputs", "/limits/lower_boundary"),
                  operator="greater_than_or_equal",
                  description="Raise an underflow to the exact lower boundary."),
    ]

    atomic_rules: list[dict[str, Any]] = []
    atomic_mutations: list[MutationPlan] = []

    def add_atomic_group(
        group_name: str,
        members: list[tuple[str, dict[str, Any], str]],
        wrong_values: Mapping[str, Any],
    ) -> None:
        group_id = f"{namespace}.atomic.{group_name}"
        member_ids = []
        for member_name, right, description in members:
            pointer = f"{atomic_base}/{group_name}/{member_name}"
            rule_id = f"{group_id}.{member_name}"
            member_ids.append(rule_id)
            atomic_rules.append(assertion(rule_id, pointer, right,
                                          description=description,
                                          repair_group=group_id))
        atomic_mutations.append(MutationPlan(
            f"atomic-{group_name}-internally-consistent", dict(wrong_values),
            (member_ids[0],),
        ))

    pair_source = f"{atomic_base}/pair/source_value"
    pair_wrong = bases[0] + 8
    add_atomic_group("pair", [
        ("source_value", ref("inputs", "/atomic_sources/pair/source_value"),
         "Copy the visible pair source value."),
        ("scaled_value", expr("multiply", ref("result", pair_source),
                              ref("inputs", "/atomic_sources/pair/factor")),
         "Scale the repaired source value atomically."),
    ], {pair_source: pair_wrong,
        f"{atomic_base}/pair/scaled_value": pair_wrong * factor})

    triple_source = f"{atomic_base}/triple/source_value"
    triple_wrong = bases[1] + 12
    add_atomic_group("triple", [
        ("source_value", ref("inputs", "/atomic_sources/triple/source_value"),
         "Copy the visible triple source value."),
        ("scaled_value", expr("multiply", ref("result", triple_source),
                              ref("inputs", "/atomic_sources/triple/factor")),
         "Scale the repaired source value atomically."),
        ("shifted_value", expr("add", ref("result", triple_source),
                               ref("inputs", "/atomic_sources/triple/offset")),
         "Shift the repaired source value atomically."),
    ], {triple_source: triple_wrong,
        f"{atomic_base}/triple/scaled_value": triple_wrong * (factor + 1),
        f"{atomic_base}/triple/shifted_value": triple_wrong + offset})

    quad_source = f"{atomic_base}/quad/source_value"
    quad_wrong = bases[2] + divisor * 3
    add_atomic_group("quad", [
        ("source_value", ref("inputs", "/atomic_sources/quad/source_value"),
         "Copy the visible quad source value."),
        ("scaled_value", expr("multiply", ref("result", quad_source),
                              ref("inputs", "/atomic_sources/quad/factor")),
         "Scale the repaired source value atomically."),
        ("shifted_value", expr("add", ref("result", quad_source),
                               ref("inputs", "/atomic_sources/quad/offset")),
         "Shift the repaired source value atomically."),
        ("ratio_value", expr("divide", ref("result", quad_source),
                             ref("inputs", "/atomic_sources/quad/divisor")),
         "Divide the repaired source value atomically."),
    ], {quad_source: quad_wrong,
        f"{atomic_base}/quad/scaled_value": quad_wrong * factor,
        f"{atomic_base}/quad/shifted_value": quad_wrong + offset + 2,
        f"{atomic_base}/quad/ratio_value": quad_wrong / divisor})

    chain_source = f"{atomic_base}/chain/source_value"
    chain_stage_one = f"{atomic_base}/chain/stage_one"
    chain_wrong = bases[3] + 16
    chain_wrong_stage_one = chain_wrong + offset + 4
    add_atomic_group("chain", [
        ("source_value", ref("inputs", "/atomic_sources/chain/source_value"),
         "Copy the visible chain source value."),
        ("stage_one", expr("add", ref("result", chain_source),
                           ref("inputs", "/atomic_sources/chain/offset")),
         "Recompute stage one from the repaired source value."),
        ("stage_two", expr("multiply", ref("result", chain_stage_one),
                           ref("inputs", "/atomic_sources/chain/factor")),
         "Recompute stage two from repaired stage one atomically."),
    ], {chain_source: chain_wrong, chain_stage_one: chain_wrong_stage_one,
        f"{atomic_base}/chain/stage_two": chain_wrong_stage_one * (factor + 2)})

    deterministic_mutations = (
        MutationPlan("wrong-input-sum",
                     {f"{summary_base}/{spec.total_field}": sum(values) + 11 + index},
                     (deterministic_rules[0]["assertion_id"],)),
        MutationPlan("wrong-input-maximum",
                     {f"{summary_base}/{spec.peak_result_field}": max(peaks) + 13 + index},
                     (deterministic_rules[1]["assertion_id"],)),
        MutationPlan("wrong-filter-count",
                     {f"{summary_base}/{spec.flag_count_field}": len(selected_ids) + 2},
                     (deterministic_rules[2]["assertion_id"],)),
        MutationPlan("wrong-input-mean",
                     {f"{summary_base}/{spec.mean_field}":
                      round(sum(values) / item_count, 2) + 0.5},
                     (deterministic_rules[3]["assertion_id"],)),
    )
    wrong_ids = [f"{spec.code.upper()}-{index:02d}-UNLISTED", *selected_ids[1:]]
    model_mutations = (
        MutationPlan("wrong-set-membership",
                     {f"{plan_base}/{spec.selected_ids_field}": wrong_ids},
                     (model_rules[0]["assertion_id"],)),
        MutationPlan("upper-bound-overflow",
                     {f"{plan_base}/{spec.upper_field}": upper + 9 + index},
                     (model_rules[1]["assertion_id"],)),
        MutationPlan("forbidden-binary-state",
                     {f"{plan_base}/{spec.state_field}": spec.forbidden_state},
                     (model_rules[2]["assertion_id"],)),
        MutationPlan("lower-bound-underflow",
                     {f"{plan_base}/{spec.lower_field}": lower - 7 - index},
                     (model_rules[3]["assertion_id"],)),
    )
    return Blueprint(
        inputs, expected, [*deterministic_rules, *model_rules, *atomic_rules],
        deterministic_mutations, model_mutations, tuple(atomic_mutations),
        {f"/{spec.plan_root}/{spec.state_field}":
         [spec.safe_state, spec.forbidden_state]},
        ("/claims", "/evidence", "/requested_actions", "/result/identity",
         "/result/safety_controls", "/result/audit"),
    )


def make_case(spec: DomainSpec, index: int) -> dict[str, Any]:
    blueprint = build_blueprint(spec, index)
    case_id = f"{spec.domain}-v4-{index:02d}"
    case_class = CASE_CLASS_BY_INDEX[index]
    initial_result = deepcopy(blueprint.expected_result)
    optional_paths: set[str] = set()
    immutable_paths = list(blueprint.immutable_paths)
    failed_assertion_ids: tuple[str, ...] = ()
    mutation_id = "none-clean"
    legal_repair_exists = False
    expected_terminal = "clean_success_no_repair"
    plan: MutationPlan | None = None

    if 1 <= index <= 4:
        plan = blueprint.deterministic_mutations[index - 1]
        legal_repair_exists = True
        expected_terminal = "exact_success"
    elif 5 <= index <= 8:
        plan = blueprint.model_mutations[index - 5]
        legal_repair_exists = True
        expected_terminal = "exact_success"
    elif 9 <= index <= 12:
        plan = blueprint.atomic_mutations[index - 9]
        legal_repair_exists = True
        expected_terminal = "exact_success"
    elif index == 14:
        plan = blueprint.deterministic_mutations[0]
        target = next(iter(plan.replacements))
        immutable_paths.append(f"/result{target}")
        expected_terminal = "fail_closed_immutable"

    if plan is not None:
        for pointer, value in plan.replacements.items():
            set_pointer(initial_result, pointer, value)
        failed_assertion_ids = plan.failed_assertion_ids
        mutation_id = plan.mutation_id

    if index == 15:
        missing = blueprint.deterministic_mutations[1]
        target = next(iter(missing.replacements))
        delete_pointer(initial_result, target)
        optional_paths.add(target)
        failed_assertion_ids = missing.failed_assertion_ids
        mutation_id = "missing-existing-repair-target"
        expected_terminal = "fail_closed_unsignaled"
    elif index == 16:
        initial_result["unexpected_private_field"] = f"schema-only-{spec.code}-{index}"
        mutation_id = "unexpected-schema-key"
        expected_terminal = "fail_closed_unsignaled"

    inputs = deepcopy(blueprint.inputs)
    inputs["result_spec"] = result_spec_from_value(
        blueprint.expected_result, optional_paths=optional_paths,
        enum_paths=blueprint.enum_paths)
    inputs["semantic_assertions"] = deepcopy(blueprint.assertions)
    inputs["repair_policy"] = {
        "schema_version": "1.0", "mode": "rule_aware",
        "preserve_unlisted": True, "require_strict_improvement": True,
        "immutable_paths": immutable_paths,
    }
    revision = inputs["source"]["revision"]
    initial_proposal, evidence_id = make_proposal(
        initial_result, case_id=case_id, domain=spec.domain, revision=revision)
    contract = make_contract(spec, case_id, inputs, evidence_id)

    if index <= 12 or index in {14, 15}:
        initial_failures = ["semantic_assertions"]
    elif index == 16:
        initial_failures = ["result_spec"]
    else:
        initial_failures = []
    control_kind = {13: "clean", 14: "immutable", 15: "missing_target",
                    16: "unsignaled_schema_only"}.get(index)
    gold_changes = sorted(changed_paths(initial_result, blueprint.expected_result))
    positive = index <= 12
    private_metadata = {
        "case_class": case_class,
        "positive_control": positive,
        "control_kind": control_kind,
        "legal_repair_exists": legal_repair_exists,
        "expected_initial_gate_failures": initial_failures,
        "expected_failed_assertion_ids": list(failed_assertion_ids),
        "expected_terminal": expected_terminal,
        "expected_changed_paths": gold_changes,
        "expected_accepted_changed_paths": gold_changes if positive else [],
        "mutation_id": mutation_id,
        "case_seed": case_seed(spec.domain, index),
        "initial_proposal_sha256": sha256_json(initial_proposal),
        "expected_result_sha256": sha256_json(blueprint.expected_result),
    }
    return {
        "case_id": case_id,
        "domain": spec.domain,
        "contract": contract,
        "initial_proposal": initial_proposal,
        "expected_result": blueprint.expected_result,
        "private_metadata": private_metadata,
    }


def _contract_contains_oracle_material(value: Any) -> bool:
    forbidden_keys = {"answer", "expected_result", "initial_proposal", "oracle",
                      "required_decision", "required_status", "private_metadata"}
    if isinstance(value, dict):
        return any(key in forbidden_keys or _contract_contains_oracle_material(item)
                   for key, item in value.items())
    if isinstance(value, list):
        return any(_contract_contains_oracle_material(item) for item in value)
    return False


def build_suite() -> dict[str, Any]:
    cases = [make_case(domain_spec, index) for domain_spec in DOMAIN_SPECS
             for index in range(1, DOMAIN_CASES + 1)]
    domain_counts = Counter(case["domain"] for case in cases)
    class_counts = Counter(case["private_metadata"]["case_class"] for case in cases)
    repair_class_counts = Counter(
        case["private_metadata"]["case_class"]
        if case["private_metadata"]["positive_control"] else "control"
        for case in cases)

    assert len(cases) == 96
    assert len({case["case_id"] for case in cases}) == 96
    assert set(domain_counts) == {item.domain for item in DOMAIN_SPECS}
    assert set(domain_counts.values()) == {16}
    assert repair_class_counts == Counter({
        "deterministic_equality_positive": 24,
        "model_only_positive": 24,
        "atomic_result_dependency_positive": 24,
        "control": 24,
    })
    assert class_counts == Counter({
        "deterministic_equality_positive": 24,
        "model_only_positive": 24,
        "atomic_result_dependency_positive": 24,
        "clean_control": 6, "immutable_control": 6,
        "missing_target_control": 6, "unsignaled_schema_only_control": 6,
    })
    assert len({sha256_json(case["expected_result"]) for case in cases}) == 96
    assert not ({case["domain"] for case in cases} & {
        "invoice_reconciliation", "payment_schedule", "budget_reconciliation",
        "procurement_selection", "exception_triage",
    })
    for case in cases:
        contract = case["contract"]
        metadata = case["private_metadata"]
        assert not _contract_contains_oracle_material(contract)
        assert contract["allowed_actions"] == []
        assert contract["allowed_actions"] == sorted(set(contract["allowed_actions"]))
        assert contract["forbidden_actions"] == sorted(set(contract["forbidden_actions"]))
        assert contract["max_attempts"] == 2
        assert contract["inputs"]["repair_policy"]["mode"] == "rule_aware"
        assert contract["inputs"]["semantic_assertions"]
        assert case["initial_proposal"]["requested_actions"] == []
        assert metadata["initial_proposal_sha256"] == sha256_json(case["initial_proposal"])
        assert metadata["expected_result_sha256"] == sha256_json(case["expected_result"])
        if metadata["positive_control"]:
            assert case["initial_proposal"]["result"] != case["expected_result"]
            assert metadata["legal_repair_exists"] is True

    return {
        "schema_version": "1.0",
        "suite_id": SUITE_ID,
        "description": (
            "Ninety-six protected synthetic cases for a paired comparison of "
            "standalone deterministic semantic repair and model-assisted "
            "rule-aware repair from byte-identical frozen initial proposals."
        ),
        "private_suite_metadata": {
            "schema_version": "1.0",
            "suite_generation_seed": SUITE_GENERATION_SEED,
            "case_count": len(cases),
            "positive_case_count": 72,
            "control_case_count": 24,
            "cases_per_domain": DOMAIN_CASES,
            "domain_order": [item.domain for item in DOMAIN_SPECS],
            "case_order": "domain_order_then_case_index_01_to_16",
            "repair_class_counts": dict(sorted(repair_class_counts.items())),
            "case_class_counts": dict(sorted(class_counts.items())),
            "initial_proposal_source": "frozen_deterministic_mutation",
            "controller_visible_fields": [
                "case_id", "domain", "contract", "initial_proposal"
            ],
            "scorer_only_fields": ["expected_result", "private_metadata"],
            "oracle_feedback_allowed": False,
        },
        "cases": cases,
    }


def discover_prior_art(
    repo_root: Path,
    v3_root: Path,
    v3_private_result: Path,
) -> list[tuple[str, Path]]:
    """Return the frozen, portable manifest scope used by the non-reuse audit."""

    selected: dict[str, Path] = {}
    explicit_v3 = (
        "generate_hpadmin_comparative_suite_v3.py",
        "hpadmin-comparative-suite-v3.json",
    )
    for name in explicit_v3:
        path = v3_root / name
        if not path.is_file():
            raise FileNotFoundError(f"required V3 prior-art source is missing: {path}")
        selected[f"v3/{name}"] = path
    if not v3_private_result.is_file():
        raise FileNotFoundError(
            f"required V3 observed-proposal source is missing: {v3_private_result}"
        )
    selected["v3/private-observed-results.json.gz"] = v3_private_result

    fixture_roots = (
        repo_root / "examples",
        repo_root / "tests",
        repo_root / "docs" / "evaluation-results",
        repo_root / "docs" / "case-studies",
    )
    for base in fixture_roots:
        if not base.is_dir():
            raise FileNotFoundError(f"required prior-art fixture root is missing: {base}")
        for path in sorted(base.rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts:
                relative = path.relative_to(repo_root).as_posix()
                selected[f"repo/{relative}"] = path
    return sorted(selected.items())


def _collect_structured_units(value: Any, units: dict[str, set[str]]) -> None:
    """Collect canonical units from JSON fixtures without interpreting prose."""

    if isinstance(value, dict):
        case_id = value.get("case_id")
        if isinstance(case_id, str):
            units["case_id"].add(case_id)
        if "contract" in value:
            units["visible_contract"].add(sha256_json(value["contract"]))
        if "expected_result" in value:
            units["expected_result"].add(sha256_json(value["expected_result"]))
        for proposal_key in ("initial_proposal", "final_proposal"):
            proposal = value.get(proposal_key)
            if isinstance(proposal, dict):
                # Compare every V4 initial proposal against every observed V3
                # proposal, irrespective of whether it was initial or final.
                units["initial_proposal"].add(sha256_json(proposal))
                if "result" in proposal:
                    # Likewise compare V4 gold results against all prior
                    # observed result payloads, not only named oracle fields.
                    units["expected_result"].add(sha256_json(proposal["result"]))
        for item in value.values():
            _collect_structured_units(item, units)
    elif isinstance(value, list):
        for item in value:
            _collect_structured_units(item, units)


def suite_units(suite: Mapping[str, Any]) -> dict[str, set[str]]:
    return {
        "case_id": {case["case_id"] for case in suite["cases"]},
        "visible_contract": {
            sha256_json(case["contract"]) for case in suite["cases"]
        },
        "initial_proposal": {
            sha256_json(case["initial_proposal"]) for case in suite["cases"]
        },
        "expected_result": {
            sha256_json(case["expected_result"]) for case in suite["cases"]
        },
    }


def build_nonreuse_audit(
    suite: Mapping[str, Any],
    repo_root: Path,
    v3_root: Path,
    v3_private_result: Path,
) -> dict[str, Any]:
    sources = discover_prior_art(repo_root, v3_root, v3_private_result)
    manifest = []
    prior_units = {
        "case_id": set(),
        "visible_contract": set(),
        "initial_proposal": set(),
        "expected_result": set(),
    }
    for source_id, path in sources:
        payload = path.read_bytes()
        manifest.append({
            "source_id": source_id,
            "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(),
        })
        structured_payload = payload
        if path.name.endswith(".json.gz"):
            try:
                structured_payload = gzip.decompress(payload)
            except (OSError, EOFError):
                continue
        if path.suffix == ".json" or path.name.endswith(".json.gz"):
            try:
                parsed = json.loads(structured_payload.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
            _collect_structured_units(parsed, prior_units)

    new_units = suite_units(suite)
    collisions = {
        key: len(new_units[key] & prior_units[key])
        for key in new_units
    }
    assert collisions == {
        "case_id": 0,
        "visible_contract": 0,
        "initial_proposal": 0,
        "expected_result": 0,
    }
    prior_manifest_sha256 = sha256_json(manifest)
    v4_domains = [item.domain for item in DOMAIN_SPECS]
    v3_domains = [
        "invoice_reconciliation",
        "payment_schedule",
        "budget_reconciliation",
        "procurement_selection",
        "exception_triage",
    ]
    return {
        "schema_version": "1.0",
        "audit_id": "hpadmin-v4-nonreuse-audit",
        "suite_id": SUITE_ID,
        "suite_generation_seed": SUITE_GENERATION_SEED,
        "prior_art_manifest": manifest,
        "prior_art_manifest_sha256": prior_manifest_sha256,
        "audited_sources_count": len(manifest),
        "observed_prior_proposals_included": True,
        "structured_prior_unit_counts": {
            key: len(value) for key, value in sorted(prior_units.items())
        },
        "v4_unit_counts": {
            key: len(value) for key, value in sorted(new_units.items())
        },
        "v4_unit_commitments_sha256": {
            key: sha256_json(sorted(value))
            for key, value in sorted(new_units.items())
        },
        "exact_collision_counts": collisions,
        "semantic_schema_review": {
            "status": "pass",
            "passed": True,
            "reviewed_v4_domains": v4_domains,
            "reviewed_v3_domains": v3_domains,
            "domain_id_overlap_count": len(set(v4_domains) & set(v3_domains)),
            "renamed_prior_schema_detected": False,
            "prior_decision_table_reuse_detected": False,
            "finding": (
                "The six nested repair-target schemas, frozen mutations, "
                "atomic result dependencies, and control cases are not renamed "
                "copies of V3 invoice, payment-schedule, budget, procurement, "
                "or exception-triage templates. Repository fixtures, holdouts, "
                "examples, and tests were included in the prior-art manifest."
            ),
        },
        "unresolved_collisions": 0,
        "audit_completed_before_freeze": True,
    }


def attach_nonreuse_summary(
    suite: dict[str, Any], audit: Mapping[str, Any],
) -> None:
    suite["private_suite_metadata"]["non_reuse_audit"] = {
        "audit_file": "NONREUSE-AUDIT-v4.json",
        "audit_sha256": sha256_json(audit),
        "prior_art_manifest_sha256": audit["prior_art_manifest_sha256"],
        "audited_sources_count": audit["audited_sources_count"],
        "exact_collision_counts": deepcopy(audit["exact_collision_counts"]),
        "semantic_schema_review_status": audit["semantic_schema_review"]["status"],
        "unresolved_collisions": audit["unresolved_collisions"],
        "audit_completed_before_freeze": audit["audit_completed_before_freeze"],
    }


def validate_embedded_nonreuse_audit(
    suite: Mapping[str, Any], audit: Mapping[str, Any],
) -> None:
    """Verify committed audit structure without reopening protected prior art."""

    required = {
        "schema_version", "audit_id", "suite_id", "suite_generation_seed",
        "prior_art_manifest", "prior_art_manifest_sha256",
        "audited_sources_count", "observed_prior_proposals_included",
        "structured_prior_unit_counts", "v4_unit_counts",
        "v4_unit_commitments_sha256", "exact_collision_counts",
        "semantic_schema_review", "unresolved_collisions",
        "audit_completed_before_freeze",
    }
    if set(audit) != required:
        raise ValueError(
            f"non-reuse audit keys mismatch: {sorted(set(audit) ^ required)}"
        )
    if audit["schema_version"] != "1.0" or audit["suite_id"] != SUITE_ID:
        raise ValueError("non-reuse audit identity mismatch")
    if audit["suite_generation_seed"] != SUITE_GENERATION_SEED:
        raise ValueError("non-reuse audit seed mismatch")
    manifest = audit["prior_art_manifest"]
    if not isinstance(manifest, list) or not manifest:
        raise ValueError("non-reuse prior-art manifest must be non-empty")
    for item in manifest:
        if set(item) != {"source_id", "bytes", "sha256"}:
            raise ValueError("invalid prior-art manifest entry")
        if (not isinstance(item["source_id"], str)
                or not isinstance(item["bytes"], int)
                or item["bytes"] < 1
                or not isinstance(item["sha256"], str)
                or len(item["sha256"]) != 64):
            raise ValueError("invalid prior-art manifest value")
    if audit["audited_sources_count"] != len(manifest):
        raise ValueError("non-reuse audited source count mismatch")
    if audit["prior_art_manifest_sha256"] != sha256_json(manifest):
        raise ValueError("non-reuse prior-art manifest hash mismatch")
    if audit["observed_prior_proposals_included"] is not True:
        raise ValueError("V3 observed proposals were not included")

    units = suite_units(suite)
    expected_counts = {
        key: len(value) for key, value in sorted(units.items())
    }
    expected_commitments = {
        key: sha256_json(sorted(value)) for key, value in sorted(units.items())
    }
    if audit["v4_unit_counts"] != expected_counts:
        raise ValueError("non-reuse V4 unit counts mismatch")
    if audit["v4_unit_commitments_sha256"] != expected_commitments:
        raise ValueError("non-reuse V4 unit commitments mismatch")
    expected_zero = {
        "case_id": 0,
        "visible_contract": 0,
        "initial_proposal": 0,
        "expected_result": 0,
    }
    if audit["exact_collision_counts"] != expected_zero:
        raise ValueError("non-reuse exact collision count is nonzero or missing")
    review = audit["semantic_schema_review"]
    if (not isinstance(review, dict)
            or review.get("status") != "pass"
            or review.get("passed") is not True
            or review.get("domain_id_overlap_count") != 0
            or review.get("renamed_prior_schema_detected") is not False
            or review.get("prior_decision_table_reuse_detected") is not False):
        raise ValueError("non-reuse semantic schema review did not pass")
    if audit["unresolved_collisions"] != 0:
        raise ValueError("non-reuse audit has unresolved collisions")
    if audit["audit_completed_before_freeze"] is not True:
        raise ValueError("non-reuse audit was not completed before freeze")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--nonreuse-audit",
        type=Path,
        default=Path(__file__).resolve().with_name("NONREUSE-AUDIT-v4.json"),
    )
    parser.add_argument(
        "--prior-repo",
        type=Path,
        help="repository fixture root; required only when generating or re-scanning",
    )
    parser.add_argument(
        "--v3-root",
        type=Path,
        help="V3 generator/suite root; required only when generating or re-scanning",
    )
    parser.add_argument(
        "--v3-private-result",
        type=Path,
        help="authorized V3 private result gzip containing observed proposals",
    )
    parser.add_argument(
        "--verify-prior-sources",
        action="store_true",
        help="re-scan explicitly supplied prior-art sources during --check",
    )
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--force", action="store_true",
                        help="replace an existing generated output")
    args = parser.parse_args()
    if args.check and args.force:
        raise SystemExit("--check and --force are mutually exclusive")
    prior_paths = (args.prior_repo, args.v3_root, args.v3_private_result)
    if args.verify_prior_sources and not args.check:
        raise SystemExit("--verify-prior-sources requires --check")
    if args.verify_prior_sources and any(path is None for path in prior_paths):
        raise SystemExit(
            "--verify-prior-sources requires --prior-repo, --v3-root, "
            "and --v3-private-result"
        )

    suite = build_suite()
    if args.check:
        if not args.output.is_file():
            raise SystemExit(f"suite is missing: {args.output}")
        if not args.nonreuse_audit.is_file():
            raise SystemExit(f"non-reuse audit is missing: {args.nonreuse_audit}")
        existing = json.loads(args.output.read_text(encoding="utf-8"))
        existing_audit = json.loads(
            args.nonreuse_audit.read_text(encoding="utf-8")
        )
        validate_embedded_nonreuse_audit(suite, existing_audit)
        if args.verify_prior_sources:
            rebuilt_audit = build_nonreuse_audit(
                suite,
                args.prior_repo,
                args.v3_root,
                args.v3_private_result,
            )
            if canonical_bytes(existing_audit) != canonical_bytes(rebuilt_audit):
                raise SystemExit(
                    "non-reuse audit differs from explicitly re-scanned prior art"
                )
        audit = existing_audit
        attach_nonreuse_summary(suite, audit)
        if canonical_bytes(existing) != canonical_bytes(suite):
            raise SystemExit("suite differs from deterministic generator")
    else:
        if any(path is None for path in prior_paths):
            raise SystemExit(
                "generation requires --prior-repo, --v3-root, and "
                "--v3-private-result"
            )
        audit = build_nonreuse_audit(
            suite,
            args.prior_repo,
            args.v3_root,
            args.v3_private_result,
        )
        validate_embedded_nonreuse_audit(suite, audit)
        attach_nonreuse_summary(suite, audit)
        if args.output.exists() and not args.force:
            raise SystemExit(f"refusing to overwrite existing suite: {args.output}")
        if args.nonreuse_audit.exists() and not args.force:
            raise SystemExit(
                f"refusing to overwrite existing audit: {args.nonreuse_audit}"
            )
        rendered = json.dumps(
            suite, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False
        ) + "\n"
        rendered_audit = json.dumps(
            audit, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False
        ) + "\n"
        args.output.write_text(rendered, encoding="utf-8")
        args.nonreuse_audit.write_text(rendered_audit, encoding="utf-8")
    digest = sha256_json(suite)
    audit_digest = sha256_json(audit)
    print(f"SUITE_ID={SUITE_ID}")
    print(f"SUITE_GENERATION_SEED={SUITE_GENERATION_SEED}")
    print("CASES=96")
    print("DOMAINS=6")
    print("CASES_PER_DOMAIN=16")
    print(f"NONREUSE_AUDITED_SOURCES={audit['audited_sources_count']}")
    print(f"NONREUSE_AUDIT_SHA256={audit_digest}")
    print(f"SUITE_CANONICAL_SHA256={digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
