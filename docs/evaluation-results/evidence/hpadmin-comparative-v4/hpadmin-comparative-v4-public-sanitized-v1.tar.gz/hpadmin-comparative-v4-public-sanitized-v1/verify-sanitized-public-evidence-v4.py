#!/usr/bin/env python3
"""Verify the endpoint-sanitized HPADMIN Comparative V4 public derivative."""

from __future__ import annotations

import copy
import hashlib
import json
import re
from pathlib import Path
from typing import Any

import rescore_support_v4 as support
import generate_hpadmin_comparative_suite_v4 as generator


ROOT = Path(__file__).resolve().parent
RAW_NAME = "PUBLIC-HPADMIN-COMPARATIVE-RAW-v4.sanitized.json"
EVIDENCE_NAME = "PUBLIC-HPADMIN-COMPARATIVE-EVIDENCE-v4.sanitized.json"
REPORT_NAME = "PUBLIC-HPADMIN-COMPARATIVE-REPORT-v4.sanitized.md"
PROTOCOL_NAME = "HPADMIN-COMPARATIVE-PROTOCOL-v4.sanitized.json"
NONREUSE_NAME = "NONREUSE-AUDIT-v4.sanitized.json"
PRIVATE_IPV4 = re.compile(
    rb"(?<![0-9])(?:10(?:\.[0-9]{1,3}){3}|192\.168(?:\.[0-9]{1,3}){2}|"
    rb"172\.(?:1[6-9]|2[0-9]|3[01])(?:\.[0-9]{1,3}){2})(?::[0-9]{1,5})?"
)


def file_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(name: str) -> Any:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def read_manifest() -> dict[str, str]:
    entries: dict[str, str] = {}
    for line in (ROOT / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        digest, name = line.split("  ./", 1)
        if not re.fullmatch(r"[0-9a-f]{64}", digest) or not name or name in entries:
            raise ValueError("invalid SHA256SUMS entry")
        entries[name] = digest
    return entries


def exact_manifest() -> None:
    manifest = read_manifest()
    members = list(ROOT.iterdir())
    if any(path.is_symlink() or not path.is_file() for path in members):
        raise ValueError("sanitized bundle may contain only regular files")
    actual = {path.name for path in members if path.name != "SHA256SUMS"}
    if set(manifest) != actual:
        raise ValueError("SHA256SUMS member set is not exact")
    for name, expected in manifest.items():
        path = ROOT / name
        if file_sha(path) != expected:
            raise ValueError(f"SHA256SUMS mismatch: {name}")


def assert_endpoint_redaction(protocol: dict[str, Any], prescore: dict[str, Any], result: dict[str, Any]) -> None:
    values = (
        protocol.get("model_policy", {}).get("endpoint_canonical_sha256"),
        prescore.get("protocol_sha256"),
        result.get("protocol_sha256"),
        result.get("prescore_sha256"),
        prescore.get("suite_commitment_sha256"),
        result.get("suite_commitment_sha256"),
        prescore.get("runtime_policy", {}).get("endpoint_canonical_sha256"),
        result.get("runtime_policy", {}).get("endpoint_canonical_sha256"),
        prescore.get("runtime_policy", {}).get("evaluator_sha256"),
        result.get("runtime_policy", {}).get("evaluator_sha256"),
        prescore.get("runtime_policy", {}).get("execution_code_commit"),
        result.get("runtime_policy", {}).get("execution_code_commit"),
        prescore.get("suite_commitment", {}).get("protocol_commit"),
        result.get("suite_commitment", {}).get("protocol_commit"),
    )
    if any(value is not None for value in values):
        raise ValueError("endpoint or transitive historical commitment was not withheld")
    for path in ROOT.iterdir():
        if PRIVATE_IPV4.search(path.read_bytes()):
            raise ValueError(f"private IPv4 literal remains in sanitized bundle: {path.name}")


def projected_nonreuse_violations(
    audit: Any, suite: dict[str, Any]
) -> tuple[int, list[str]]:
    """Reproduce the frozen finding without the withheld prior-art inventory."""

    issues: list[str] = []
    if not isinstance(audit, dict):
        return 1, ["nonreuse.audit_missing"]
    if (
        audit.get("schema_version") != "hpadmin-nonreuse-audit/4.0"
        or audit.get("suite_id") != support.SUITE_ID
    ):
        issues.append("nonreuse.schema_or_suite")
    if (
        audit.get("suite_generation_seed") != 20260904
        or audit.get("audit_completed_before_freeze") is not True
    ):
        issues.append("nonreuse.freeze")
    if audit.get("observed_prior_proposals_included") is not True:
        issues.append("nonreuse.prior_proposals_not_audited")
    collisions = audit.get("exact_collision_counts")
    if collisions != {
        "case_id": 0,
        "visible_contract": 0,
        "initial_proposal": 0,
        "expected_result": 0,
    }:
        issues.append("nonreuse.exact_collision")
    review = audit.get("semantic_schema_review", {})
    if (
        review.get("status") != "pass"
        or review.get("passed") is not True
        or review.get("domain_id_overlap_count") != 0
        or review.get("renamed_prior_schema_detected") is not False
        or review.get("prior_decision_table_reuse_detected") is not False
    ):
        issues.append("nonreuse.semantic_review")
    if audit.get("unresolved_collisions") != 0:
        issues.append("nonreuse.unresolved_collision")
    projection = audit.get("publication_projection", {})
    if projection != {
        "schema_version": "hpadmin-nonreuse-public-projection/1.0",
        "prior_art_inventory_published": False,
        "prior_art_inventory_status": "WITHHELD_PRIVATE_SOURCE_METADATA",
        "original_suite_link_publicly_reverified": False,
        "frozen_schema_mismatch_preserved": True,
    }:
        issues.append("nonreuse.public_projection")
    suite_link = suite.get("private_suite_metadata", {}).get("non_reuse_audit", {})
    if (
        suite_link.get("audited_sources_count") != audit.get("audited_sources_count")
        or suite_link.get("exact_collision_counts") != collisions
        or suite_link.get("semantic_schema_review_status") != review.get("status")
        or suite_link.get("unresolved_collisions") != 0
        or suite_link.get("audit_completed_before_freeze") is not True
    ):
        issues.append("nonreuse.suite_summary")
    return len(set(issues)), sorted(set(issues))


def expected_report(evidence: dict[str, Any]) -> str:
    report = support.report_markdown(evidence)
    report = report.replace(
        "**ASSESSMENT: NOT_PASSED**\n\n",
        "**ASSESSMENT: NOT_PASSED**\n\n"
        "> This is a post-score sanitized publication derivative. The complete\n"
        "> synthetic suite, oracle, proposals, traces, and scores are retained. The\n"
        "> endpoint digest and transitive original commitments are omitted; therefore\n"
        "> endpoint identity and the original commitment chain cannot be independently\n"
        "> reverified from this bundle.\n\n",
        1,
    )
    report = report.replace(
        "## Preregistered success clauses\n\n",
        "## Recorded preregistered success clauses\n\n"
        "The statuses below are the frozen evaluator's recorded clause results. The\n"
        "sanitized verifier independently recomputes proposal-dependent clauses; the\n"
        "commitment-chain and post-freeze chronology clauses remain restricted-record\n"
        "attestations.\n\n",
        1,
    )
    report = report.replace(
        "Commitment violations: 0. Non-reuse violations: 1. Post-freeze mutations: 0.\n\n",
        "The original restricted execution record reported: commitment violations 0,\n"
        "non-reuse violations 1, and post-freeze mutations 0. The public derivative\n"
        "does not independently reopen the original commitment chain.\n\n",
        1,
    )
    report = report.replace(
        "External timestamp assurance: operator-committed GitHub binding; the remote timestamp was not independently verified. This is disclosed and does not claim stronger attestation.\n\n",
        "The original record also reported an operator-committed GitHub binding. Its R1\n"
        "record and package digest are intentionally not bundled or consumed by this\n"
        "derivative, which does not verify the remote timestamp or authenticate the\n"
        "sanitized results with that record.\n\n",
        1,
    )
    return report + (
        "\n## Sanitized-public verification boundary\n\n"
        "The included verifier independently re-scores all 384 final proposals and 738\n"
        "trace proposals, then recomputes the aggregate statistics and formal\n"
        "`NOT_PASSED` decision. It does not verify the redacted endpoint identity, the\n"
        "original package-manifest chain, or the remote GitHub timestamp. Those are\n"
        "historical properties of the private execution record, not claims established\n"
        "by this sanitized derivative.\n\n"
        "To preserve the retired suite byte for byte, its two non-endpoint commitments\n"
        "to the omitted non-reuse audit and prior-art inventory remain in suite metadata.\n"
        "They cannot reveal the endpoint, but may confirm a correct guess of that\n"
        "withheld inventory.\n\n"
        "Only `verify-sanitized-public-evidence-v4.sh` is intended to be executed. The\n"
        "original launcher, runner, collector, package verifier, operational evidence,\n"
        "and pre-execution README are intentionally absent because they contain or bind\n"
        "the recoverable endpoint commitment.\n"
    )


def main() -> None:
    if not __debug__:
        raise SystemExit("Python optimization must be disabled")
    exact_manifest()

    raw = read_json(RAW_NAME)
    evidence = read_json(EVIDENCE_NAME)
    suite = read_json("hpadmin-comparative-suite-v4.json")
    protocol = read_json(PROTOCOL_NAME)
    audit = read_json(NONREUSE_NAME)
    sanitization = read_json("SANITIZATION-MANIFEST-v4.json")
    prescore = raw["inference_commitment"]
    result = raw["scored_result"]

    if raw.get("schema_version") != "hpadmin-comparative-public-raw-sanitized/1.0":
        raise ValueError("unsupported sanitized RAW schema")
    if evidence.get("schema_version") != "hpadmin-comparative-public-evidence-sanitized/1.0":
        raise ValueError("unsupported sanitized EVIDENCE schema")
    if sanitization.get("schema_version") != "hpadmin-public-sanitization-manifest/1.0":
        raise ValueError("unsupported sanitization manifest")
    if raw.get("sanitization") != evidence.get("sanitization"):
        raise ValueError("RAW/EVIDENCE sanitization declarations differ")
    if sanitization["endpoint_protection"]["withheld_field_value"] is not None:
        raise ValueError("withheld endpoint fields must be JSON null")
    if any(
        sanitization["endpoint_protection"][key] is not False
        for key in (
            "direct_unsalted_endpoint_digest_published",
            "endpoint_identity_publicly_verifiable",
            "endpoint_plaintext_published",
            "transitive_original_endpoint_commitments_included_in_this_archive",
        )
    ):
        raise ValueError("endpoint-protection declaration is overstated")

    assert_endpoint_redaction(protocol, prescore, result)
    regenerated_suite = generator.build_suite()
    published_without_audit_link = copy.deepcopy(suite)
    published_without_audit_link.get("private_suite_metadata", {}).pop(
        "non_reuse_audit", None
    )
    if not support.json_equal(regenerated_suite, published_without_audit_link):
        raise ValueError("published suite cases differ from deterministic generator")
    suite_claim = sanitization.get("byte_exact_and_recomputed", {})
    if (
        suite_claim.get("retired_suite_content_consistent_with_generator") is not True
        or suite_claim.get("retired_suite_canonical_sha256")
        != support.canonical_sha(suite)
    ):
        raise ValueError("retired suite projection hash or generator claim differs")
    retained_nonendpoint = sanitization.get(
        "retained_nonendpoint_historical_commitments", {}
    )
    suite_nonreuse = suite.get("private_suite_metadata", {}).get(
        "non_reuse_audit", {}
    )
    if (
        retained_nonendpoint.get("paths")
        != [
            "/private_suite_metadata/non_reuse_audit/audit_sha256",
            "/private_suite_metadata/non_reuse_audit/prior_art_manifest_sha256",
        ]
        or retained_nonendpoint.get("source_inventory_published") is not False
        or any(
            re.fullmatch(r"[0-9a-f]{64}", suite_nonreuse.get(key, "")) is None
            for key in ("audit_sha256", "prior_art_manifest_sha256")
        )
    ):
        raise ValueError("retained non-endpoint commitment disclosure differs")
    suite_by_id = support.validate_suite(suite)
    support.validate_protocol(protocol)
    support.validate_prescore_result(
        prescore, result, suite, protocol, allow_redacted=True
    )
    bindings = raw.get("public_projection_bindings", {})
    expected_bindings = {
        "sanitized_protocol_canonical_sha256": support.canonical_sha(protocol),
        "sanitized_protocol_file_sha256": file_sha(ROOT / PROTOCOL_NAME),
        "sanitized_inference_record_canonical_sha256": support.canonical_sha(prescore),
        "sanitized_result_record_canonical_sha256": support.canonical_sha(result),
    }
    if bindings != expected_bindings:
        raise ValueError("post-score projection bindings differ from published bytes")

    matrix = support.build_matrix(result, suite_by_id)
    reuse_count, reuse_issues = projected_nonreuse_violations(audit, suite)
    analysis = support.analyze(
        matrix,
        result,
        suite_by_id,
        commitment_violations=0,
        non_reuse_violations=reuse_count,
        post_freeze_mutations=0,
    )
    if not support.json_equal(evidence.get("case_matrix"), matrix):
        raise ValueError("published matrix differs from independent rescoring")
    if not support.json_equal(evidence.get("analysis"), analysis):
        raise ValueError("published analysis differs from independent recomputation")
    if evidence.get("non_reuse_audit") != {
        "violations": reuse_count,
        "issue_codes": reuse_issues,
    }:
        raise ValueError("non-reuse conclusion differs from frozen evaluator")
    if raw.get("non_reuse_audit") != audit:
        raise ValueError("RAW and standalone non-reuse artifacts differ")
    if evidence.get("raw_publication", {}).get("file_sha256") != file_sha(ROOT / RAW_NAME):
        raise ValueError("EVIDENCE does not bind sanitized RAW bytes")
    if evidence.get("protocol", {}).get("sanitized_canonical_sha256") != support.canonical_sha(protocol):
        raise ValueError("EVIDENCE does not bind sanitized protocol content")
    if evidence.get("protocol", {}).get("sanitized_file_sha256") != file_sha(ROOT / PROTOCOL_NAME):
        raise ValueError("EVIDENCE does not bind sanitized protocol bytes")
    if evidence.get("commitment_audit", {}).get("sanitized_public_reverification") != (
        "NOT_AVAILABLE_ENDPOINT_AND_TRANSITIVE_COMMITMENTS_REDACTED"
    ):
        raise ValueError("public commitment-verification limitation is missing")
    final_count = sum(len(row["conditions"]) for row in result["cases"])
    trace_count = sum(
        len(outcome["proposal_trace"])
        for row in result["cases"]
        for outcome in row["conditions"].values()
    )
    unit_count = sum(len(row["model_units"]) for row in result["cases"])
    ledger_count = sum(
        len(outcome.get("controller", {}).get("ledger_records", []))
        for row in result["cases"]
        for outcome in row["conditions"].values()
    )
    feedback_count = sum(
        len(outcome.get("controller", {}).get("feedback_events", []))
        for row in result["cases"]
        for outcome in row["conditions"].values()
    )
    if (
        final_count != 384
        or trace_count != 738
        or unit_count != 192
        or ledger_count != 1056
        or feedback_count != 150
        or result.get("actual_logical_model_calls") != 150
        or result.get("physical_model_calls") != 151
        or result.get("transport_retries") != 1
    ):
        raise ValueError("complete final/trace proposal inventory is missing")
    declared = sanitization["retained_evidence"]
    if declared.get("case_condition_outcomes") != final_count or declared.get("trace_proposals") != trace_count:
        raise ValueError("sanitization manifest inventory differs from RAW data")
    if analysis.get("assessment") != "NOT_PASSED":
        raise ValueError("formal assessment was not reproduced")

    report = (ROOT / REPORT_NAME).read_text(encoding="utf-8")
    if report != expected_report(evidence):
        raise ValueError("sanitized report is not the deterministic recomputed rendering")

    print("SANITIZED_BUNDLE=VERIFIED")
    print("FULL_SYNTHETIC_RESCORE=384_FINALS_AND_738_TRACES_VERIFIED")
    print("EXTERNAL_SUITE_COMMITMENT=NOT_BUNDLED")
    print("ORIGINAL_COMMITMENT_CHAIN=PARTIAL_NOT_REVERIFIED")
    print("ENDPOINT_BINDING=OMITTED")
    print("REMOTE_TIMESTAMP=NOT_VERIFIED")
    print("SOURCE_TAR_INTEGRITY=NOT_CLAIMED")
    print(f"ASSESSMENT={analysis['assessment']}")


if __name__ == "__main__":
    main()
