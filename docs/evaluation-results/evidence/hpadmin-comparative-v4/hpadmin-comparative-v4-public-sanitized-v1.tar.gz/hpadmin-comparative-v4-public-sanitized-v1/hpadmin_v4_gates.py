#!/usr/bin/env python3
"""Production-visible gates and the standalone deterministic V4 baseline.

This module must remain oracle-free. It may inspect only the visible task
contract and a candidate proposal. Hidden expected answers are loaded later by
the separate scoring phase.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from hermes_dohaa.assurance.gates import (
    ActionPolicyGate,
    ClaimEvidenceGate,
    Gate,
    RequiredEvidenceGate,
    ResultSpecGate,
    SemanticAssertionsGate,
)
from hermes_dohaa.contracts.models import TaskContract
from hermes_dohaa.controller.repair_policy import (
    RepairScope,
    RuleAwareRepairPolicy,
    assess_candidate_changes,
    compare_failure_sets,
)
from hermes_dohaa.controller.semantic_repair import (
    propose_deterministic_semantic_repair,
)
from hermes_dohaa.runtime.base import Proposal


EXPECTED_GATE_NAMES = (
    "result_spec",
    "semantic_assertions",
    "action_policy",
    "claim_evidence",
    "required_evidence",
)


@dataclass(frozen=True, slots=True)
class DeterministicPolicyOutcome:
    proposal: Proposal
    attempted: bool
    adopted: bool
    reason_code: str
    assertion_ids: tuple[str, ...] = ()
    result_pointers: tuple[str, ...] = ()
    candidate: Proposal | None = None

    def audit_dict(self) -> dict[str, object]:
        """Return value-free metadata suitable for the protected pre-score."""

        return {
            "attempted": self.attempted,
            "adopted": self.adopted,
            "reason_code": self.reason_code,
            "assertion_ids": list(self.assertion_ids),
            "result_pointers": list(self.result_pointers),
            "candidate_proposal_sha256": (
                self.candidate.fingerprint()
                if self.candidate is not None
                else None
            ),
        }


def production_controller_gates(contract: TaskContract) -> tuple[Gate, ...]:
    """Return the exact deployable gate set used during V4 inference."""

    if not isinstance(contract.inputs.get("result_spec"), dict):
        raise ValueError("V4 contracts must declare result_spec")
    if not isinstance(contract.inputs.get("semantic_assertions"), list):
        raise ValueError("V4 contracts must declare semantic_assertions")
    if RuleAwareRepairPolicy.from_contract(contract) is None:
        raise ValueError("V4 contracts must opt into rule-aware repair")
    gates: tuple[Gate, ...] = (
        ResultSpecGate(),
        SemanticAssertionsGate(),
        ActionPolicyGate(),
        ClaimEvidenceGate(),
        RequiredEvidenceGate(),
    )
    assert_production_gate_set(gates)
    return gates


def production_scoring_gates(contract: TaskContract) -> tuple[Gate, ...]:
    """Use the same visible gates after inference, before hidden scoring."""

    return production_controller_gates(contract)


def apply_deterministic_policy_baseline(
    contract: TaskContract,
    initial: Proposal,
    gates: Sequence[Gate],
) -> DeterministicPolicyOutcome:
    """Apply every eligible equality repair once and retain it only if safe.

    The baseline makes no model call. It is intentionally strong: all eligible
    input-derived equality targets may be proposed in one deterministic pass.
    Immutable paths and full-gate monotonicity are enforced independently.
    """

    assert_production_gate_set(gates)
    before = tuple(gate.evaluate(contract, initial) for gate in gates)
    repair = propose_deterministic_semantic_repair(contract, initial)
    if repair is None:
        return DeterministicPolicyOutcome(
            initial,
            attempted=False,
            adopted=False,
            reason_code="deterministic.no_candidate",
        )

    policy = RuleAwareRepairPolicy.from_contract(contract)
    if policy is None:
        raise ValueError("deterministic baseline requires repair_policy")
    broad_result_scope = RepairScope.from_raw(
        {
            "schema_version": "1.0",
            "failed_rule_ids": ["deterministic-baseline"],
            "rule_ids": ["deterministic-baseline"],
            "editable_paths": ["/result"],
            "atomic_groups": [],
            "source_pointers": [],
        }
    )
    change = assess_candidate_changes(
        initial,
        repair.proposal,
        broad_result_scope,
        policy,
    )
    if not change.allowed:
        return DeterministicPolicyOutcome(
            initial,
            attempted=True,
            adopted=False,
            reason_code="deterministic.immutable_change",
            assertion_ids=repair.assertion_ids,
            result_pointers=repair.result_pointers,
            candidate=repair.proposal,
        )

    after = tuple(gate.evaluate(contract, repair.proposal) for gate in gates)
    comparison = compare_failure_sets(before, after, gates=gates)
    if not comparison.accepted:
        return DeterministicPolicyOutcome(
            initial,
            attempted=True,
            adopted=False,
            reason_code=(
                "deterministic."
                + comparison.reason_code.removeprefix("repair.")
            ),
            assertion_ids=repair.assertion_ids,
            result_pointers=repair.result_pointers,
            candidate=repair.proposal,
        )
    return DeterministicPolicyOutcome(
        repair.proposal,
        attempted=True,
        adopted=True,
        reason_code="deterministic.strict_improvement",
        assertion_ids=repair.assertion_ids,
        result_pointers=repair.result_pointers,
        candidate=repair.proposal,
    )


def assert_production_gate_set(gates: Sequence[Gate]) -> None:
    names = tuple(gate.name for gate in gates)
    if names != EXPECTED_GATE_NAMES:
        raise ValueError(f"unexpected V4 production gate set: {names!r}")
    if len({id(gate) for gate in gates}) != len(gates):
        raise ValueError("V4 production gates must be distinct instances")
