# HPADMIN Comparative V4 — privacy-sanitized public review bundle

**Formal assessment: `NOT_PASSED`**

This is a post-execution publication derivative of HPADMIN Comparative V4.
The experiment was not rerun; the publication files are a post-score projection
with the transformations listed in the manifest. V4 is permanently retired as
confirmatory data.

As an operator-attested projection, the bundle retains the 96-case synthetic
suite and oracle byte for byte, all 384 condition outcomes, all 738 proposal
snapshots, 1,056 controller-ledger records, model-call accounting, stored
scores, and the offline code needed to re-score the disclosed evidence and
recompute the statistics.

## Why this derivative exists

The original public candidate was withheld because an unsalted endpoint digest
could reveal a private IP address and port through offline dictionary search.
This derivative sets endpoint coordinates and endpoint-dependent historical
commitments to JSON `null`, omits operational host artifacts and source digests
that could confirm guesses, and publishes new projection-only hashes.

The complete proposal and oracle evidence is retained. The private prior-art
inventory from the non-reuse audit is summarized without its file list; the
frozen `schema_version: "1.0"` mismatch that caused one formal failure remains
unchanged in the public projection.

Preserving the suite byte for byte also preserves its two non-endpoint SHA-256
commitments to the omitted non-reuse audit and prior-art inventory. They do not
bind the endpoint, but they can confirm a correct offline guess of that private
inventory. This residual boundary is disclosed in the sanitization manifest.

## Verify

Extract into a new directory and run only the sanitized offline verifier:

```bash
mkdir hpadmin-comparative-v4-public-sanitized-v1
tar -xzf hpadmin-comparative-v4-public-sanitized-v1.tar.gz \
  -C hpadmin-comparative-v4-public-sanitized-v1 --strip-components=1
cd hpadmin-comparative-v4-public-sanitized-v1
bash verify-sanitized-public-evidence-v4.sh
```

The verifier checks the exact publication member set, regenerates the suite,
re-scores all 384 final and 738 trace proposals, verifies hashes and controller
ledgers, recomputes paired tests and Holm adjustment, and reproduces
`NOT_PASSED`.

## Verification boundary

This derivative does **not** independently verify the private endpoint, the
original package-manifest chain, original prescore chronology, source TAR byte
identity, remote GitHub timestamp, or model-artifact digest. The historical R1
record and its package digest are intentionally not bundled or consumed by the
sanitized verifier. These limitations cannot rescue the formal result because
two independently visible failures already force `NOT_PASSED`: nine unsafe
finals in the generic comparator and the frozen non-reuse schema mismatch.

See `SANITIZATION-MANIFEST-v4.json` for the exact retained, transformed, and
withheld fields. Do not use this archive to launch or repeat the experiment.
